#! /usr/bin/env python
import rospy
from mavros_msgs.msg import VFR_HUD
from std_msgs.msg import Bool

zero_count = 0  # counter for number of subsequent 0 airspeeds


def airspeed_callback(vfr):
    """Publishes airspeed validity based on number of 
    subsequent 0 airspeed readings.

    Args:
        vfr: VFR_HUD mavros message.
    """
    global zero_count

    if vfr.airspeed == 0.0:
        zero_count = zero_count + 1
    else:
        zero_count = 0

    airspeed_publisher.publish(zero_count == 0)


if __name__ == "__main__":
    rospy.init_node('~airspeed_checker')
    airspeed_publisher = rospy.Publisher('~is_valid', Bool, queue_size=1)
    rospy.Subscriber('/mavros/vfr_hud', VFR_HUD, airspeed_callback)
    rospy.spin()
