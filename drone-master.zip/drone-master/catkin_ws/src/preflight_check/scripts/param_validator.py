#! /usr/bin/env python
"""Verifies all parameters loaded from the Pixhawk are consistent."""

import rospy
import numpy as np
from mavros_msgs.srv import ParamGet, ParamPull
from std_srvs.srv import Trigger, TriggerResponse

# Parameter blacklist.
blacklist = {
    "LND_FLIGHT_T_HI",  # Total flight time in microseconds, high byte.
    "LND_FLIGHT_T_LO",  # Total flight time in microseconds, low byte.
}


def get_expected_params(path):
    """Loads the expected parameter list from a parameter file exported by QGC.

    Args:
        path: Path to file.

    Returns:
        Dictionary of parameter keys to expected values.
    """
    with open(path) as f:
        # Filter out comments.
        p = filter(lambda x: not x.startswith('#'), f)

        # Tokenize and extract relevant data.
        p = map(lambda x: x.strip().split('\t')[2:4], p)

        # Transform to proper types.
        p = map(lambda x: (x[0], np.float64(x[1])
                           if '.' in x[1] else np.int64(x[1])), p)

    # Convert to dict.
    return {x[0]: x[1] for x in p}


def compare_params(expected):
    """Compares the expected parameters from the parameters retrieved from the
    Pixhawk.

    Args:
        expected: Expected parameters dictionary.

    Returns:
        Number of inconsistencies.
    """
    # Pull all parameters for faster loading.
    r = pull_server.call()
    rospy.loginfo("Checking %d params...", r.param_received)

    # Compare them one by one.
    inconsistencies = 0
    for key, expected_value in expected.items():
        if key in blacklist:
            # Ignore this parameter.
            continue

        get_response = get_server.call(key)
        if get_response.success:
            if isinstance(expected_value, np.float64):
                set_value = get_response.value.real
            else:
                set_value = get_response.value.integer

            if not np.isclose([set_value], [expected_value]):
                inconsistencies += 1
                rospy.logwarn("Unexpected value for %s: expected %r, got: %r",
                              key, expected_value, set_value)
        else:
            inconsistencies += 1
            rospy.logwarn("Could not retrieve value for %s", key)

    if inconsistencies > 0:
        rospy.logerr("%d inconsistencies found, flying not recommended",
                     inconsistencies)

    return inconsistencies


def check_cb(req):
    """Validates the parameter list.

    Args:
        req: Trigger request, unused.

    Returns:
        TriggerResponse.
    """
    path = rospy.get_param("~param_path")
    expected_params = get_expected_params(path)
    inconsistencies = compare_params(expected_params)
    success = inconsistencies == 0
    message = "{} inconsistencies found".format(inconsistencies)
    return TriggerResponse(success, message)


if __name__ == "__main__":
    rospy.init_node("~param")

    pull_server = rospy.ServiceProxy("/mavros/param/pull", ParamPull)
    get_server = rospy.ServiceProxy("/mavros/param/get", ParamGet, True)

    checker_service = rospy.Service("~check", Trigger, check_cb)

    pull_server.wait_for_service()
    get_server.wait_for_service()

    rospy.spin()
