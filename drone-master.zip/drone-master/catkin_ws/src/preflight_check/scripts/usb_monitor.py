#!/usr/bin/env python

import os
import rospy
from preflight_check.msg import USBDevice, USBDeviceArray


def get_usb_monitor_set():
    """Get the USB connections from the parameter loaded by launch file.

    Returns:
        Set of paths of USB connections that we want to monitor.
    """
    path = rospy.get_param("~usb_path")
    return set(path)


def generate_USBDevice_msg(path, connected):
    """Generate one USB connection message

    Args:
        path: path of the connection
        connected: whether the connection is connected or not

    Returns:
        A USBDevice message
    """
    msg = USBDevice()
    msg.path = path
    msg.connected = connected
    return msg


def generate_USBDeviceArray_msg(usb_set_connected, usb_set_disconnected):
    """Generate all USB connections message

    Args:
        usb_set_connected
        usb_set_disconnected

    Returns:
        A USBDeviceArray message
    """
    msgArray = USBDeviceArray()
    for usb in usb_set_connected:
        msgArray.data.append(generate_USBDevice_msg(usb, True))
    for usb in usb_set_disconnected:
        msgArray.data.append(generate_USBDevice_msg(usb, False))
    return msgArray


if __name__ == "__main__":
    rospy.init_node("~usb")

    # Publishes only when connections change, and publishes only changed
    # connections.
    pub_change = rospy.Publisher("~event", USBDevice, queue_size=1)

    # Publishes all the time for all USB connections.
    pub_all = rospy.Publisher("~devices", USBDeviceArray, queue_size=1)

    rate = rospy.Rate(1)  # 1Hz
    usb_set_all = get_usb_monitor_set()
    usb_set_connected = get_usb_monitor_set()
    usb_set_disconnected = set()

    while not rospy.is_shutdown():
        # Update connected set
        for usb in usb_set_connected:
            if not os.path.exists(usb):
                usb_set_disconnected.add(usb)
                msg = generate_USBDevice_msg(usb, False)
                rospy.logwarn("{} is disconnected".format(msg.path))
                pub_change.publish(msg)

        usb_set_connected = usb_set_all - usb_set_disconnected

        # Update disconnected set
        for usb in usb_set_disconnected:
            if os.path.exists(usb):
                usb_set_connected.add(usb)
                msg = generate_USBDevice_msg(usb, True)
                rospy.loginfo("{} is connected".format(msg.path))
                pub_change.publish(msg)

        usb_set_disconnected = usb_set_all - usb_set_connected

        msgArray = generate_USBDeviceArray_msg(usb_set_connected,
                                               usb_set_disconnected)
        pub_all.publish(msgArray)

        rate.sleep()
