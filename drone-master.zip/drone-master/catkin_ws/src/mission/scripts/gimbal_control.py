#!/usr/bin/env python
"""Controls and stows the camera gimbal."""

import rospy
import tf2_ros
import numpy as np
import message_filters
import tf2_geometry_msgs
from mission.srv import GimbalTrack
from mission.msg import GimbalStatus
from std_srvs.srv import SetBool, Trigger
from storm32_gimbal.msg import GimbalOrientation
from geometry_msgs.msg import PoseStamped, QuaternionStamped
from mavros_msgs.msg import Altitude, ExtendedState, StatusText


class GimbalController(object):

    """Gimbal controller."""

    def __init__(self, default_orientation, stow_orientation, gimbal_topic,
                 gimbal_unlimited, gimbal_ref_frame_id, period):
        """Constructs the GimbalController.

        Args:
            default_orientation (QuaternionStamped): Default orientation to
                point the gimbal to.
            stow_orientation (QuaternionStamped): Orientation to stow the
                gimbal.
            gimbal_topic (str): Gimbal topic.
            gimbal_unlimited (bool): Whether or not to limit the rotation of
                the gimbal.
            gimbal_ref_frame_id (str): Gimbal reference frame ID.
            period (Duration): Control loop period.
        """
        self._stowed = False
        self._tracking = False
        self._track_id = ""
        self._unlimited = gimbal_unlimited
        self._ref_frame_id = gimbal_ref_frame_id

        self._default_orientation = default_orientation
        self._stow_orientation = stow_orientation
        self._pub = rospy.Publisher(
            gimbal_topic, GimbalOrientation, queue_size=1)
        self._status_pub = rospy.Publisher(
            "~status", GimbalStatus, queue_size=1)

        self._buffer = tf2_ros.Buffer()
        self._listener = tf2_ros.TransformListener(self._buffer)

        rospy.Timer(period, self._control_cb)
        rospy.Timer(rospy.Duration(1.0), self._status_cb)

    @property
    def stowed(self):
        """Whether the gimbal is stowed or not."""
        return self._stowed

    def _status_cb(self, event):
        """Status loop callback.

        Args:
            event (TimerEvent): Unused.
        """
        msg = GimbalStatus()
        msg.header.frame_id = self._ref_frame_id
        msg.header.stamp = rospy.get_rostime()
        msg.stowed = self._stowed
        msg.tracking = self._tracking
        msg.track_id = self._track_id
        self._status_pub.publish(msg)

    def _control_cb(self, event):
        """Control loop callback.

        Args:
            event (TimerEvent): Unused.
        """
        # Pull these out in case they change during the call.
        stowed = self._stowed
        tracking = self._tracking
        track_id = self._track_id

        if stowed:
            frame_id = self._stow_orientation.header.frame_id
            quaternion = self._stow_orientation.quaternion
        elif tracking:
            frame_id = track_id
        else:
            frame_id = self._default_orientation.header.frame_id
            quaternion = self._default_orientation.quaternion

        # Get the latest transform.
        try:
            transform_stamped = self._buffer.lookup_transform(
                self._ref_frame_id, frame_id, rospy.Time(0))
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException,
                tf2_ros.ExtrapolationException) as e:
            rospy.logerr_throttle(1.0, str(e))
            return

        if tracking and not stowed:
            # The rotation of the transform is all we need.
            quaternion = transform_stamped.transform.rotation
        else:
            # We need to transform the rotation to the gimbal_ref frame.
            pose_stamped = PoseStamped()
            pose_stamped.header.stamp = rospy.get_rostime()
            pose_stamped.header.frame_id = frame_id
            pose_stamped.pose.orientation = quaternion
            quaternion = tf2_geometry_msgs.do_transform_pose(
                pose_stamped, transform_stamped).pose.orientation

        # Publish.
        msg = GimbalOrientation()
        msg.orientation = quaternion
        msg.unlimited = self._unlimited
        self._pub.publish(msg)

    def stow(self):
        """Stows the gimbal.

        Raises:
            tf2_ros.LookupException: If frame_id cannot be looked up.
            tf2_ros.ConnectivityException: If frame_id is not connected to
                gimbal_ref_frame_id.
            tf2_ros.ExtrapolationException: If the frame_id to
                gimbal_ref_frame_id transform requires extrapolation into the
                future.
        """
        self._stowed = True

        # Attempt to lookup transform without catching exceptions.
        self._buffer.lookup_transform(self._ref_frame_id,
                                      self._stow_orientation.header.frame_id,
                                      rospy.Time(0))

    def unstow(self):
        """Unstows the gimbal."""
        self._stowed = False

    def track(self, frame_id):
        """Tracks a reference frame.

        Args:
            frame_id (str): The target frame ID.

        Raises:
            tf2_ros.LookupException: If frame_id cannot be looked up.
            tf2_ros.ConnectivityException: If frame_id is not connected to
                gimbal_ref_frame_id.
            tf2_ros.ExtrapolationException: If the frame_id to
                gimbal_ref_frame_id transform requires extrapolation into the
                future.
        """
        self._tracking = True
        self._track_id = frame_id
        warn("Tracking {} frame".format(frame_id))

        # Attempt to lookup transform without catching exceptions.
        self._buffer.lookup_transform(self._ref_frame_id, frame_id,
                                      rospy.Time(0))

    def untrack(self):
        """Stops tracking a reference frame."""
        warn("No longer tracking {} frame".format(self._track_id))
        self._tracking = False
        self._track_id = None


def warn(text):
    """Alerts the user of a message.

    Args:
        text (str): Message.
    """
    rospy.logwarn(text)
    msg = StatusText()
    msg.severity = StatusText.ALERT
    msg.text = text
    statustext_pub.publish(msg)


def stow_cb(req):
    """Stowing service callback.

    Args:
        req (SetBoolRequest): ROS service request.

    Returns:
        SetBoolResponse.
    """
    if req.data == controller.stowed:
        return True, ""

    if req.data:
        try:
            warn("Stowing gimbal by request")
            controller.stow()
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException,
                tf2_ros.ExtrapolationException) as e:
            rospy.logerr(str(e))
            controller.unstow()
            return False, str(e)
    else:
        warn("Unstowing gimbal by request")
        controller.unstow()

    return True, ""


def track_cb(req):
    """Tracking service callback.

    Args:
        req (GimbalTrackRequest): ROS service request.

    Returns:
        GimbalTrackResponse.
    """
    try:
        controller.track(req.frame_id)
        return True, ""
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException,
            tf2_ros.ExtrapolationException) as e:
        rospy.logerr(str(e))
        controller.untrack()
        return False, str(e)


def untrack_cb(req):
    """Untracking service callback.

    Args:
        req (TriggerRequest): ROS service request.

    Returns:
        TriggerResponse.
    """
    controller.untrack()
    return True, ""


def msg_callback(extended_state, altitude):
    """Callback to automatically stow/unstow the camera during takeoff and
    landing.

    Args:
        extended_state (ExtendedState): ROS message.
        altitude (Altitude): ROS message.
    """
    reason = {
        ExtendedState.LANDED_STATE_UNDEFINED: "UNDEFINED",
        ExtendedState.LANDED_STATE_ON_GROUND: "ON GROUND",
        ExtendedState.LANDED_STATE_IN_AIR: "IN AIR",
        ExtendedState.LANDED_STATE_TAKEOFF: "TAKEOFF",
        ExtendedState.LANDED_STATE_LANDING: "LANDING",
    }[extended_state.landed_state]

    should_stow = extended_state.landed_state != ExtendedState.LANDED_STATE_IN_AIR

    if not np.isfinite(altitude.relative):
        should_stow = True
        reason = "{}, ALTITUDE UNKNOWN".format(reason)

    if altitude.relative < min_altitude:
        should_stow = True
        reason = "{}, ALTITUDE TOO LOW".format(reason)

    if not should_stow:
        if not controller.stowed:
            return

        controller.unstow()
        warn("Auto unstow: {}".format(reason))
    elif not controller.stowed:
        controller.stow()
        warn("Auto stow: {}".format(reason))


if __name__ == "__main__":
    rospy.init_node("~gimbal")

    default_msg = QuaternionStamped()
    default_msg.header.frame_id = rospy.get_param("~default_orientation/frame")
    default_msg.quaternion.x = rospy.get_param("~default_orientation/x")
    default_msg.quaternion.y = rospy.get_param("~default_orientation/y")
    default_msg.quaternion.z = rospy.get_param("~default_orientation/z")
    default_msg.quaternion.w = rospy.get_param("~default_orientation/w")

    stow_msg = QuaternionStamped()
    stow_msg.header.frame_id = rospy.get_param("~stow_orientation/frame")
    stow_msg.quaternion.x = rospy.get_param("~stow_orientation/x")
    stow_msg.quaternion.y = rospy.get_param("~stow_orientation/y")
    stow_msg.quaternion.z = rospy.get_param("~stow_orientation/z")
    stow_msg.quaternion.w = rospy.get_param("~stow_orientation/w")

    gimbal_topic = rospy.get_param("~target_topic")
    gimbal_unlimited = rospy.get_param("~unlimited")
    gimbal_ref_frame_id = rospy.get_param("~ref_frame_id")
    min_altitude = rospy.get_param("~min_altitude")

    period = rospy.Duration(rospy.get_param("~period"))

    controller = GimbalController(default_msg, stow_msg, gimbal_topic,
                                  gimbal_unlimited, gimbal_ref_frame_id, period)

    statustext_pub = rospy.Publisher(
        "/mavros/statustext/send", StatusText, queue_size=1)

    rospy.Service("~stow", SetBool, stow_cb)
    rospy.Service("~track", GimbalTrack, track_cb)
    rospy.Service("~untrack", Trigger, untrack_cb)

    subscribers = [
        message_filters.Subscriber("/mavros/extended_state", ExtendedState),
        message_filters.Subscriber("/mavros/altitude", Altitude),
    ]
    synchronizer = message_filters.ApproximateTimeSynchronizer(
        subscribers, 20, 2)
    synchronizer.registerCallback(msg_callback)

    rospy.spin()
