#!/usr/bin/env python
"""Action server that takes a list of mission tasks and accomplishes them one by one."""

import rospy
import actionlib
from std_srvs.srv import Trigger
from actionlib_msgs.msg import GoalStatus
from navigation.msg import Navigation, NavigationAction, NavigationGoal
from mavros_msgs.msg import StatusText
from mission.msg import (MissionRunnerAction, MissionRunnerFeedback,
                         MissionRunnerResult, MissionTask)
from mission.srv import GimbalTrack


def mission_task_to_navigation_goal(mission_task):
    """Converts a mission task to a navigation goal.
    Conversion only makes sense for mission tasks that are related to
    navigation (e.g. takeoff, waypoint captures, landing).

    Args:
        mission_task (mission/MissionTask).

    Returns:
        navigation/NavigationGoal.

    Raises:
        ValueError: If the conversion does not make sense.
    """
    # Ensure that the conversion makes sense.
    if mission_task.task == MissionTask.TAKEOFF:
        task = Navigation.TAKEOFF
    elif mission_task.task == MissionTask.WAYPOINT_CAPTURE:
        task = Navigation.WAYPOINT_CAPTURE
    elif mission_task.task == MissionTask.SURVEY:
        task = Navigation.WAYPOINT_CAPTURE  # Convert SURVEY.
    elif mission_task.task == MissionTask.LAND:
        task = Navigation.LAND
    else:
        raise ValueError(
            'Cannot convert a MissionTask with a task of {} into a NavigationGoal.'.
            format(mission_task.task))

    return NavigationGoal(
        navigation=Navigation(
            task=task,
            param1=mission_task.param1,
            param2=mission_task.param2,
            param3=mission_task.param3,
            param4=mission_task.param4,
            param5=mission_task.param5,
            param6=mission_task.param6,
        ))


CANCELLED = 'CANCELLED'
SUCCEEDED = 'SUCCEEDED'
FAILED = 'FAILED'


def send_navigation_goal(navigation_action_client, navigation_goal,
                         cancellation_test):
    """Sends a navigation goal to the navigation server.

    Args:
        navigation_action_client (actionlib.SimpleActionClient): The client to the
            navigation server.
        navigation_goal (navigation/NavigationGoal): The goal to send to the
            navigation server.
        cancellation_test (function): Non-blocking function (taking no arguments)
            that has to return True to abort the navigation goal. This function is
            the means by which send_navigation_goal knows whether or not to request
            an abort of the navigation goal. This function will be called
            periodically.

    Returns:
        CANCELLED, SUCCEEDED, or FAILED.
    """
    navigation_action_client.send_goal(navigation_goal)

    # Block until the task completes, or if the mission_runner_goal
    # (i.e. mission) is preempted.
    # Similar to the functionality of SimpleActionClient.wait_for_result().
    # A custom solution is used in this case so that entire function can be
    # terminated (instead of only terminating the current iteration of the
    # for loop).
    state = navigation_action_client.get_state()
    while (not rospy.is_shutdown() and
           (state == GoalStatus.PENDING or state == GoalStatus.ACTIVE)):
        predicate = cancellation_test()
        if predicate:
            navigation_action_client.cancel_all_goals()
            return CANCELLED

        # Get the updated state of the task.
        state = navigation_action_client.get_state()

    # Get the result of the navigation action once it has been completed.
    navigation_action_client.wait_for_result()
    task_result = navigation_action_client.get_result()
    if task_result.success:
        return SUCCEEDED
    else:
        return FAILED


def mission_runner_callback(mission_runner_goal):
    """Callback for the mission runner action.

    Args:
        mission_runner_goal (mission/MissionRunnerGoal).
    """
    # Initial mission task states.
    mission_task_states = [MissionRunnerFeedback.STOPPED] * len(
        mission_runner_goal.mission_tasks)
    start_from_index = mission_runner_goal.start_from

    # Execute mission tasks.
    for index, mission_task in enumerate(
            mission_runner_goal.mission_tasks[start_from_index:],
            start_from_index):

        # Send initial feedback for the current mission task.
        mission_task_states[index] = MissionRunnerFeedback.RUNNING
        server.publish_feedback(
            MissionRunnerFeedback(
                current_task=index, task_states=mission_task_states))

        # Execute the task.
        # Every branch should set `result` to either CANCELLED, SUCCEEDED, or FAILED.
        if (mission_task.task == MissionTask.TAKEOFF or
                mission_task.task == MissionTask.WAYPOINT_CAPTURE or
                mission_task.task == MissionTask.SURVEY or
                mission_task.task == MissionTask.LAND):

            navigation_goal = mission_task_to_navigation_goal(mission_task)
            result = send_navigation_goal(navigation_client, navigation_goal,
                                          lambda: server.is_preempt_requested())
        elif (mission_task.task == MissionTask.OFF_AXIS_OBJECT or
              mission_task.task == MissionTask.EMERGENT_OBJECT):

            # Instruct the gimbal to start tracking the object.
            if mission_task.task == MissionTask.OFF_AXIS_OBJECT:
                start_tracking = gimbal_track(frame_id='off_axis_obj')
            else:
                start_tracking = gimbal_track(frame_id='emergent_obj')

            if not start_tracking.success:
                rospy.logerr(
                    'Unable to instruct gimbal to track object on ground.')
                result = FAILED
            else:
                # Go as close as possible to the object.
                navigation_goal = NavigationGoal(
                    navigation=Navigation(
                        task=MissionTask.WAYPOINT_CAPTURE,
                        param1=mission_task.param1,
                        param2=mission_task.param2,
                        param3=40.0,  # Altitude in metres.
                    ))
                result = send_navigation_goal(
                    navigation_client, navigation_goal,
                    lambda: server.is_preempt_requested())

                # Stop the gimbal from tracking the object.
                stop_tracking = gimbal_untrack()
                if not stop_tracking.success:
                    rospy.logwarn(
                        'Unable to instruct gimbal to stop tracking object on ground.'
                    )
        elif mission_task.task == MissionTask.SURVEY:
            result = FAILED
            rospy.logwarn('The SURVEY task has not been implemented.')
        elif mission_task.task == MissionTask.AIRDROP:
            result = FAILED
            rospy.logwarn('The AIRDROP task has not been implemented.')
        else:
            result = FAILED
            rospy.logerr('Invalid MissionTask task value: {}'.format(
                mission_task.task))

        # Send feedback about the result of the task.
        if result == CANCELLED:
            mission_task_states[index] = MissionRunnerFeedback.STOPPED
            server.publish_feedback(
                MissionRunnerFeedback(
                    current_task=index, task_states=mission_task_states))

            server.set_preempted(
                MissionRunnerResult(
                    success=False, message='Mission preempted.'),
                'Mission preempted.')
            return
        elif (result == SUCCEEDED or result == FAILED):
            if result == SUCCEEDED:
                mission_task_states[index] = MissionRunnerFeedback.COMPLETED
            else:
                mission_task_states[index] = MissionRunnerFeedback.FAILED

            # Send feedback.
            server.publish_feedback(
                MissionRunnerFeedback(
                    current_task=index, task_states=mission_task_states))

        # Send status text.
        # WARN: Does not send anything if navigation is preempted.
        status = StatusText()
        status.header.stamp = rospy.Time.now()
        status.severity = StatusText.ALERT
        if result == SUCCEEDED:
            status.text = 'Task {} was completed successfully'.format(index)
        else:
            status.text = 'Task {} failed'.format(index)
        status_pub.publish(status)

        del result  # So that bugs appear earlier in the form of NameErrors...

    # All tasks in the mission have been run.
    server.set_succeeded(
        MissionRunnerResult(success=True),
        'Finished running all tasks in the mission.')


if __name__ == '__main__':
    rospy.init_node('~mission_runner')

    # For making the aircraft move.
    navigation_client = actionlib.SimpleActionClient(
        '/navigation/server/navigation', NavigationAction)
    navigation_client.wait_for_server()

    # For commanding the gimbal.
    track_ns = '/mission/gimbal/track'
    gimbal_track = rospy.ServiceProxy(track_ns, GimbalTrack)
    rospy.wait_for_service(track_ns)

    untrack_ns = '/mission/gimbal/untrack'
    gimbal_untrack = rospy.ServiceProxy(untrack_ns, Trigger)
    rospy.wait_for_service(untrack_ns)

    # For displaying status messages.
    status_pub = rospy.Publisher(
        '/mavros/statustext/send', StatusText, queue_size=1)

    # Start the action server.
    server = actionlib.SimpleActionServer(
        '~server',
        MissionRunnerAction,
        mission_runner_callback,
        auto_start=False)
    server.start()

    rospy.spin()
