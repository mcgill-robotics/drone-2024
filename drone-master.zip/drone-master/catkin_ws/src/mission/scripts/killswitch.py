#!/usr/bin/env python
"""Script that allows for a killswitch to control mission_runner i.e.
start,pause, and stop a loaded mission."""

import rospy
from mavros_msgs.msg import RCIn
from std_srvs.srv import Trigger, TriggerResponse
from mavros_msgs.msg import StatusText

killswitch = True
status_pub = rospy.Publisher(
    '/mavros/statustext/send', StatusText, queue_size=1)


def start_mission():
    """Starts mission by calling the start_mission service.
    Also sets killswitch to false.
    """
    global killswitch
    rospy.wait_for_service('/mission/start_mission')
    try:
        start_mission = rospy.ServiceProxy('/mission/start_mission', Trigger)
        start_mission_response = start_mission()
    except rospy.ServiceException as e:
        rospy.logwarn_throttle(1, 'Failed to start mission_runner: {}'.format(
            e.message))
        return

    if not start_mission_response.success:
        rospy.logwarn_throttle(1, 'Failed to start mission_runner: {}'.format(
            start_mission_response.message))
    else:
        killswitch = False
        msg = 'Mission killswitch disabled and mission started'
        rospy.logwarn_throttle(1, msg)
        start_statustext = StatusText()
        start_statustext.header.stamp = rospy.Time.now()
        start_statustext.severity = StatusText.ALERT
        start_statustext.text = msg
        status_pub.publish(start_statustext)


def stop_mission():
    """Stops mission by calling the stop_mission service.
    Also sets killswitch to True.
    """
    global killswitch
    rospy.wait_for_service('/mission/stop_mission')
    try:
        stop_mission = rospy.ServiceProxy('/mission/stop_mission', Trigger)
        stop_mission_response = stop_mission()
    except rospy.ServiceException as e:
        rospy.logwarn_throttle(1, 'Failed to stop mission_runner: {}'.format(
            e.message))
        return

    if not stop_mission_response.success:
        rospy.logwarn_throttle(1, 'Failed to stop mission_runner: {}'.format(
            stop_mission_response.message))
    else:
        killswitch = True
        msg = 'Mission killsitch enabled and mission stopped'
        rospy.logwarn_throttle(1, msg)
        stop_statustext = StatusText()
        stop_statustext.header.stamp = rospy.Time.now()
        stop_statustext.severity = StatusText.ALERT
        stop_statustext.text = msg
        status_pub.publish(stop_statustext)


def rc_in_cb(msg):
    """RC callback for killswitch triggering.

    Args:
        msg (mavros_msgs/RCIn): RC message
    """
    global killswitch
    if operation == 'greater':
        if msg.channels[channel] >= treshold and killswitch:
            start_mission()
        elif msg.channels[channel] < treshold and not killswitch:
            stop_mission()
    elif operation == 'less':
        if msg.channels[channel] <= treshold and killswitch:
            start_mission()
        elif msg.channels[channel] > treshold and not killswitch:
            stop_mission()
    else:
        raise ValueError('Operation not permitted')


if __name__ == '__main__':
    rospy.init_node('~killswitch')

    channel = int(rospy.get_param('~channel'))
    operation = rospy.get_param('~operation')
    treshold = int(rospy.get_param('~treshold'))

    rospy.Subscriber('/mavros/rc/in', RCIn, rc_in_cb, queue_size=1)

    rospy.spin()
