#!/usr/bin/env python
"""Control over the mission (set mission, start mission, pause mission,
stop mission, set current task).
"""

import rospy
import actionlib
from actionlib_msgs.msg import GoalStatus
from std_srvs.srv import Trigger, TriggerResponse

from mission.msg import (MissionPlan, MissionRunnerAction, MissionRunnerGoal)
from mission.srv import (SetMission, SetMissionResponse, SetCurrentTask,
                         SetCurrentTaskResponse)

mission_state = MissionPlan.STOPPED
current_task = 0  # index.
navigation_tasks = []
task_states = []


def set_mission_state(state):
    global mission_state
    mission_state = state


def set_current_task(task_index):
    global current_task
    current_task = task_index


def set_task_states(states):
    global task_states
    task_states = states


def set_navigation_tasks(tasks):
    global navigation_tasks
    navigation_tasks = tasks


# Control over the mission runner.
def start_mission_runner(mission_runner_goal):
    """Start the mission runner, sending the provided goal to the mission runner.

    Args:
        mission_runner_goal (mission/MissionRunnerGoal): Goal to send to the
            mission runner.
    """
    action_client.send_goal(
        mission_runner_goal,
        feedback_cb=mission_runner_feedback_cb,
        done_cb=mission_runner_done_cb)
    set_mission_state(MissionPlan.RUNNING)


def pause_mission_runner():
    """Pause the mission runner by cancelling all goals."""
    global task_states
    global current_task

    action_client.cancel_all_goals()

    while action_client.gh is not None:
        if action_client.get_state() != GoalStatus.ACTIVE:
            break

    set_mission_state(MissionPlan.PAUSED)
    task_states[current_task] = MissionPlan.PAUSED


def stop_mission_runner():
    """Stop the mission runner by stopping all of its running goals."""
    action_client.cancel_all_goals()

    # Block until goals are all cancelled.
    # Needed because cancel_all_goals() does not block (it is asynchronous).
    # gh is the goal handle. This is used in order to avoid spamming the
    # console with expected errors.
    while action_client.gh is not None:
        if action_client.get_state() != GoalStatus.ACTIVE:
            break
    # In order to allow for zero-state functionality, the current
    # task must be set to zero.
    set_current_task(0)
    set_mission_state(MissionPlan.STOPPED)
    set_task_states([MissionPlan.STOPPED] * len(navigation_tasks))


def mission_runner_feedback_cb(feedback):
    """Called every time a feedback from the mission runner is received.

    Args:
        feedback (mission/MissionRunnerFeedback): Feedback from the mission
            runner.
    """
    set_current_task(feedback.current_task)
    set_task_states(feedback.task_states)


def mission_runner_done_cb(goal_status, result):
    """Called when the mission runner completes its goal.

    Args:
        goal_status (actionlib_msgs/GoalStatus): Terminal state (unused).
        result (mission/MissionRunnerResult): The result of the goal sent
            to the mission runner (unused).
    """
    set_mission_state(MissionPlan.COMPLETED)


def is_mission_running():
    """Whether or not the mission runner is running a mission.

    Returns:
        bool: True if the mission runner is still running tasks. False otherwise.
    """
    return mission_state == MissionPlan.RUNNING


# ROS publishers and service handlers.
def publish_mission(timer_event):
    """Publishes a MissionPlan for viewing the current state of the mission.

    Args:
        timer_event (rospy.timer.TimerEvent): Unused.
    """
    mission_publisher.publish(
        MissionPlan(
            state=mission_state,
            current_task=current_task,
            mission_tasks=navigation_tasks,
            task_states=task_states))


def set_mission_cb(request):
    """Callback for the set_mission service.

    Args:
        request (mission/SetMission).
    """
    set_navigation_tasks(request.mission_tasks)

    # Set the current task to be the first task.
    set_current_task(0)

    # Set all the task states to 'STOPPED'.
    set_task_states([MissionPlan.STOPPED] * len(navigation_tasks))

    stop_mission_runner()

    return SetMissionResponse(success=True)  # Always successful.


def start_mission_cb(request):
    """Callback for the start_mission service.

    Args:
        request (std_srvs/Trigger).
    """
    response = TriggerResponse()

    if is_mission_running():
        response.success = False
        response.message = 'A mission is already running.'
    else:
        # Convert the navigation tasks into a goal for the mission_runner.
        mission_runner_goal = MissionRunnerGoal(
            start_from=current_task, mission_tasks=navigation_tasks)
        start_mission_runner(mission_runner_goal)
        response.success = True

    return response


def pause_mission_cb(request):
    """Callback for the pause_mission service.

    Args:
        request (std_srvs/Trigger).
    """
    response = TriggerResponse()

    if len(navigation_tasks) == 0:
        response.success = False
        response.message = 'There is no current mission.'
    else:
        pause_mission_runner()
        response.success = True

    return response


def stop_mission_cb(request):
    """Callback for the stop_mission service.

    Args:
        request (std_srvs/Trigger).
    """
    response = TriggerResponse()

    if len(navigation_tasks) == 0:
        response.success = False
        response.message = 'There is no current mission.'
    else:
        stop_mission_runner()
        response.success = True

    return response


def set_current_task_cb(request):
    """Callback for the set_current_task service.

    Args:
        request (mission/SetCurrentTask).
    """
    response = SetCurrentTaskResponse()

    if is_mission_running():
        response.success = False
        response.message = 'Mission is running. Mission must be stopped before setting the task.'
    elif request.task_index > (len(navigation_tasks) - 1):
        response.success = False
        response.message = 'Invalid index.'
    else:
        set_current_task(request.task_index)
        response.success = True

    return response


if __name__ == '__main__':
    rospy.init_node('~mission_control')

    # For sending goals to the mission runner.
    action_client = actionlib.SimpleActionClient('mission_runner/server',
                                                 MissionRunnerAction)
    action_client.wait_for_server()

    # Services for controlling the mission.
    rospy.Service('set_mission', SetMission, set_mission_cb)
    rospy.Service('set_current_task', SetCurrentTask, set_current_task_cb)
    rospy.Service('start_mission', Trigger, start_mission_cb)
    rospy.Service('pause_mission', Trigger, pause_mission_cb)
    rospy.Service('stop_mission', Trigger, stop_mission_cb)

    # Publishers.
    # For viewing the current mission.
    mission_publisher = rospy.Publisher('inspect', MissionPlan, queue_size=1)
    rospy.Timer(rospy.Duration(1), publish_mission)

    rospy.spin()
