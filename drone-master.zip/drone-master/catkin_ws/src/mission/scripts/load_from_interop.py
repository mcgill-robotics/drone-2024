#!/usr/bin/env python
"""Provides a ROS service for loading a mission based on information from
interop into mission control.
"""

import rospy
from mission.survey import generate_coordinates
from mission.msg import MissionTask
from interop.msg import WayPoints
from geographic_msgs.msg import GeoPointStamped
from interop.msg import GeoPolygonStamped, FlyZoneArray
from mission.srv import SetMission, SetMissionRequest
from std_srvs.srv import Trigger, TriggerRequest, TriggerResponse


def get_waypoints():
    """Get the list of waypoints from interop.

    Returns:
        list(geographic_msgs/GeoPoint): The list of waypoints.
    """
    message = rospy.wait_for_message(
        '/interop/mission_info/waypoints', WayPoints, timeout=5.0)
    return message.waypoints


def get_survey_polygon():
    """Get the survey polygon (search grid) from interop.

    Returns:
        list(geographic_msgs/Geopoint): The list of points that define the
            survey polygon.
    """
    message = rospy.wait_for_message(
        '/interop/mission_info/search_grid', GeoPolygonStamped, timeout=5.0)
    return message.polygon.points


def get_emergent_object_position():
    """Get the position of the emergent object from interop.

    Returns:
        geographic_msgs/GeoPoint: The position of the emergent object.
    """
    message = rospy.wait_for_message(
        '/interop/mission_info/emergent_obj', GeoPointStamped, timeout=5.0)
    return message.position


def generate_mission_task_msgs(waypoints, survey_polygon,
                               emergent_obj_position):
    """Generate the list of tasks for the mission.

    Args:
        waypoints (list(geographic_msgs/GeoPoint)): The list of waypoints.
        survey_polygon (list(geographic_msgs/GeoPoint)): The survey polygon.
        emergent_obj_position (geographic_msgs/GeoPoint): The position of the
            emergent object.

    Returns:
        list(mission/MissionTask): The list of mission tasks.
    """
    takeoff = MissionTask(
        task=MissionTask.TAKEOFF,
        param1=rospy.get_param("~takeoff_lat"),
        param2=rospy.get_param("~takeoff_long"),
        param3=rospy.get_param("~takeoff_alt"))

    waypoints_list = [
        MissionTask(
            task=MissionTask.WAYPOINT_CAPTURE,
            param1=waypoint.latitude,
            param2=waypoint.longitude,
            param3=waypoint.altitude,
            param4=rospy.get_param('~waypoint_acceptance_radius'),
            param5=rospy.get_param("~waypoint_widen_radius"),
            param6=rospy.get_param("~waypoint_widen_factor"))
        for waypoint in waypoints
    ]

    SURVEY_ALTITUDE = rospy.get_param('~survey_altitude')
    CAMERA_FOV = rospy.get_param('~camera_fov')
    survey_path = generate_coordinates(survey_polygon, SURVEY_ALTITUDE,
                                       CAMERA_FOV)
    survey_waypoints = [
        MissionTask(
            task=MissionTask.SURVEY,
            param1=lat,
            param2=lon,
            param3=alt,
            param4=rospy.get_param('~survey_acceptance_radius'),
            param5=rospy.get_param("~waypoint_widen_radius"),
            param6=rospy.get_param("~waypoint_widen_factor"))
        for (lat, lon, alt) in survey_path
    ]

    emergent_object = MissionTask(
        task=MissionTask.EMERGENT_OBJECT,
        param1=emergent_obj_position.latitude,
        param2=emergent_obj_position.longitude,
    )

    # Hardcoded landing guides are used to guide the aircraft to land in the
    # correct direction.
    landing_guide_1 = MissionTask(
        task=MissionTask.WAYPOINT_CAPTURE,
        param1=38.144513,  # Latitude.
        param2=-76.427784,  # Longitude.
        param3=40.0,  # Altitude.
        param4=10.0,  # Acceptance radius (metres).
        param5=rospy.get_param("~waypoint_widen_radius"),
        param6=rospy.get_param("~waypoint_widen_factor"))

    landing_guide_2 = MissionTask(
        task=MissionTask.WAYPOINT_CAPTURE,
        param1=38.145415,  # Latitude.
        param2=-76.428780,  # Longitude.
        param3=40.0,  # Altitude.
        param4=15.0,  # Acceptance radius (metres).
        param5=rospy.get_param("~waypoint_widen_radius"),
        param6=rospy.get_param("~waypoint_widen_factor"))

    # Note: all landing params will be ignored when using offboard mode.
    landing = MissionTask(
        task=MissionTask.LAND,
        param1=rospy.get_param("~land_lat"),
        param2=rospy.get_param("~land_long"),
        param3=rospy.get_param("~land_alt"),
        param4=rospy.get_param("~touchdown_lat"),
        param5=rospy.get_param("~touchdown_long"))

    return [takeoff] + waypoints_list + survey_waypoints + [emergent_object] + [
        landing_guide_1, landing_guide_2, landing
    ]


def load_from_interop_callback(request):
    """Callback for the load_from_interop service.

    Args:
        request (std_srvs/Trigger): Unused.

    Returns:
        std_srvs/TriggerResponse.
    """
    waypoints = get_waypoints()
    survey_polygon = get_survey_polygon()
    emergent_obj_position = get_emergent_object_position()

    # Generate the tasks that would complete the mission.
    task_list = generate_mission_task_msgs(waypoints, survey_polygon,
                                           emergent_obj_position)

    # Set the mission.
    result = set_mission_service(
        SetMissionRequest(start_from=1, mission_tasks=task_list))
    response = TriggerResponse()
    response.success = result.success
    response.message = result.message

    rospy.loginfo('Loaded mission from interop server')

    return response


if __name__ == '__main__':
    rospy.init_node('load_from_interop')

    # Set up service clients.
    service_name = '/mission/set_mission'
    rospy.wait_for_service(service_name)
    set_mission_service = rospy.ServiceProxy(service_name, SetMission)

    # Set up service server.
    rospy.Service('load_from_interop', Trigger, load_from_interop_callback)

    # Automatically load the mission.
    load_from_interop_callback(TriggerRequest())

    rospy.spin()
