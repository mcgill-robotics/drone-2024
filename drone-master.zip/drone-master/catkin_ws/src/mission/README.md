# Mission

For controlling a mission.

## ROS Publishers

* `/mission/inspect` (`mission/MissionPlan`): See the current mission
  and its current state.

## ROS Services

* `/mission/set_mission` (`mission/SetMission`): Load a mission into the mission
  controller.

* `/mission/load_from_interop` (`std_srvs/Trigger`): Load a mission directly from
  interop into the mission controller.

* `/mission/start_mission` (`std_srvs/Trigger`): Start the mission that has been
  loaded into the mission controller.

* `/mission/stop_mission` (`std_srvs/Trigger`): Stop the running mission.

* `/mission/set_current_task` (`mission/SetCurrentTask`): Set the current task
  in the mission.

## How to use

* Start the interop package (`roslaunch interop interop.launch`). Make sure that
  the interop node successfully connects to the interop server.
* Start the navigation package (`roslaunch navigation navigation.launch`).
* Start the simulation environment (`roslaunch drone_gazebo drone_gazebo.launch`).
* Start QGroundControl. The autopilot has to be in mission mode and armed
  before starting a mission.
* Start the mission package (`roslaunch mission mission.launch`).
