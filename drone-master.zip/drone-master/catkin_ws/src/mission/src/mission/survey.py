import math
import numpy as np

from transformers.points import ENUCoord


class Line(object):

    """Encapsulates a bounded straight line in slope-intercept form.
    Being bounded means that the line has a start point and an end point.
    i.e. The line does not extend to an infinite length.
    """

    def __init__(self, start_point, end_point):
        """Initialize a straight line bounded by two points.
        Args:
            start_point: The first point used to construct the line with.
            end_point: The second point used to construct the line with.
        """
        x0, y0 = start_point[0], start_point[1]
        x1, y1 = end_point[0], end_point[1]

        self.slope = float('nan')
        if x1 - x0 != 0:
            self.slope = (y1 - y0) / (x1 - x0)

        self.intercept = y0 - (self.slope * x0)

        self.x_min = min(x0, x1)
        self.x_max = max(x0, x1)

    def get_y_value(self, x):
        """Get the y value of the bounded straight line given an x.
        Args:
            x (int or float): The x coordinate.
        Returns:
            float: The y value given the x.
        Raises:
            ValueError: When there is no appropriate y value to return
                for the specified x either because the line is vertical,
                or because no y value exists for the x (no intersection
                because the x is out of bounds).
        """
        if math.isnan(self.slope):
            raise ValueError

        if (self.x_min <= x <= self.x_max):
            value = (self.slope * x) + self.intercept
            return value
        else:
            raise ValueError

    def __str__(self):
        s = "slope:{} \n intercept:{} \n x_min:{} \n x_max:{} \n".format(
            self.slope, self.intercept, self.x_min, self.x_max)
        return s

    def __repr__(self):
        return self.__str__()


class Map(object):

    """A set of lines representing a polygon."""

    def __init__(self, geopoints):
        """Initialize a representation of a polygon using a set of
        straight lines.
        Args:
            geopoints list(geometry_msgs/GeoPoint): The polygon to build the
                set of lines out of.
        """
        self.line_map = []
        for i in range(-1, len(geopoints) - 1):
            self.line_map.append(Line(geopoints[i], geopoints[i + 1]))

    def get_y_values(self, x):
        """Get the points of intersection (y values) between the vertical
        line (x) and the polygon.
        Args:
            x (int or float): The x position of the vertical line used
                to calculate the intersection with.
        Returns:
            list: Values corresponding to the intersections of the
                polygon and the vertical line (x).
        """
        values = []
        for line in self.line_map:
            try:
                value = line.get_y_value(x)
            except ValueError:
                pass
            else:
                values.append(value)
        return values


def generate_coordinates(geopoints, coverage_altitude, fov, overlap=0.2):
    """Given a coverage altitude and a camera field of view, generate
    coordinates to fly to in order for the camera to completely cover a
    coverage/survey geopoints. The generated coordinates result in a
    lawnmower search pattern.
    Args:
        geopoints list(geometry_msgs/GeoPoint): Polygon containing the coverage/
            survey area. The points defining the polygon are expected to
            be in lat/long coordinates.
        coverage_altitude (int or float): The altitude (in metres) that
            the drone should fly at during coverage/survey.
        fov (int or float): The field of view (in degrees) of the
            downward-facing survey camera.
    Yields:
        tuple: The next coordinate in the form (lat, lon, alt)
            that the drone should fly to.
    """
    coverage_width = (
        2. - overlap) * math.tan(math.radians(fov / 2.0)) * coverage_altitude

    # Convert the lat/long polygon points to local coordinates.
    ref_point = ENUCoord.ref_point_from_map_transform()
    coordinates = [
        ENUCoord.from_lla((geopoint.latitude, geopoint.longitude, 0), ref_point)
        for geopoint in geopoints
    ]

    coverage_map = Map(
        [(enu_point.x, enu_point.y) for enu_point in coordinates])

    # Get the points with the smallest and largest x values.
    min_x = min(coordinates, key=lambda point: point.x).x
    max_x = max(coordinates, key=lambda point: point.x).x

    # Special handling for the case where the coverage width is wide enough
    # for the whole polygon to be covered within one north-south or
    # south-north flight path.
    if (min_x + coverage_width) >= max_x:
        x = (min_x + max_x) / 2.
        all_y_values = coverage_map.get_y_values(x)
        if all_y_values:
            significant_y_values = [min(all_y_values), max(all_y_values)]

            # Convert back to lat/lon.
            for y in significant_y_values:
                point = ENUCoord(x, y, 0, q=[0, 0, 0, 1])
                lat, lon, _ = ENUCoord.to_lla(point, ref_point)
                yield (lat, lon, coverage_altitude)
    else:
        # Flag for whether or not to reverse the order of the y values generated.
        # Needed because a top-to-bottom path section must be followed
        # by a horizontal path section, and then a bottom-to-top path section
        # to produce a path that has the shape of a square wave function.
        reverse = False
        start = min_x + coverage_width / 2.
        end = max_x

        for x in np.linspace(start, end, (end - start) / coverage_width):
            all_y_values = coverage_map.get_y_values(x)
            if all_y_values:
                # The points in between the minimum and the maximum are not useful
                # in this algorithm.Jenkins ver. 2.138.2
                significant_y_values = [min(all_y_values), max(all_y_values)]
                if reverse:
                    significant_y_values.reverse()

                for y in significant_y_values:
                    point = ENUCoord(x, y, 0, q=[0, 0, 0, 1])
                    lat, lon, _ = ENUCoord.to_lla(point, ref_point)
                    yield (lat, lon, coverage_altitude)

                reverse = not reverse
