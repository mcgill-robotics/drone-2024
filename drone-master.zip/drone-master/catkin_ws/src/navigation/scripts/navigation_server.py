#!/usr/bin/env python
"""ROS action server for navigation (making the aircraft move)."""

import rospy
import actionlib
from navigation.autopilot import Autopilot
from navigation.autopilot_tasks import (
    OffboardTakeoff, MissionTakeoff, OffboardWaypointCapture,
    MissionWaypointCapture, OffboardLanding, MissionLanding)
from navigation.msg import Navigation, NavigationAction, NavigationResult


class NavigationServer(object):

    def __init__(self, autopilot, offboard=False):
        """
        Args:
            autopilot (navigation.autopilot.Autopilot): An instance of the
                Autopilot class that has already been 'connected' to the
                physical autopilot.
        """
        self.autopilot = autopilot
        self.server = actionlib.SimpleActionServer(
            '~navigation', NavigationAction, self.callback, False)
        self.server.start()
        self.offboard = offboard

    def callback(self, goal):
        """Callback for the action server."""
        result = NavigationResult()

        # If the autopilot is not yet connected.
        if not self.autopilot.is_connected():
            result.success = False
            self.server.set_aborted(result, 'Autopilot is not yet connected.')
            return

        # Dispatch based on the kind of navigation action requested.
        if goal.navigation.task == Navigation.TAKEOFF:
            # No need to takeoff if aircraft is already in the air.
            if self.autopilot.is_in_air():
                rospy.logwarn(
                    'Skipping takeoff because the aircraft is already in the air.'
                )
                result.success = True
                self.server.set_succeeded(result, 'Takeoff skipped.')
                return
            else:
                if self.offboard:
                    task = OffboardTakeoff(
                        self.autopilot, goal.navigation.param1,
                        goal.navigation.param2, goal.navigation.param3)
                else:
                    task = MissionTakeoff(
                        self.autopilot, goal.navigation.param1,
                        goal.navigation.param2, goal.navigation.param3)
        elif goal.navigation.task == Navigation.WAYPOINT_CAPTURE:
            if self.offboard:
                task = OffboardWaypointCapture(
                    self.autopilot, goal.navigation.param1,
                    goal.navigation.param2, goal.navigation.param3,
                    goal.navigation.param4, goal.navigation.param5,
                    goal.navigation.param6)
            else:
                task = MissionWaypointCapture(
                    self.autopilot, goal.navigation.param1,
                    goal.navigation.param2, goal.navigation.param3,
                    goal.navigation.param4)
        elif goal.navigation.task == Navigation.LAND:
            if self.offboard:
                task = OffboardLanding(
                    self.autopilot, goal.navigation.param1,
                    goal.navigation.param2, goal.navigation.param3,
                    goal.navigation.param4, goal.navigation.param5)
            else:
                task = MissionLanding(
                    self.autopilot, goal.navigation.param1,
                    goal.navigation.param2, goal.navigation.param3,
                    goal.navigation.param4, goal.navigation.param5)
        else:
            # Not a recognized navigation task.
            error_message = '{} is not a valid navigation task.'.format(
                goal.navigation.task)
            rospy.logerr(error_message)
            result.success = False
            self.server.set_aborted(result, error_message)
            return

        # Start task.
        try:
            task.start()
        except self.autopilot.NotInMissionMode:
            rospy.loginfo('Could not start task. Not in mission mode.')
            result.success = False
            self.server.set_aborted(result, 'Autopilot not in mission mode.')
            return
        except self.autopilot.CommandRejected:
            rospy.loginfo(
                'Could not start task. Command rejected by autopilot.')
            result.success = False
            self.server.set_aborted(result, 'Command rejected.')
            return

        # Wait for completion of the task.
        rate = rospy.Rate(20)  # Unit: Hz.
        while not rospy.is_shutdown():
            # Step the task.
            task.spin_once()

            # Check for goal abortion, or if a new goal was submitted.
            if self.server.is_preempt_requested():
                try:
                    task.abort()
                except Autopilot.AutopilotException:
                    pass

                rospy.loginfo('Task preempted.')
                result.success = False
                self.server.set_preempted(result, 'Task preempted.')
                return

            # Check for task completion.
            status = task.get_status()
            if status == task.COMPLETED:
                rospy.loginfo('Task completed.')
                result.success = True
                self.server.set_succeeded(result, 'Task completed.')
                return
            elif status == task.IN_PROGRESS:
                rate.sleep()
                continue
            elif status == task.NOT_IN_MISSION_MODE:
                rospy.logerr(
                    'Could not complete task. Autopilot not in mission mode.')
                result.success = False
                self.server.set_aborted(result,
                                        'Autopilot not in mission mode.')
                return
            elif status == task.MISSION_CHANGED:
                rospy.logerr(
                    'Could not complete task. Autopilot waypoint table '
                    'unexpectedly changed.')
                result.success = False
                self.server.set_aborted(result,
                                        'Autopilot waypoint table changed.')
                return
            elif status == task.COMMAND_REJECTED:
                rospy.logerr(
                    'Could not complete task. Additional commands rejected '
                    'by the autopilot.')
                result.success = False
                self.server.set_aborted(result, 'Command rejected.')
                return
            else:
                fatal_message = 'Unrecognized status: {}.'.format(status)
                rospy.logfatal(fatal_message)
                result.success = False
                self.server.set_aborted(result, fatal_message)
                return


if __name__ == '__main__':
    rospy.init_node('~server')
    offboard_autopilot = rospy.get_param("~offboard_autopilot")

    autopilot = Autopilot()

    # Start the navigation server.
    navigation_server = NavigationServer(autopilot, offboard=offboard_autopilot)

    rospy.spin()
