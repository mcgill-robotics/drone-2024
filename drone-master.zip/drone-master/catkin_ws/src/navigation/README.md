# Navigation

For navigating the aircraft in mission mode.

```bash
roslaunch navigation navigation.launch
```

## ROS Actions

`Navigation.action`: Make the aircraft move. The aircraft must be armed and in
mission mode.

* For takeoff:
    * task: `TAKEOFF`.
    * param1: latitude of the point to aim for (in degrees).
    * param2: longitude of the point to aim for (in degrees).
    * param3: altitude of the point to aim for (in metres).
* For waypoint captures:
    * task: `WAYPOINT_CAPTURE`.
    * param1: latitude of the point to go to (in degrees).
    * param2: longitude of the point to go to (in degrees).
    * param3: altitude of the point to go to (in metres).
* For landing:
    * task: `LAND`.
    * param1: latitude of the point to go to right before starting the descent (in degrees).
    * param2: longitude of the point to go to right before starting the descent (in degrees).
    * param3: altitude of the point to go to right before starting the descent (in metres).
    * param4: latitude of the touchdown point on the ground (in degrees).
    * param5: longitude of the touchdown point on the ground (in degrees).

## How to use

First, start the simulation environment
(`roslaunch drone_gazebo drone_gazebo.launch`) and QGroundControl.

Then, start this package:
```bash
roslaunch navigation navigation.launch
```

Ensure that the aircraft is armed and is in mission mode before sending goals to
the navigation action server.

To send a navigation goal from the command line, enter this first, then press
tab for autocompletion:

```bash
rosptopic pub /navigation/server/goal navigation/NavigationActionGoal
```

Fill in the fields (task, param1, param2, etc.), then press Enter to send
a goal to the navigation action server.
