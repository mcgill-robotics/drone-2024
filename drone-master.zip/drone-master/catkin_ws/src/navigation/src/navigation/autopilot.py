"""Functions for interacting with the autopilot.
Provides functions for obtaining information and functions for sending
instructions.
"""

import copy
import threading
import rospy
import numpy as np
from six.moves import map, zip
from sensor_msgs.msg import NavSatFix
from mavros_msgs.msg import State, ExtendedState, WaypointList, Altitude
from mavros_msgs.srv import WaypointPush
from transformers.points import ENUCoord


class Autopilot(object):

    """For direct interaction with the autopilot when in mission mode.
    This is meant to be a singleton class (i.e. there should be only one
    instance of this class).
    """

    # MAVLink command IDs.
    # Reference: MAV_CMD at https://mavlink.io/en/messages/common.html
    MAV_CMD_NAV_WAYPOINT = 16
    MAV_CMD_NAV_LOITER_UNLIM = 17
    MAV_CMD_NAV_LAND = 21
    MAV_CMD_NAV_TAKEOFF = 22

    # Mavros topic and service names.
    # Reference: https://wiki.ros.org/mavros
    STATE_TOPIC = '/mavros/state'
    EXTENDED_STATE_TOPIC = '/mavros/extended_state'
    LOCATION_TOPIC = '/mavros/global_position/global'
    WAYPOINTS_LIST_TOPIC = '/mavros/mission/waypoints'
    ALTITUDE_TOPIC = '/mavros/altitude'

    WAYPOINTS_PUSH_SERVICE = '/mavros/mission/push'

    _state_lock = threading.Lock()
    _extended_state_lock = threading.Lock()
    _location_lock = threading.Lock()
    _waypoints_list_lock = threading.Lock()
    _altitudes_lock = threading.Lock()

    _waypoints_push_lock = threading.RLock()  # Note: re-entrant lock.

    # Define exceptions.
    class AutopilotException(Exception):

        """Base class for exceptions related to the autopilot."""
        pass

    class NotInMissionMode(AutopilotException):

        """Used to signal that the autopilot is not in mission mode."""
        pass

    class CommandRejected(AutopilotException):

        """Used to signal that the autopilot has rejected a command.
        e.g. When a call to a mavros service returns a result of 'success: False'.
        """
        pass

    def __init__(self):
        """Set up subscribers for obtaining information from the autopilot,
        and set up service clients.
        """

        self.ref_point = ENUCoord.ref_point_from_map_transform()
        self._state_msg = None
        self._extended_state_msg = None
        self._location_msg = None
        self._waypoints_list_msg = None
        self._altitudes_msg = None

        # Set up mavros subscribers...
        rospy.Subscriber(self.STATE_TOPIC, State, self._state_cb)
        rospy.Subscriber(self.EXTENDED_STATE_TOPIC, ExtendedState,
                         self._extended_state_cb)
        rospy.Subscriber(self.LOCATION_TOPIC, NavSatFix, self._location_cb)
        rospy.Subscriber(self.WAYPOINTS_LIST_TOPIC, WaypointList,
                         self._waypoints_list_cb)
        rospy.Subscriber(self.ALTITUDE_TOPIC, Altitude, self._altitude_cb)

        # Set up service clients.
        # Set up the service client used for sending waypoint tables
        # (i.e instructions) to the autopilot.
        rospy.wait_for_service(self.WAYPOINTS_PUSH_SERVICE)
        self._waypoints_service = rospy.ServiceProxy(
            self.WAYPOINTS_PUSH_SERVICE, WaypointPush)

    def is_connected(self):
        """Whether or not all the self._*_msg variables have received an
        initial value from the autopilot.

        Returns:
            bool: True if all the expected initial values from the autopilot
                have been received, False otherwise.
        """
        msgs_received = map(
            lambda msg: msg is not None,
            [
                self._state_msg,
                self._extended_state_msg,
                self._location_msg,  # Requires GPS.
                self._waypoints_list_msg,
                self._altitudes_msg
            ])
        return all(msgs_received)

    ## Subscriber callbacks.
    def _state_cb(self, msg):
        """Callback for the subscription to /mavros/state.

        Args:
            msg (mavros_msgs/State).
        """
        with self._state_lock:
            self._state_msg = msg

    def _extended_state_cb(self, msg):
        """Callback for the subscription to /mavros/extended_state.

        Args:
            msg (mavros_msgs/ExtendedState).
        """
        with self._extended_state_lock:
            self._extended_state_msg = msg

        if msg.landed_state == ExtendedState.LANDED_STATE_UNDEFINED:
            rospy.logerr("Landed state is unknown.")

    def _location_cb(self, msg):
        """Callback for the subscription to /mavros/global_position/global.

        Args:
            msg (sensor_msgs/NavSatFix).
        """
        with self._location_lock:
            self._location_msg = msg

    def _waypoints_list_cb(self, msg):
        """Callback for the subscription to /mavros/mission/waypoints.

        Args:
            msg (mavros_msgs/WaypointList).
        """
        with self._waypoints_list_lock:
            self._waypoints_list_msg = msg

    def _altitude_cb(self, msg):
        """Callback for the subscription to /mavros/mission/waypoints

        Args:
            msg (mavros_msgs/Altitude)
        """
        with self._altitudes_lock:
            self._altitudes_msg = msg

    ## Functions for getting information from the autopilot.
    def get_relative_altitude(self):
        """
        Get the relative altitude of the plane.

        Returns:
            Relative altitude of the plane.
        """
        return self._altitudes_msg.relative

    def get_amsl_altitude(self):
        """
        Get the amsl altitude of the plane.

        Returns:
            Absoloute(AMSL) altitude of the plane.
        """
        return self._altitudes_msg.amsl

    def get_location(self):
        """Returns the GPS coordinates of the autopilot.

        Returns:
            tuple(float, float, float): The GPS coordinates of the autopilot
                in the form (latitude, longitude, altitude). Latitude and
                longitude are in degrees, and altitude is in metres.
        """
        with self._location_lock:
            # self._location_msg type: sensor_msgs/NavSatFix.
            return (self._location_msg.latitude, self._location_msg.longitude,
                    self._altitudes_msg.amsl)

    def get_waypoints(self):
        """Returns the autopilot's waypoint table.

        Returns:
            list(mavros_msgs/Waypoint): The autopilot's waypoint table.
        """
        with self._waypoints_list_lock:
            # self._waypoints_list_msg type: mavros_msgs/WaypointList.
            return copy.deepcopy(self._waypoints_list_msg.waypoints)

    ## Functions for getting the state of the autopilot.
    def is_armed(self):
        """Whether or not the autopilot is armed.

        Returns:
            bool: True if autopilot is armed, False if autopilot is disarmed.
        """
        with self._state_lock:
            # self._state_msg type: mavros_msgs/State.
            return self._state_msg.armed

    def is_in_mission_mode(self):
        """Whether or not the autopilot is in mission mode.

        Returns:
            bool: True is the flight mode is 'mission', False otherwise.
        """
        with self._state_lock:
            # self._state_msg type: mavros_msgs/State.
            return self._state_msg.mode == 'AUTO.MISSION'

    def is_in_manual_mode(self):
        """Whether or not the autopilot flight mode is manual.

        Returns:
            bool: True if the flight mode is 'manual', False otherwise.
        """
        with self._state_lock:
            # self._state_msg type: mavros_msgs/State.
            return self._state_msg.mode == 'MANUAL'

    ## Functions for querying the state of the aircraft.
    def is_in_air(self):
        """Whether or not the aircraft is in the air.
        Note that takeoff and the descent during landing do not count as being
        'in the air'.

        Returns:
            bool: True if the aircraft is in the air, False otherwise.
        """
        with self._extended_state_lock:
            # self._extended_state_msg type: mavros_msgs/ExtendedState.
            return (self._extended_state_msg.landed_state ==
                    ExtendedState.LANDED_STATE_IN_AIR)

    def is_landing(self):
        """Whether or not the aircraft is in the process of landing
        (i.e. has started its descent).

        Returns:
            bool: True if the aircraft is in the process of landing, False
                otherwise.
        """
        with self._extended_state_lock:
            # self._extended_state_msg type: mavros_msgs/ExtendedState.
            return (self._extended_state_msg.landed_state ==
                    ExtendedState.LANDED_STATE_LANDING)

    def is_landed(self):
        """Whether or not the aircraft has landed.

        Returns:
            bool: True if the aircraft has landed. False if the aircraft
                is not landed, or if the autopilot does not know.
        """
        with self._extended_state_lock:
            # self._extended_state_msg type: mavros_msgs/ExtendedState.
            return (self._extended_state_msg.landed_state ==
                    ExtendedState.LANDED_STATE_ON_GROUND)

    ## Functions for comparing Waypoints (type: mavros_msgs/Waypoint).
    def is_waypoint_equal(self, waypoint_a, waypoint_b):
        """Checks if two waypoints have the same commands and coordinates.

        Args:
            waypoint_a (mavros_msgs/Waypoint): The first waypoint involved
                in the comparison.
            waypoint_b (mavros_msgs/Waypoint): The second waypoint involved
                in the comparison.

        Returns:
            bool: True if waypoint_a and waypoint_b have the same command and
                coordinates, False otherwise.
        """
        # np.isclose is used to compare floats instead of == because floats may
        # not be exactly equal.
        return (waypoint_a.command == waypoint_b.command and
                np.isclose(waypoint_a.x_lat, waypoint_b.x_lat) and
                np.isclose(waypoint_a.y_long, waypoint_b.y_long) and
                np.isclose(waypoint_a.z_alt, waypoint_b.z_alt))

    def is_waypoint_list_equal(self, list_a, list_b):
        """Whether or not two waypoint lists contain the same waypoints
        (mavros_msgs/Waypoint) in the same order.
        Waypoints are considered equal if they have the same command and the
        same coordinates.

        Args:
            list_a (list(mavros_msgs/Waypoint)): List of waypoints.
            list_b (list(mavros_msgs/Waypoint)): List of waypoints.

        Returns:
            bool: True if list_a and list_b contain the same waypoints in the
                same order, False otherwise.
        """
        if len(list_a) != len(list_b):
            return False

        # Compare the elements of the two lists.
        return all(
            map(lambda a_b: self.is_waypoint_equal(*a_b), zip(list_a, list_b)))

    ## Functions for making the aircraft move.
    def push_waypoints(self, waypoints):
        """
        Send a list of waypoints (i.e instructions) to the autopilot.

        Args:
            waypoints (list(mavros_msgs/Waypoint)): List of waypoints to send
                to the autopilot.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode. If the
                autopilot is not in mission mode, this class will not be able to
                make the aircraft move. This class was designed to be used only
                in mission mode.
            Autopilot.CommandRejected: The list of waypoints was rejected by the
                autopilot.
        """
        with self._waypoints_push_lock:
            if not self.is_in_mission_mode():
                raise self.NotInMissionMode

            # Make a ROS service call.
            output = self._waypoints_service(waypoints=waypoints)

            if output.success:
                # Block until all the self._*_msg variables update through mavros
                # subscribers to reflect the waypoint list just sent through the
                # ROS service call.
                while not rospy.is_shutdown():
                    current_waypoint_table = self.get_waypoints()

                    # Once the submitted waypoints and the waypoint table as known by
                    # this class are equal, unblock.
                    if self.is_waypoint_list_equal(waypoints,
                                                   current_waypoint_table):
                        break
            else:
                raise self.CommandRejected

    def push_waypoints_if(self, test, waypoints):
        """Test a condition and send waypoints to the autopilot only if that
        condition is fulfilled.
        This function exists so that a test and a waypoint push can be performed
        atomically.

        Args:
            test (function): The test that determines whether or not to push
                the given waypoints. This function must take no arguments,
                and must return a bool. If the returned bool is True, the
                waypoints will be pushed. If the returned bool is False, the
                waypoints will not be pushed.
            waypoints (list(mavros_msgs/Waypoint)): List of waypoints to send
                to the autopilot if the test is True.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode. If the
                autopilot is not in mission mode, this class will not be able to
                make the aircraft move. This class was designed to be used only
                in mission mode.
            Autopilot.CommandRejected: The list of waypoints was rejected by the
                autopilot.
        """
        with self._waypoints_push_lock:
            predicate = test()
            assert type(predicate) is bool  # Sanity check.

            if predicate:
                # This is why a re-entrant lock is used. The same lock
                # (self._waypoints_push_lock) is used again in
                # self.push_waypoints().
                self.push_waypoints(waypoints)
