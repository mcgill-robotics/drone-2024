"""Functions for making the aircraft takeoff, do waypoint captures, and land."""

import abc
import copy
import six
import rospy
import tf
import numpy as np

from threading import Lock
from math import sin, cos
from pyproj import Proj, transform
from autopilot import Autopilot
from transformers.points import ENUCoord
from geometry_msgs.msg import PoseStamped
from std_srvs.srv import SetBool
from mavros_msgs.msg import Waypoint, PositionTarget


def try_lookup_state():
    listener = tf.TransformListener()
    while not rospy.is_shutdown():
        try:
            return listener.lookupTransform("map", "base_link", rospy.Time(0))
        except:
            rospy.logwarn_throttle(1, "Waiting for map to base_link transform")
            continue


def build_msg(ref_point, goal_altitude, distance):
    position, quaternion = try_lookup_state()
    msg = PositionTarget()
    msg.position.z = -goal_altitude
    _, _, yaw = tf.transformations.euler_from_quaternion(quaternion)
    x = cos(yaw) * distance + position[0]
    y = sin(yaw) * distance + position[0]

    inv_rot = tf.transformations.quaternion_inverse(ref_point.q)
    tmp = tf.transformations.quaternion_multiply(inv_rot,
                                                 [x, y, -goal_altitude, 0.0])
    tr = tf.transformations.quaternion_multiply(
        tmp, tf.transformations.quaternion_conjugate(inv_rot))[:3]

    translated = [tr[0] + ref_point.x, tr[1] + ref_point.y, tr[2] + ref_point.z]

    lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
    ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")

    lon, lat, _ = transform(
        ecef, lla, translated[0], translated[1], translated[2], radians=False)

    msg.position.x = lat
    msg.position.y = lon

    return msg


def generate_takeoff_waypoints(lat, lon, alt):
    """Generate the waypoints needed for a takeoff that heads towards the
    given (latitude, longitude, altitude).

    Args:
        lat (float): Latitude (in degrees) of the point to head towards on
            takeoff (i.e. the takeoff waypoint).
        lon (float): Longitude (in degrees) of the takeoff waypoint.
        alt (float): Altitude (in metres) of the takeoff waypoint.

    Returns:
        list(mavros_msgs/Waypoint): The list of waypoints for a takeoff.
    """
    takeoff_waypoint = Waypoint(
        command=Autopilot.MAV_CMD_NAV_TAKEOFF,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        is_current=True,
        # Move to the next waypoint (dummy waypoint) when completed.
        autocontinue=True,
        x_lat=lat,
        y_long=lon,
        z_alt=alt)

    # Dummy loiter waypoint with same coordinates as the takeoff waypoint.
    dummy_waypoint = Waypoint(
        command=Autopilot.MAV_CMD_NAV_LOITER_UNLIM,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        autocontinue=True,
        x_lat=lat,
        y_long=lon,
        z_alt=alt)

    return [takeoff_waypoint, dummy_waypoint]


def generate_capture_waypoints(lat, lon, alt):
    """Generate waypoints needed for a waypoint capture.

    Args:
        lat (float): Latitude (in degrees) of the point to capture.
        lon (float): Longitude (in degrees) of the point to go to.
        alt (float): Altitude (in metres) of the point to go to.

    Returns:
        list(mavros_msgs/Waypoint): The list of waypoints needed to perform
            the waypoint capture.
    """
    waypoint = Waypoint(
        command=Autopilot.MAV_CMD_NAV_WAYPOINT,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        is_current=True,
        # Move to the next waypoint (dummy waypoint) when completed.
        autocontinue=True,
        x_lat=lat,
        y_long=lon,
        z_alt=alt)

    dummy_waypoint = Waypoint(
        command=Autopilot.MAV_CMD_NAV_LOITER_UNLIM,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        autocontinue=True,
        x_lat=lat,
        y_long=lon,
        z_alt=alt)

    return [waypoint, dummy_waypoint]


def generate_landing_waypoints(start_lat, start_lon, start_alt, touchdown_lat,
                               touchdown_lon):
    """Generate waypoints needed for a landing.

    Args:
        start_lat (float): Latitude (in degrees) of the point to go to right
            before starting the descent.
        start_lon (float): Longitude (in degrees) of the point to go to right
            before starting the descent.
        start_alt (float): Altitude (in metres) of the point to go to right
            before starting the descent.
        touchdown_lat (float): Latitude (in degrees) of the touchdown point
            on the ground.
        touchdown_lon (float): Longitude (in degrees) of the touchdown point
            on the ground.

    Returns:
        list(mavros_msgs/Waypoint): The list of waypoints needed for a landing.
    """
    # Coordinates to go to before starting the descent.
    waypoint = Waypoint(
        command=Autopilot.MAV_CMD_NAV_WAYPOINT,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        is_current=True,
        autocontinue=True,
        x_lat=start_lat,
        y_long=start_lon,
        z_alt=start_alt)

    # Where the touchdown should be.
    touchdown_point = Waypoint(
        command=Autopilot.MAV_CMD_NAV_LAND,
        frame=Waypoint.FRAME_GLOBAL_REL_ALT,
        is_current=False,
        autocontinue=True,
        x_lat=touchdown_lat,
        y_long=touchdown_lon)

    return [waypoint, touchdown_point]


@six.add_metaclass(abc.ABCMeta)
class AutopilotAction(object):

    COMPLETED = 'COMPLETED'
    IN_PROGRESS = 'IN_PROGRESS'
    NOT_IN_MISSION_MODE = 'NOT_IN_MISSION_MODE'
    MISSION_CHANGED = 'MISSION_CHANGED'
    COMMAND_REJECTED = 'COMMAND_REJECTED'

    # Force all classes inheriting from this class to implement all methods
    # in this class.
    @abc.abstractmethod
    def start(self):
        raise NotImplementedError

    @abc.abstractmethod
    def abort(self):
        raise NotImplementedError

    @abc.abstractmethod
    def get_status(self):
        raise NotImplementedError

    @abc.abstractmethod
    def spin_once(self):
        raise NotImplementedError


class OffboardTakeoff(AutopilotAction):

    def __init__(self, autopilot, lat, lon, alt):
        """
        Takes off the plane in a straight line
        """
        self.takeoff_distance = rospy.get_param("~takeoff_distance")
        self.takeoff_acceptance_altitude = rospy.get_param(
            "~takeoff_min_altitude")
        self.takeoff_altitude = rospy.get_param("~takeoff_altitude")
        self.autopilot = autopilot
        self.publisher = rospy.Publisher(
            "/mavros/setpoint_raw/local", PositionTarget, queue_size=10)
        self.msg = None
        self.start_srv = rospy.ServiceProxy(
            "/planner/dwa_planner/toggle_publish", SetBool)

    def start(self):
        """Takeoff.

        Raises:
            Autopilot.CommandRejected: The command was rejected.
        """
        self.start_srv(False)
        self.msg = build_msg(self.autopilot.ref_point, self.takeoff_altitude,
                             self.takeoff_distance)
        self.msg.type_mask = 0x11f8

    def abort(self):
        """Cancel the takeoff by starting to loiter in the current location.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The abort was rejected.
        """
        pass

    def get_status(self):
        """Returns the status of the takeoff.

        Returns:
            str: The status of the takeoff.
        """
        if self.autopilot.get_relative_altitude(
        ) > self.takeoff_acceptance_altitude:
            self.start_srv(True)
            return self.COMPLETED
        return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        if not self.msg:
            return
        self.publisher.publish(self.msg)


class OffboardWaypointCapture(AutopilotAction):

    def __init__(self, autopilot, lat, lon, alt, acceptance_radius,
                 widen_radius, widening_factor):
        """
        Args:
            autopilot (navigation.Autopilot): Instance of the Autopilot class.
            lat (float): Latitude (in degrees) of the point to head towards on
                takeoff (i.e. the takeoff waypoint).
            lon (float): Longitude (in degrees) of the takeoff waypoint.
            alt (float): Altitude (in metres) of the takeoff waypoint.
        """
        self.autopilot = autopilot
        self.waypoint = ENUCoord.from_lla([lat, lon, alt], autopilot.ref_point)

        self.publisher = rospy.Publisher(
            "/planner/dwa_planner/target", PoseStamped, queue_size=10)

        self.current_target_pub = rospy.Subscriber(
            "/planner/dwa_planner/current_target", PoseStamped,
            self.current_target_cb)
        self._current_target_lock = Lock()
        self.current_target = None

        self.acceptance_radius = acceptance_radius
        self.widen_radius = widen_radius
        self.listener = tf.TransformListener()
        self.start_srv = rospy.ServiceProxy(
            "/planner/dwa_planner/toggle_publish", SetBool)

        self.start_widening = False
        self.widening_factor = widening_factor
        self.prev_distance = 0
        self.decreased = False

        self.republish = True

    def start(self):
        """Start the waypoint capture."""
        self.start_srv(True)
        self.msg = PoseStamped()
        self.msg.header.stamp = rospy.get_rostime()
        self.msg.header.frame_id = "map"
        self.msg.pose.position.x = self.waypoint.x
        self.msg.pose.position.y = self.waypoint.y
        self.msg.pose.position.z = self.waypoint.z
        self.msg.pose.orientation.w = 1
        self.publisher.publish(self.msg)

    def abort(self):
        """Cancel the waypoint capture by starting to loiter in the
        current location."""
        pass

    def current_target_cb(self, msg):
        with self._current_target_lock:
            self.current_target = msg

    def get_status(self):
        """Returns the status of the waypoint capture.

        Returns:
            str: The status of the waypoint capture.
        """
        try:
            position, rotation = self.listener.lookupTransform(
                "map", "base_link", rospy.Time(0))
        except Exception as e:
            rospy.logwarn("Error fetching current position: {}".format(str(e)))
            return self.IN_PROGRESS

        distance = ((position[0] - self.waypoint.x)**2 +
                    (position[1] - self.waypoint.y)**2 +
                    (position[2] - self.waypoint.z)**2)

        if self.start_widening and self.decreased and distance > self.prev_distance:
            self.acceptance_radius *= self.widening_factor
            self.decreased = False
        elif self.start_widening and distance < self.prev_distance:
            self.decreased = True

        if distance < self.acceptance_radius**2:
            return self.COMPLETED
        elif distance < self.widen_radius**2 and not self.start_widening:
            self.decreased = True
            self.start_widening = True

        self.prev_distance = distance
        return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        if self.current_target:
            with self._current_target_lock:
                curr_targ = self.current_target.pose.position

            close = np.isclose(
                [curr_targ.x, curr_targ.y, curr_targ.z],
                [self.waypoint.x, self.waypoint.y, self.waypoint.z],
                atol=0.01).all()

            if close and self.republish:
                self.republish = False

        if self.republish:
            self.msg.header.stamp = rospy.get_rostime()
            self.publisher.publish(self.msg)


class OffboardLanding(AutopilotAction):

    def __init__(self, autopilot, start_lat, start_lon, start_alt,
                 touchdown_lat, touchdown_lon):
        """
        Args:
            autopilot (navigation.Autopilot): Instance of the Autopilot class.
        """
        self.land_lat = touchdown_lat
        self.land_lon = touchdown_lon
        self.landing_distance = rospy.get_param("~landing_distance")
        self.autopilot = autopilot
        self.publisher = rospy.Publisher(
            "/mavros/setpoint_raw/local", PositionTarget, queue_size=10)

        self.start_srv = rospy.ServiceProxy(
            "/planner/dwa_planner/toggle_publish", SetBool)

    def start(self):
        """Start landing."""
        self.start_srv(False)
        self.msg = PositionTarget()
        self.msg.position.x = self.land_lat
        self.msg.position.y = self.land_lon
        self.msg.position.z = 0
        self.msg.type_mask = 0x21f8

    def abort(self):
        """Cancel the landing by starting to loiter in the current location."""
        pass

    def get_status(self):
        """Returns the status of the landing.

        Returns:
            str: The status of the landing.
        """
        return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        if not self.msg:
            return

        self.publisher.publish(self.msg)


class MissionTakeoff(AutopilotAction):

    def __init__(self, autopilot, lat, lon, alt):
        """A takeoff waypoint is a waypoint that the aircraft immediately heads
        towards on takeoff.

        Args:
            autopilot (navigation.Autopilot): Instance of the Autopilot class.
            lat (float): Latitude (in degrees) of the point to head towards on
                takeoff (i.e. the takeoff waypoint).
            lon (float): Longitude (in degrees) of the takeoff waypoint.
            alt (float): Altitude (in metres) of the takeoff waypoint.
        """
        self.autopilot = autopilot

        # For takeoff, the second waypoint in the autopilot's waypoint table
        # can be made the dummy waypoint.
        self.DUMMY_WAYPOINT_INDEX = 1

        # Generate waypoints needed for takeoff.
        self.waypoints = generate_takeoff_waypoints(lat, lon, alt)

    def _get_waypoints(self):
        """Returns the takeoff waypoints.

        Returns:
            list(mavros_msgs/Waypoint): The takeoff waypoints.
        """
        return copy.deepcopy(self.waypoints)

    def _waypoint_table_has_current_task(self):
        """Whether or not the autopilot's waypoint table contains the takeoff
        waypoint.
        Normally, the waypoint table will contain the takeoff waypoints once
        they are sent, but it is possible for the waypoint table to be modified
        externally (i.e outside of this ROS node), which can make this class
        very confused if there are no checks like this function.

        Returns:
            bool: True if the autopilot's waypoint table contains the takeoff
                waypoints sent. False otherwise.
        """
        autopilot_waypoints = self.autopilot.get_waypoints()
        return self.autopilot.is_waypoint_list_equal(autopilot_waypoints,
                                                     self._get_waypoints())

    def start(self):
        """Takeoff.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The command was rejected.
        """
        # Push the takeoff waypoints to the autopilot.
        self.autopilot.push_waypoints(self._get_waypoints())

    def abort(self):
        """Cancel the takeoff by starting to loiter in the current location.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The abort was rejected.
        """
        (lat, lon, alt) = self.autopilot.get_location()  # Current location.

        loiter_waypoint = Waypoint(
            command=self.autopilot.MAV_CMD_NAV_LOITER_UNLIM,
            frame=Waypoint.FRAME_GLOBAL_REL_ALT,
            is_current=True,
            x_lat=lat,
            y_long=lon,
            z_alt=alt)

        # Push loiter waypoint (i.e. abort this task) only if we are sure that
        # the current waypoint table contains this task. (If we don't check, we
        # may accidentally cancel other tasks).
        self.autopilot.push_waypoints_if(
            lambda: self._waypoint_table_has_current_task(),  # Notice the delayed evaluation.
            [loiter_waypoint])

    def get_status(self):
        """Returns the status of the takeoff.

        Returns:
            str: The status of the takeoff.
        """
        if not self.autopilot.is_in_mission_mode():
            return self.NOT_IN_MISSION_MODE

        if not self._waypoint_table_has_current_task():
            return self.MISSION_CHANGED

        autopilot_waypoints = self.autopilot.get_waypoints()
        if autopilot_waypoints[self.DUMMY_WAYPOINT_INDEX].is_current:
            return self.COMPLETED
        else:
            return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        pass


class MissionWaypointCapture(AutopilotAction):

    def __init__(self, autopilot, lat, lon, alt, acceptance_radius):
        """
        Args:
            autopilot (navigation.Autopilot): Instance of the Autopilot class.
            lat (float): Latitude (in degrees) of the point to head towards on
                takeoff (i.e. the takeoff waypoint).
            lon (float): Longitude (in degrees) of the takeoff waypoint.
            alt (float): Altitude (in metres) of the takeoff waypoint.
        """
        self.autopilot = autopilot

        # For takeoff, the second waypoint in the autopilot's waypoint table
        # can be made the dummy waypoint.
        self.DUMMY_WAYPOINT_INDEX = 1

        # Generate waypoints for a waypoint capture.
        self.waypoints = generate_capture_waypoints(lat, lon, alt)

    def _get_waypoints(self):
        """Returns the autopilot waypoints used for the waypoint capture.

        Returns:
            list(mavros_msgs/Waypoint): The waypoints used to achieve the
                waypoint capture.
        """
        return copy.deepcopy(self.waypoints)

    def _waypoint_table_has_current_task(self):
        """Whether or not the autopilot's waypoint table contains the waypoints
        needed for the waypoint capture.
        Normally, the waypoint table will contain the waypoints once
        they are sent, but it is possible for the waypoint table to be modified
        externally (i.e outside of this ROS node), which can make this class
        very confused if there are no checks like this function.

        Returns:
            bool: True if the autopilot's waypoint table contains the waypoints
                needed to perform the waypoint capture. False otherwise.
        """
        autopilot_waypoints = self.autopilot.get_waypoints()
        return self.autopilot.is_waypoint_list_equal(autopilot_waypoints,
                                                     self._get_waypoints())

    def start(self):
        """Start the waypoint capture.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The command was rejected.
        """
        # Push the waypoints needed for the waypoint capture.
        self.autopilot.push_waypoints(self._get_waypoints())

    def abort(self):
        """Cancel the waypoint capture by starting to loiter in the
        current location.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The abort was rejected.
        """
        (lat, lon, alt) = self.autopilot.get_location()  # Current location.

        loiter_waypoint = Waypoint(
            command=self.autopilot.MAV_CMD_NAV_LOITER_UNLIM,
            frame=Waypoint.FRAME_GLOBAL_REL_ALT,
            is_current=True,
            x_lat=lat,
            y_long=lon,
            z_alt=alt)

        # Push loiter waypoint (i.e. abort this task) only if we are sure that
        # the current waypoint table contains this task. (If we don't check, we
        # may accidentally cancel other tasks).
        self.autopilot.push_waypoints_if(
            lambda: self._waypoint_table_has_current_task(), [loiter_waypoint])

    def get_status(self):
        """Returns the status of the waypoint capture.

        Returns:
            str: The status of the waypoint capture.
        """
        if not self.autopilot.is_in_mission_mode():
            return self.NOT_IN_MISSION_MODE

        if not self._waypoint_table_has_current_task():
            return self.MISSION_CHANGED

        autopilot_waypoints = self.autopilot.get_waypoints()
        if autopilot_waypoints[self.DUMMY_WAYPOINT_INDEX].is_current:
            return self.COMPLETED
        else:
            return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        pass


class MissionLanding(AutopilotAction):

    def __init__(self, autopilot, start_lat, start_lon, start_alt,
                 touchdown_lat, touchdown_lon):
        """
        Args:
            autopilot (navigation.Autopilot): Instance of the Autopilot class.
            start_lat (float): Latitude (in degrees) of the point to go to right
                before starting the descent.
            start_lon (float): Longitude (in degrees) of the point to go to right
                before starting the descent.
            start_alt (float): Altitude (in metres) of the point to go to right
                before starting the descent.
            touchdown_lat (float): Latitude (in degrees) of the touchdown point
                on the ground.
            touchdown_lon (float): Longitude (in degrees) of the touchdown point
                on the ground.
        """
        self.autopilot = autopilot
        # Generate waypoints for landing.
        self.waypoints = generate_landing_waypoints(
            start_lat, start_lon, start_alt, touchdown_lat, touchdown_lon)

    def _get_waypoints(self):
        """Returns the autopilot waypoints used for the landing.

        Returns:
            list(mavros_msgs/Waypoint): The waypoints used for landing.
        """
        return copy.deepcopy(self.waypoints)

    def _waypoint_table_has_current_task(self):
        """Whether or not the autopilot's waypoint table contains the waypoints
        needed for the landing.
        Normally, the waypoint table will contain the waypoints once
        they are sent, but it is possible for the waypoint table to be modified
        externally (i.e outside of this ROS node), which can make this class
        very confused if there are no checks like this function.

        Returns:
            bool: True if the autopilot's waypoint table contains the waypoints
                needed for landing. False otherwise.
        """
        autopilot_waypoints = self.autopilot.get_waypoints()
        return self.autopilot.is_waypoint_list_equal(autopilot_waypoints,
                                                     self._get_waypoints())

    def start(self):
        """Start landing.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The command was rejected.
        """
        # Push the waypoints needed for landing.
        self.autopilot.push_waypoints(self._get_waypoints())

    def abort(self):
        """Cancel the landing by starting to loiter in the current location.

        Raises:
            Autopilot.NotInMissionMode: The autopilot is not in mission mode.
            Autopilot.CommandRejected: The abort was rejected.
        """
        (lat, lon, alt) = self.autopilot.get_location()  # Current location.

        loiter_waypoint = Waypoint(
            command=self.autopilot.MAV_CMD_NAV_LOITER_UNLIM,
            frame=Waypoint.FRAME_GLOBAL_REL_ALT,
            is_current=True,
            x_lat=lat,
            y_long=lon,
            z_alt=alt)

        # Push loiter waypoint (i.e. abort this task) only if we are sure that
        # the current waypoint table contains this task. (If we don't check, we
        # may accidentally cancel other tasks).
        self.autopilot.push_waypoints_if(
                lambda: self._waypoint_table_has_current_task() and not self.autopilot.is_landed(),
                [loiter_waypoint])

    def get_status(self):
        """Returns the status of the landing.

        Returns:
            str: The status of the landing.
        """
        if not self.autopilot.is_in_mission_mode():
            return self.NOT_IN_MISSION_MODE

        if not self._waypoint_table_has_current_task():
            return self.MISSION_CHANGED

        if self.autopilot.is_landed():
            return self.COMPLETED
        else:
            return self.IN_PROGRESS

    def spin_once(self):
        """Runs one iteration of the task."""
        pass
