"""A cubic spline segment representation."""

import rospy
from state_estimation.msg import Spline


class SplineEvaluator(object):

    """Cubic spline segment representation."""

    def __init__(self, c0, c1, c2, c3, t0):
        """Constructs a SplineEvaluator.

        S(t) = c0 + c1 * (t - t0) + c2 * (t - t0)^2 + c3 * (t - t0)^3.

        Args:
            c0 (float): Constant coefficient.
            c1 (float): First order coefficient.
            c2 (float): Second order coefficient.
            c3 (float): Third order coefficient.
            t0 (float): Time offset in seconds.
        """
        self.c0 = c0
        self.c1 = c1
        self.c2 = c2
        self.c3 = c3
        self.t0 = t0

    @classmethod
    def from_msg(cls, msg):
        """Constructs a Spline from a SplineSegment message.

        Args:
            msg (Spline): ROS message.

        Returns:
            SplineEvaluator object.
        """
        return cls(msg.c0, msg.c1, msg.c2, msg.c3, msg.t0.to_sec())

    def to_msg(self):
        """Constructs a Spline message."""
        msg = Spline()
        msg.c0 = self.c0
        msg.c1 = self.c1
        msg.c2 = self.c2
        msg.c3 = self.c3
        msg.t0 = rospy.Time.from_sec(self.t0)
        return msg

    def eval(self, t):
        """Evaluates the spline at time t.

        Args:
            t (float): Time in seconds.

        Returns:
            Evaluation of spline (float).
        """
        t -= self.t0
        return self.c0 + t * (self.c1 + t * (self.c2 + t * self.c3))
