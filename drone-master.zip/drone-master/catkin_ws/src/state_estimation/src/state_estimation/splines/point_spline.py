"""Three-dimensional cubic spline segment representation."""

from spline import SplineEvaluator
from state_estimation.msg import PointSpline


class PointSplineEvaluator(object):

    """Three-dimensional cubic spline segment representation."""

    def __init__(self, x, y, z):
        """Constructs a PointSplineEvaluator.

        Args:
            x (Spline): x coordinate spline segment [m].
            y (Spline): y coordinate spline segment [m].
            z (Spline): z coordinate spline segment [m].
        """
        self.x_spline = x
        self.y_spline = y
        self.z_spline = z

    @classmethod
    def from_msg(cls, msg):
        """Constructs a PointSplineEvaluator from a PointSpline message.

        Args:
            msg (PointSpline): ROS message.

        Returns:
            PointSplineEvaluator object.
        """
        x_spline = SplineEvaluator.from_msg(msg.x_spline)
        y_spline = SplineEvaluator.from_msg(msg.y_spline)
        z_spline = SplineEvaluator.from_msg(msg.z_spline)
        return cls(x_spline, y_spline, z_spline)

    def to_msg(self):
        """Constructs a PointSpline message."""
        msg = PointSpline()
        msg.x_spline = self.x_spline.to_msg()
        msg.y_spline = self.y_spline.to_msg()
        msg.z_spline = self.z_spline.to_msg()
        return msg

    def eval(self, t):
        """Evaluates the spline at time t.

        Args:
            t (float): Time in seconds.

        Returns:
            Point spline x, y and z as (float, float, float).
        """
        return (self.x_spline.eval(t), self.y_spline.eval(t),
                self.z_spline.eval(t))
