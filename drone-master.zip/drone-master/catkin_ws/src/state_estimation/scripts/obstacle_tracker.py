#!/usr/bin/env python
"""Tracks and predicts moving obstacle paths."""

import rospy
import numpy as np
from nav_msgs.msg import Path
from transformers.points import ENUCoord
from geometry_msgs.msg import PoseStamped
from interop.msg import GeoSphereArrayStamped
from state_estimation.msg import PointSpline, PointSplineArrayStamped
from state_estimation.splines import PointSplineEvaluator, SplineEvaluator


class ObstacleTracker(object):

    """Obstacle tracker."""

    def __init__(self, radius, queue_size):
        """Constructs an ObstacleTracker.

        Args:
            radius (float): Obstacle radius.
            queue_size (int): Maximum number of past measurements to use in
                estimation.
        """
        self._radius = radius
        self._queue_size = queue_size

        # Queues.
        self._index = 0
        self._count = 0
        self._t = np.zeros((queue_size, 1), dtype=np.float64)
        self._x_Y = np.zeros((queue_size, 1), dtype=np.float64)
        self._y_Y = np.zeros((queue_size, 1), dtype=np.float64)
        self._z_Y = np.zeros((queue_size, 1), dtype=np.float64)

        # Prediction.
        self.point_spline = PointSplineEvaluator(
            SplineEvaluator(0, 0, 0, 0, 0), SplineEvaluator(0, 0, 0, 0, 0),
            SplineEvaluator(0, 0, 0, 0, 0))

    @property
    def is_ready(self):
        """Whether the tracker has filled its buffer."""
        return self._count == self._queue_size

    def reset(self):
        """Resets the internal state of the estimator."""
        # Clear queues.
        self._t.fill(0)
        self._x_Y.fill(0)
        self._y_Y.fill(0)
        self._z_Y.fill(0)
        self._index = 0
        self._count = 0

    def update(self, x, y, z, t):
        """Updates the state and predictions of the tracker.

        Args:
            x (float): X coordinate of the obstacle at time t in meters.
            y (float): Y coordinate of the obstacle at time t in meters.
            z (float): Z coordinate of the obstacle at time t in meters.
            t (float): Time in seconds.
        """
        # Update state.
        self._t[self._index] = t
        self._x_Y[self._index] = x
        self._y_Y[self._index] = y
        self._z_Y[self._index] = z

        # Update index and count.
        self._count = min(self._count + 1, self._queue_size)
        self._index = (self._index + 1) % self._queue_size

        if not self.is_ready:
            # Not enough data for a meaningful estimate.
            return

        # Update time offset.
        offset = t
        t = self._t - offset

        # Solve for spline coefficients with least squares.
        A = np.hstack([np.ones((self._queue_size, 1)), t, t**2, t**3])
        mat = np.linalg.pinv(A.T.dot(A)).dot(A.T)
        x_spline = SplineEvaluator(*mat.dot(self._x_Y), t0=offset)
        y_spline = SplineEvaluator(*mat.dot(self._y_Y), t0=offset)
        z_spline = SplineEvaluator(*mat.dot(self._z_Y), t0=offset)
        self.point_spline = PointSplineEvaluator(x_spline, y_spline, z_spline)


def cb(msg, cb_args):
    """Callback for moving obstacles prediction.

    Args:
        msg (interop/GeoSphereArrayStamped): Moving obstacles message.
        cb_args ([ObstacleTracker], Publisher, ENUCoord, int): Additional
            callback arguments.
    """
    trackers, pub, ref, queue_size = cb_args
    if not trackers:
        # Initialize trackers now that we know how many trackers are needed.
        # This assumes the obstacles list will always have the same order.
        for obstacle in msg.spheres:
            trackers.append(ObstacleTracker(obstacle.radius, queue_size))

    # Update trackers.
    point_spline_array = PointSplineArrayStamped()
    point_spline_array.header.stamp = msg.header.stamp
    point_spline_array.header.frame_id = "map"
    curr_t = point_spline_array.header.stamp.to_sec()
    for tracker, obstacle in zip(trackers, msg.spheres):
        lla = (obstacle.center.latitude, obstacle.center.longitude,
               obstacle.center.altitude)
        point = ENUCoord.from_lla(lla, ref)
        tracker.update(point.x, point.y, point.z, curr_t)

        if not tracker.is_ready:
            # Only publish when all trackers are ready.
            # We can't only publish ready ones since their index matters.
            # This is okay though because all trackers will be ready at the
            # same time anyway.
            return

        point_spline = tracker.point_spline.to_msg()
        point_spline_array.point_splines.append(point_spline)

    pub.publish(point_spline_array)


if __name__ == "__main__":
    rospy.init_node("~obstacle_tracker")
    queue_size = int(rospy.get_param("~queue_size", 100))

    trackers = []
    pub = rospy.Publisher("~predictions", PointSplineArrayStamped, queue_size=1)
    ref = ENUCoord.ref_point_from_map_transform()

    rospy.Subscriber(
        '/interop/obstacles/moving',
        GeoSphereArrayStamped,
        cb,
        queue_size=1,
        callback_args=(
            trackers,
            pub,
            ref,
            queue_size,
        ))

    rospy.spin()
