#!/usr/bin/env python
"""State estimation ROS package."""

from distutils.core import setup
from catkin_pkg.python_setup import generate_distutils_setup

__author__ = "Anass Al"

d = generate_distutils_setup(
    packages=["state_estimation"], package_dir={"": "src"})

setup(**d)
