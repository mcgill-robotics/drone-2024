# TF Tree

This package builds and broadcasts the `tf` tree of the robot.

Check out the docs [here](https://drone.mcgillrobotics.com/packages/tf_tree).

