#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""TF tree broadcaster."""

import rospy
import numpy as np
import tf2_ros as tf2
import message_filters
import tf.transformations
from functools import partial
from mavros_msgs.msg import Altitude
from transformers import ENUTransformer
from sensor_msgs.msg import NavSatFix, Imu
from geographic_msgs.msg import GeoPointStamped
from geometry_msgs.msg import QuaternionStamped, TransformStamped
from interop.msg import (GeoCylinderArrayStamped, GeoSphereArrayStamped,
                         WayPoints)


def broadcast_gimbal_orientation(msg, cb_args):
    """Broadcasts the gimbal_ref->* transformations.

    Args:
        msg (QuaternionStamped): Gimbal orientation message.
        cb_args (TransformBroadcaster, str): Additional callback arguments.
    """
    br, child_frame_id = cb_args

    transform_stamped = TransformStamped()
    transform_stamped.header = msg.header
    transform_stamped.child_frame_id = child_frame_id

    quaternion = [
        msg.quaternion.x,
        msg.quaternion.y,
        msg.quaternion.z,
        msg.quaternion.w,
    ]
    pitch, roll, _ = tf.transformations.euler_from_quaternion(
        quaternion, axes="syxz")
    orientation = tf.transformations.quaternion_from_euler(
        pitch, roll, 0, axes="syxz")
    transform_stamped.transform.rotation.x = orientation[0]
    transform_stamped.transform.rotation.y = orientation[1]
    transform_stamped.transform.rotation.z = orientation[2]
    transform_stamped.transform.rotation.w = orientation[3]

    br.sendTransform(transform_stamped)


def is_finite_transform(transform):
    """Verifies that a transform's translation and rotations are finite.

    Args:
        transform (TransformStamped): Transform message.

    Returns:
        True if finite, False otherwise.
    """
    finite = np.isfinite([
        transform.transform.translation.x,
        transform.transform.translation.y,
        transform.transform.translation.z,
        transform.transform.rotation.x,
        transform.transform.rotation.y,
        transform.transform.rotation.z,
        transform.transform.rotation.w,
    ]).all()

    if not finite:
        rospy.logwarn_throttle(5.0, "{} -> {} transform is not finite".format(
            transform.header.frame_id, transform.child_frame_id))

    return finite


def generic_broadcaster(br, msg_handler, *args):
    """Generic transform broadcast handler.

    Args:
        br (TransformBroadcaster): Transformation broadcaster.
        msg_handler(*args -> TransformStamped | [TransformStamped]): Message
            handler.
        *args: Additional positional arguments.
    """
    try:
        transform = msg_handler(*args)
    except Exception as e:
        rospy.logerr_throttle(5.0, str(e))
        return

    if hasattr(transform, "__iter__"):
        for t in transform:
            if is_finite_transform(t):
                br.sendTransform(t)
    elif is_finite_transform(transform):
        br.sendTransform(transform)


if __name__ == "__main__":
    # Initialize node.
    rospy.init_node("tf_tree")

    # Get topic names.
    home_topic = rospy.get_param("~home_topic")
    gps_topic = rospy.get_param("~gps_topic")
    gimbal_camera_topic = rospy.get_param("~gimbal_camera_topic")
    gimbal_controller_topic = rospy.get_param("~gimbal_controller_topic")
    imu_topic = rospy.get_param("~imu_topic")
    alt_topic = rospy.get_param("~alt_topic")

    air_drop_topic = rospy.get_param("~air_drop_topic")
    emergent_topic = rospy.get_param("~emergent_topic")
    off_axis_topic = rospy.get_param("~off_axis_topic")
    stat_obs_topic = rospy.get_param("~stationary_obs_topic")
    waypoints_topic = rospy.get_param("~waypoints_topic")

    use_rostime = rospy.get_param("~use_rostime")

    # Wait for home and create the ENU broadcaster.
    home = rospy.wait_for_message(home_topic, GeoPointStamped).position
    enu_tr = ENUTransformer(
        [home.latitude, home.longitude, home.altitude], use_rostime=use_rostime)

    # Setup static home transform.
    s_br = tf2.StaticTransformBroadcaster()
    t = enu_tr.get_origin_transform()
    s_br.sendTransform(t)

    # Create the broadcasters.
    br = tf2.TransformBroadcaster()
    broadcast_air_drop = partial(generic_broadcaster, br,
                                 partial(
                                     enu_tr.get_geo_point_transform,
                                     frame_id="ground",
                                     child_frame_id="air_drop"))
    broadcast_emergent = partial(generic_broadcaster, br,
                                 partial(
                                     enu_tr.get_geo_point_transform,
                                     frame_id="ground",
                                     child_frame_id="emergent_obj"))
    broadcast_off_axis = partial(generic_broadcaster, br,
                                 partial(
                                     enu_tr.get_geo_point_transform,
                                     frame_id="ground",
                                     child_frame_id="off_axis_obj"))
    broadcast_baselink = partial(generic_broadcaster, br,
                                 enu_tr.get_baselink_transform)
    broadcast_gimbal_ref = partial(generic_broadcaster, br,
                                   enu_tr.get_gimbal_ref_transform)
    broadcast_ground = partial(generic_broadcaster, br,
                               enu_tr.get_ground_transform)
    broadcast_stat_obs = partial(generic_broadcaster, br,
                                 enu_tr.get_stat_obs_transform)
    broadcast_waypoints = partial(generic_broadcaster, br,
                                  enu_tr.get_waypoints_transform)

    # Setup subscribers.
    rospy.Subscriber(
        air_drop_topic, GeoPointStamped, broadcast_air_drop, queue_size=10)
    rospy.Subscriber(alt_topic, Altitude, broadcast_ground, queue_size=10)
    rospy.Subscriber(
        emergent_topic, GeoPointStamped, broadcast_emergent, queue_size=10)
    rospy.Subscriber(
        gimbal_camera_topic,
        QuaternionStamped,
        broadcast_gimbal_orientation,
        callback_args=(br, "gimbal_link"),
        queue_size=10)
    rospy.Subscriber(
        gimbal_controller_topic,
        QuaternionStamped,
        broadcast_gimbal_orientation,
        callback_args=(br, "gimbal_controller"),
        queue_size=10)
    rospy.Subscriber(
        off_axis_topic, GeoPointStamped, broadcast_off_axis, queue_size=10)
    rospy.Subscriber(
        stat_obs_topic,
        GeoCylinderArrayStamped,
        broadcast_stat_obs,
        queue_size=10)
    rospy.Subscriber(
        waypoints_topic, WayPoints, broadcast_waypoints, queue_size=10)
    rospy.Subscriber(
        imu_topic, Imu, callback=broadcast_gimbal_ref, queue_size=10)

    imu_sub = message_filters.Subscriber(imu_topic, Imu)
    gps_sub = message_filters.Subscriber(gps_topic, NavSatFix)
    alt_sub = message_filters.Subscriber(alt_topic, Altitude)
    ts = message_filters.ApproximateTimeSynchronizer(
        [imu_sub, gps_sub, alt_sub], 10, 0.1)
    ts.registerCallback(broadcast_baselink)

    # Spin forever.
    rospy.spin()
