#!/usr/bin/env python
import rospy
import tf
import unittest
import rostest
from mavros_msgs.msg import Altitude
from transformers import ENUTransformer
from pyproj import transform, Proj, Geod
from sensor_msgs.msg import NavSatFix, Imu
from geometry_msgs.msg import Quaternion
from geographic_msgs.msg import GeoPoint, GeoPointStamped
from interop.msg import (WayPoints, GeoSphereArrayStamped,
                         GeoCylinderArrayStamped, GeoSphere, GeoPolygonStamped,
                         GeoCylinder, FlyZoneArray, FlyZone)


class TestTransforms(unittest.TestCase):

    def setUp(self):
        self.home = [0, 0, 0]
        self.transformer = ENUTransformer(self.home)

    def rotate(self, pnt, quat):
        pnt = list(pnt) + [0.0]
        tmp = tf.transformations.quaternion_multiply(quat, pnt)
        return tf.transformations.quaternion_multiply(
            tmp, tf.transformations.quaternion_conjugate(quat))

    def test_ecef_map(self):
        t = self.transformer.get_origin_transform()

        pnt = [0, 0, 50]

        quat = [
            t.transform.rotation.x, t.transform.rotation.y,
            t.transform.rotation.z, t.transform.rotation.w
        ]
        x, y, z, _ = self.rotate(pnt,
                                 tf.transformations.quaternion_inverse(quat))

        x += t.transform.translation.x
        y += t.transform.translation.y
        z += t.transform.translation.z

        lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        tp = transform(ecef, lla, x, y, z, radians=False)

        self.assertAlmostEqual(tp[0], 0, places=2)
        self.assertAlmostEqual(tp[1], 0, places=2)
        self.assertAlmostEqual(tp[2], 50, places=2)

    def test_map_geo_point(self):
        test_geo = GeoPointStamped()
        test_geo.position = GeoPoint(
            latitude=self.home[0] + 0.5,
            longitude=self.home[1] + 0.5,
            altitude=self.home[2])
        lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        x, y, z = transform(
            lla,
            ecef,
            test_geo.position.latitude,
            test_geo.position.longitude,
            test_geo.position.altitude,
            radians=False)
        t = self.transformer.get_geo_point_transform(test_geo, "map", "test")

        self.assertAlmostEqual(z, t.transform.translation.y, places=2)
        self.assertAlmostEqual(y, t.transform.translation.x, places=2)
        self.assertAlmostEqual(
            x - Geod(ellps="WGS84").a, t.transform.translation.z, places=2)
        self.assertEqual("test", t.child_frame_id)

    def test_map_waypoints(self):
        test_wps = WayPoints()
        test_wp = GeoPoint(
            latitude=self.home[0] + 0.5,
            longitude=self.home[1] + 0.5,
            altitude=self.home[2])
        test_wps.waypoints.append(test_wp)
        lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        x, y, z = transform(
            lla,
            ecef,
            test_wp.latitude,
            test_wp.longitude,
            test_wp.altitude,
            radians=False)
        t = self.transformer.get_waypoints_transform(test_wps)[0]

        self.assertAlmostEqual(z, t.transform.translation.y, places=2)
        self.assertAlmostEqual(y, t.transform.translation.x, places=2)
        self.assertAlmostEqual(
            x - Geod(ellps="WGS84").a, t.transform.translation.z, places=2)

    def test_odom_baselink(self):
        x, y, z = self.home
        base_link = NavSatFix(latitude=x + 1, longitude=y + 1, altitude=z)
        altitude = Altitude(amsl=z + 50)
        orientation = Quaternion(x=0, y=0, z=0, w=1)
        imu = Imu(orientation=orientation)

        lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        x, y, z = transform(
            lla,
            ecef,
            base_link.latitude,
            base_link.longitude,
            altitude.amsl,
            radians=False)

        t = self.transformer.get_baselink_transform(imu, base_link, altitude)
        self.assertAlmostEqual(z, t.transform.translation.y, places=2)
        self.assertAlmostEqual(y, t.transform.translation.x, places=2)
        self.assertAlmostEqual(
            x - Geod(ellps="WGS84").a, t.transform.translation.z, places=2)
        self.assertEqual(t.transform.rotation, orientation)

    def test_stat_obs(self):
        x, y, z = self.home
        stat_obs = GeoCylinderArrayStamped()
        test_pnt = GeoPoint(latitude=x, longitude=y, altitude=z)
        test_obs = GeoCylinder(center=test_pnt, height=50)
        stat_obs.cylinders.append(test_obs)

        lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        x, y, z = transform(
            lla,
            ecef,
            test_pnt.latitude,
            test_pnt.longitude,
            test_pnt.altitude,
            radians=False)

        t = self.transformer.get_stat_obs_transform(stat_obs)[0]
        self.assertEqual(0, t.transform.translation.x)
        self.assertEqual(0, t.transform.translation.y)
        self.assertEqual(0, t.transform.translation.z)


if __name__ == "__main__":
    rospy.init_node("test")
    rostest.unitrun("tf_tree", "tf_test", TestTransforms)
