import tf
import rospy
import numpy as np
import tf2_ros as tf2
from std_msgs.msg import Header
from points import ENUCoord
from geometry_msgs.msg import TransformStamped, Vector3, Quaternion


class ENUTransformer(object):

    """Transformer for ENU frames"""

    def __init__(self, origin, use_rostime=False):
        """Constructs an ENUTransformer.

        Args:
            origin: A reference point for the ENU frame.
            use_rostime: Whether to use the current ROS time when stamping the
                transforms (True) or the corresponding message's timestamp
                (False).
        """
        self.origin = ENUCoord.ref_point_from_lla(origin)
        self.use_rostime = use_rostime

    def get_origin_transform(self):
        """Gets the earth->map transform."""
        return self._get_point_transform(self.origin, "earth", "map",
                                         rospy.get_rostime())

    def get_geo_point_transform(self, geo_point, frame_id, child_frame_id):
        """Gets the transform for a GeoPointStamped message.

        Args:
            geo_point: A GeoPointStamped message.
            frame_id: Frame of the transform.
            child_frame_id: Child frame of the transform.

        Returns:
            TransformStamped.
        """
        lla = [
            geo_point.position.latitude, geo_point.position.longitude,
            geo_point.position.altitude
        ]
        pnt = ENUCoord.from_lla(lla, self.origin)
        return self._get_point_transform(pnt, frame_id, child_frame_id,
                                         geo_point.header.stamp)

    def get_stat_obs_transform(self, cylinder_array):
        """Gets the tranforms for the stationary obstacles.

        Args:
            cylinder_array: A GeoCylinderArrayStamped message.

        Returns:
            TransformStamped list.
        """
        hdr_frame = "map"
        time_stamp = cylinder_array.header.stamp
        tr_obs = []
        for i, cylinder in enumerate(cylinder_array.cylinders):
            child_frame = "obstacles/stationary/{:d}".format(i + 1)
            lla = [
                cylinder.center.latitude, cylinder.center.longitude,
                cylinder.center.altitude
            ]
            pnt = ENUCoord.from_lla(lla, self.origin)
            tr_obs.append(
                self._get_point_transform(pnt, hdr_frame, child_frame,
                                          time_stamp))
        return tr_obs

    def get_waypoints_transform(self, waypoints):
        """Gets the transforms for the stationary obstacles.

        Args:
            waypoints: A WayPoints message.

        Returns:
            TransformStamped list.
        """
        hdr_frame = "map"
        time_stamp = waypoints.header.stamp
        tr_wp = []
        for i, wp in enumerate(waypoints.waypoints):
            child_frame = "waypoints/{:d}".format(i + 1)
            lla = [wp.latitude, wp.longitude, wp.altitude]
            pnt = ENUCoord.from_lla(lla, self.origin)
            tr_wp.append(
                self._get_point_transform(pnt, hdr_frame, child_frame,
                                          time_stamp))
        return tr_wp

    def get_baselink_transform(self, imu_data, navsatfix, altitude):
        """Gets the odom->baselink transform.

        Args:
            imu_data (Imu): An Imu message.
            navsatfix (NavSatFix): A NavSatFix message.
            altitude (Altitude): An Altitude message.

        Returns:
            TransformStamped.
        """
        loc = [navsatfix.latitude, navsatfix.longitude, altitude.amsl]
        pnt = ENUCoord.from_lla(loc, self.origin)
        base_link_tr = self._get_point_transform(pnt, "odom", "base_link",
                                                 navsatfix.header.stamp)
        base_link_tr.transform.rotation = imu_data.orientation

        return base_link_tr

    def get_gimbal_ref_transform(self, imu_data):
        """Gets the gimbal->gimbal_ref transform.

        Args:
            imu_data (Imu): An Imu message.

        Returns:
            TransformStamped.
        """
        # Remove pitch and roll from plane.
        roll, pitch, _ = tf.transformations.euler_from_quaternion([
            imu_data.orientation.x, imu_data.orientation.y,
            imu_data.orientation.z, imu_data.orientation.w
        ])
        rot = tf.transformations.quaternion_from_euler(-roll, -pitch, 0)

        gimbal_ref_tr = TransformStamped()
        gimbal_ref_tr.header = self._create_hdr(imu_data.header.stamp, "gimbal")

        gimbal_ref_tr.child_frame_id = "gimbal_ref"
        gimbal_ref_tr.transform.rotation.x = rot[0]
        gimbal_ref_tr.transform.rotation.y = rot[1]
        gimbal_ref_tr.transform.rotation.z = rot[2]
        gimbal_ref_tr.transform.rotation.w = rot[3]

        return gimbal_ref_tr

    def get_ground_transform(self, altitude):
        """Gets the map->ground transform.

        Args:
            altitude (Altitude): An Altitude message.

        Returns:
            TransformStamped.
        """
        tr = TransformStamped()
        tr.header = self._create_hdr(altitude.header.stamp, "map")
        tr.child_frame_id = "ground"
        tr.transform.translation.z = altitude.amsl - altitude.relative

        if not np.isfinite(tr.transform.translation.z):
            raise ValueError("Ground altitude is undefined")

        tr.transform.rotation.w = 1.0
        return tr

    def _create_hdr(self, time_stamp, frame):
        if self.use_rostime:
            time_stamp = rospy.get_rostime()
        header = Header()
        header.stamp = time_stamp
        header.frame_id = frame
        return header

    def _get_point_transform(self, pnt, hdr_frame, child_frame, time_stamp):
        t = TransformStamped()
        t.header = self._create_hdr(time_stamp, hdr_frame)
        t.child_frame_id = child_frame
        t.transform.translation = self._enu_point_to_translation(pnt)
        t.transform.rotation = self._quat_array_to_msg(pnt.q)
        return t

    def _enu_point_to_translation(self, pnt):
        return Vector3(x=pnt.x, y=pnt.y, z=pnt.z)

    def _quat_array_to_msg(self, q):
        return Quaternion(*q)
