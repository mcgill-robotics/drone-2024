import rospy
import tf2_ros
import numpy as np
from pyproj import Proj, transform
from tf.transformations import (quaternion_conjugate, quaternion_multiply,
                                quaternion_from_matrix, quaternion_inverse)


def _rotate(x, q):
    """ Rotate x by quaternion q """
    q_ = quaternion_conjugate(q)
    x = np.concatenate((x, [0.]))
    x = quaternion_multiply(q, x)
    x = quaternion_multiply(x, q_)
    return x[:3]


class ENUCoord(object):

    """ENU coordinate."""

    def __init__(self, x, y, z, q):
        self.x = x
        self.y = y
        self.z = z
        self.q = q

    def to_array(self):
        return np.array([self.x, self.y, self.z])

    @classmethod
    def from_lla(cls, lla_point, ref_point):
        """Creates an ENUCoord with reference to the ref_point.

        Args:
            lla_point: A iterable with (lat, lon, alt).
            ref_point: A reference ENUCoord, to calculate distance from.

        Returns:
            A ENU Point.
        """
        # Convert to ECEF.
        lla = Proj(proj="latlong", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        xyz = transform(
            lla, ecef, lla_point[1], lla_point[0], lla_point[2], radians=False)

        # Calculate translation.
        enu_point = np.subtract(xyz, ref_point.to_array())

        # Apply rotation.
        v = _rotate(enu_point, ref_point.q)

        return ENUCoord(*v, q=[0, 0, 0, 1])

    @classmethod
    def to_lla(cls, enu_point, ref_point):
        """Returns a ENUCoord with reference to ref_point back to a latlong.

        Args:
            enu_point(ENUCoord): A point in ENU w.r.t ref_point.
            ref_point(ENUCoord): Reference for the enu_point.

        Returns:
            A tuple (lat, lon, alt) of the enu_point

        Note: This is the inverse of the from_lla function, however, the values
              may not correspond exactly due to precision errors.
        """
        rotation = quaternion_inverse(ref_point.q)
        point = _rotate(enu_point.to_array(), rotation)
        point = ref_point.to_array() + point

        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        lla = Proj(proj="latlong", ellps="WGS84", datum="WGS84")
        longitude, latitude, altitude = transform(
            ecef, lla, point[0], point[1], point[2], radians=False)

        return latitude, longitude, altitude

    @classmethod
    def ref_point_from_map_transform(cls):
        """Creates a reference point at the location of the map frame.

        Note: This must run in a ROS node.
        """
        rate = rospy.Rate(10.0)
        tf_buffer = tf2_ros.Buffer()
        listener = tf2_ros.TransformListener(tf_buffer)
        while not rospy.is_shutdown():
            try:
                transform = tf_buffer.lookup_transform("earth", "map",
                                                       rospy.Time(0))
                break
            except (tf2_ros.LookupException, tf2_ros.ConnectivityException,
                    tf2_ros.ExtrapolationException):
                rate.sleep()
                rospy.logwarn_throttle(1.0,
                                       "Waiting for earth to map transform")
                continue

        return cls.ref_point_from_transform(transform.transform)

    @classmethod
    def ref_point_from_lla(cls, ref_point):
        """Creates an ENUCoord that is with reference to the center of earth.

        Args:
            origin: Origin point in lla.

        Returns:
            An ENUPoint with reference to the center of earth.
        """
        lla = Proj(proj="latlong", ellps="WGS84", datum="WGS84")
        ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")
        x, y, z = transform(
            lla, ecef, ref_point[1], ref_point[0], ref_point[2], radians=False)
        q = cls.get_ecef_orientation(ref_point)
        return ENUCoord(x, y, z, q)

    @classmethod
    def ref_point_from_transform(cls, transform):
        """ Creates a reference point from the given tf transform

        Args:
            transform: The TF transform to be used for the reference.
                       Should be in ECEF. eg: earth->map transform.

        Returns:
            An ENUCoord with reference to the center of the earth
        """
        q = [
            transform.rotation.x,
            transform.rotation.y,
            transform.rotation.z,
            transform.rotation.w,
        ]
        pnt = ENUCoord(transform.translation.x, transform.translation.y,
                       transform.translation.z, q)
        return pnt

    @classmethod
    def get_ecef_orientation(cls, lla_point):
        """ Retrieves the rotation for this coordinate for ECEF -> ENU.

        Args:
            lla_point: The lat long alt of this point,

        Returns:
            A quaternion representing the rotation.
        """
        latitude, longitude, _ = lla_point
        latitude = np.deg2rad(latitude)
        longitude = np.deg2rad(longitude)
        sin_lat = np.sin(latitude)
        sin_lon = np.sin(longitude)
        cos_lat = np.cos(latitude)
        cos_lon = np.cos(longitude)

        # yapf: disable
        M = np.array([
            [          -sin_lon,            cos_lon,       0, 0],
            [-sin_lat * cos_lon, -sin_lat * sin_lon, cos_lat, 0],
            [ cos_lon * cos_lat,  sin_lon * cos_lat, sin_lat, 0],
            [                 0,                  0,       0, 1],
        ])
        # yapf: enable

        return quaternion_from_matrix(M)
