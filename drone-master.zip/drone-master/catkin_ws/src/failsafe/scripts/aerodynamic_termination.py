#! /usr/bin/env python

import rospy
import operator
from threading import Lock
from mavros_msgs.msg import RCIn
from mavros_msgs.srv import CommandLong, CommandLongRequest


class BaseOverride(object):

    """Base override class."""

    def triggered(self):
        """Whether the override was triggered or not."""
        raise NotImplementedError


class AutomaticOverride(BaseOverride):

    """Automatic override."""

    def __init__(self, enabled, timeout, topics):
        """Constructs an AutomaticOverride.

        Args:
            enabled: Whether to enable the override or not.
            timeout: Timeout in seconds before engaging failsafe.
            topics: List of topic names to consider for comms status.
        """
        self.enabled = enabled
        self.timeout = rospy.Duration(secs=timeout)
        self.topics = topics

        if enabled:
            self._lock = Lock()

            # Wait for a valid time since time is 0 until first /clock message
            # is received.
            self._last_received = rospy.get_rostime()
            while self._last_received.to_sec() == 0:
                self._last_received = rospy.get_rostime()
                rospy.logwarn_throttle(1, "Waiting for valid ROS time...")

            # Subscribe to all communication topics.
            for topic in topics:
                rospy.Subscriber(topic, rospy.AnyMsg, self._cb, queue_size=1)

    def _cb(self, msg):
        """Callback on comms status.

        Args:
            msg (AnyMsg): ROS message, unused.
        """
        with self._lock:
            self._last_received = rospy.Time.now()

    def triggered(self):
        """Whether the override was triggered or not."""
        if self.enabled:
            with self._lock:
                return rospy.get_rostime() - self._last_received > self.timeout
        return False


class ManualOverride(BaseOverride):

    """Manual override."""

    def __init__(self, enabled, channel, operation, threshold):
        """Constructs a ManualOverride.

        Args:
            enabled: Whether to enable the override or not.
            channel: Channel to trigger on (0 indexed),
            operation: Comparison operation ('greater' | 'less'),
            threshold: Value above/below which to trigger on,
        """
        self.enabled = enabled
        self.channel = channel
        self.threshold = threshold
        if operation == "greater":
            self.operation = operator.gt
        elif operation == "less":
            self.operation = operator.lt
        else:
            raise ValueError("Unexpected trigger: {}".format(operation))

        if enabled:
            self._lock = Lock()
            self._triggered = False

            # Subscribe to RC message to listen for trigger.
            rospy.Subscriber("/mavros/rc/in", RCIn, self._cb, queue_size=1)

    def _cb(self, msg):
        """Callback on RC in message.

        Args:
            msg (RCIn): RCIn message.
        """
        curr_value = msg.channels[self.channel]
        with self._lock:
            self._triggered = self.operation(curr_value, self.threshold)

    def triggered(self):
        """Whether the override was triggered or not."""
        if self.enabled:
            with self._lock:
                return self._triggered
        return False


class AerodynamicTerminationFailsafe(object):

    """Aerodynamic termination failsafe triggered when comms are unavailable
    for a certain period of time."""

    def __init__(self, overrides, rate, failsafe):
        """Constructs an AerodynamicTerminationFailsafe.

        Args:
            overrides: List of overrides to monitor for triggers.
            rate: Rate to check for overrides in Hz.
            failsafe: Failsafe to trigger using param2 of
                MAV_CMD_DO_FLIGHTTERMINATION command.
        """
        self.overrides = overrides
        self.rate = rospy.Rate(rate)
        self.failsafe = failsafe
        self._cmd_srv = rospy.ServiceProxy(
            "/mavros/cmd/command", CommandLong, persistent=True)

    def spin(self):
        """Runs forever."""
        while not rospy.is_shutdown():
            for override in self.overrides:
                if override.triggered():
                    msg = "{}: terminating...".format(
                        override.__class__.__name__)
                    rospy.logwarn_throttle(1, msg)
                    self.terminate()

            self.rate.sleep()

    def terminate(self):
        """Force aerodynamic termination."""
        # Send a MAV_CMD_DO_FLIGHTTERMINATION command.
        # Command number = 185.
        # Param 1 must be greater than 0.5 to trigger.
        req = CommandLongRequest(command=185, param1=1.0, param2=self.failsafe)
        self._cmd_srv(req)


if __name__ == "__main__":
    rospy.init_node("~aerodynamic_termination")

    rate = rospy.get_param("~rate")
    failsafe = rospy.get_param("~failsafe")
    auto_override_params = rospy.get_param("~auto_override")
    manual_override_params = rospy.get_param("~manual_override")

    overrides = [
        AutomaticOverride(**auto_override_params),
        ManualOverride(**manual_override_params),
    ]

    AerodynamicTerminationFailsafe(overrides, rate, failsafe).spin()
