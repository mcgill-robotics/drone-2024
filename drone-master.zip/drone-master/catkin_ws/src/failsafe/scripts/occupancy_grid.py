#!/usr/bin/env python

import rospy
import numpy
import math
import tf
import cv2
from six.moves import zip
from rospy import Subscriber, Publisher
from sensor_msgs.msg import NavSatFix
from nav_msgs.msg import OccupancyGrid
from interop.msg import FlyZoneArray, GeoCylinderArrayStamped, GeoSphereArrayStamped
from transformers.points.enu_coord import ENUCoord

global_flyzone_array = None
global_stationary_array = None
global_moving_array = None


def gps_callback(msg, args):
    """Uses gps fix to draw occupancy grid.

    Args:
        msg: NavSatFix data.
        args: Tuple of arguments.
            ref: ENUCoord reference point.
            pub: Publisher for occupancy grid.
            width: Width in cells of occupancy grid.
            height: Height in cells of occupancy grid
            resolution: Resolution in meters per cell of occupancy grid.
            interop_map: Object of type OccupancyGrid.
            listener: Transform listener.

    Returns:
        Approximation of line on occupancy grid.
    """
    navsatfix = msg
    moving_array = global_moving_array

    ref, pub, width, height, resolution, interop_map, listener = args

    # Initialize occupancy grid.
    occ_grid = numpy.zeros((width, height), numpy.uint8)

    # Create origin of map in terms of ENUCoord and relative to array.
    origin_x = width / 2
    origin_y = height / 2

    navsat_ENU = ENUCoord.from_lla(
        (navsatfix.latitude, navsatfix.longitude, navsatfix.altitude), ref)
    interop_map.info.origin.position.z = navsat_ENU.z

    # Draw all interop objects on occupancy grid.
    draw_flyzones(navsatfix, listener, origin_x, origin_y, occ_grid, width,
                  height, resolution)
    draw_stationary_obs(navsatfix, listener, origin_x, origin_y, occ_grid,
                        width, height, resolution)
    draw_moving_obs(navsatfix, listener, origin_x, origin_y, occ_grid, width,
                    height, resolution)

    # Collapses data into one dimension and publishes occupancy grid.
    for i in range(width * height):
        interop_map.data[i] = occ_grid.flat[i]

    pub.publish(interop_map)


def flyzone_callback(msg):
    global global_flyzone_array
    global_flyzone_array = msg.flyzones


def stationary_callback(msg):
    global global_stationary_array
    global_stationary_array = msg


def moving_callback(msg):
    global global_moving_array
    global_moving_array = msg


def draw_flyzones(navsatfix, listener, origin_x, origin_y, occ_grid, width,
                  height, resolution):
    """Iterates through flyzones and draws them on occupancy grid.

    Args:
        navsatfix: GPS fix.
        listener: Transform listener.
        origin_x: X point of origin of occ_grid.
        origin_y: Y point of origin of occ_grid.
        occ_grid: Occupancy grid.
        width: Width of occ_grid.
        height: Height of occ_grid.
        resolution: Resolution (meters/cell).

    Returns:
        Two dimensional array of flyzones on occupancy grid.
    """
    flyzone_array = global_flyzone_array
    if not flyzone_array:
        return

    for count, flyzone in enumerate(flyzone_array, 1):
        if (flyzone.min_alt > navsatfix.altitude or
                flyzone.max_alt < navsatfix.altitude):
            break

        for i in range(len(flyzone.zone.polygon.points)):
            try:
                p1_trans, p1_rot = listener.lookupTransform(
                    "flyzones/{:d}/vertex/{:d}".format(count + 1, i + 1), "map",
                    rospy.Time(0))
                if len(fly_zone.zone.polygon.points) > i + 1:
                    p2_trans, p2_rot = listener.lookupTransform(
                        "flyzones/{:d}/vertex/{:d}".format(count + 1, i + 2),
                        "map", rospy.Time(0))
                else:
                    p2_trans, p2_rot = listener.lookupTransform(
                        "flyzones/{:d}/vertex/{:d}".format(count + 1, 1), "map",
                        rospy.Time(0))
            except (tf.LookupException, tf.ConnectivityException,
                    tf.ExtrapolationException):
                return

            point1_ENU = ENUCoord(p1_trans[0], p1_trans[1], p1_trans[2], p1_rot)
            point2_ENU = ENUCoord(p2_trans[0], p2_trans[1], p2_trans[2], p2_rot)
            point1 = (int(point1_ENU.x / resolution + origin_x),
                      int(point1_ENU.y / resolution + origin_y))
            point2 = (int(point2_ENU.x / resolution + origin_x),
                      int(point2_ENU.y / resolution + origin_y))
            draw_line(point1, point2, occ_grid)


def draw_stationary_obs(navsatfix, listener, origin_x, origin_y, occ_grid,
                        width, height, resolution):
    """Iterates through cylindrical stationary obstacles and draws them on occupancy grid.

    Args:
        navsatfix: GPS fix.
        listener: Transform listener.
        origin_x: X point of origin of occ_grid.
        origin_y: Y point of origin of occ_grid.
        occ_grid: Occupancy Grid.
        width: Width of occ_grid.
        height: Height of occ_grid.
        resolution: Resolution (meters/cell).

    Returns:
        Two dimensional array of stationary obstacles on occupancy grid.
    """
    stationary_array = global_stationary_array
    if not stationary_array:
        return

    for count, stat_obs in enumerate(stationary_array.cylinders, 1):
        if navsatfix.altitude > stat_obs.height:
            break

        try:
            stat_trans, stat_rot = listener.lookupTransform(
                "obstacles/stationary/{:d}".format(count), "map", rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException,
                tf.ExtrapolationException):
            return

        stat_obs_ENU = ENUCoord(stat_trans[0], stat_trans[1], stat_trans[2],
                                stat_rot)
        circx_origin = int(stat_obs_ENU.x / resolution + origin_x)
        circy_origin = int(stat_obs_ENU.y / resolution + origin_y)
        draw_circle(circx_origin, circy_origin,
                    int(stat_obs.radius / resolution), occ_grid)


def draw_moving_obs(navsatfix, listener, origin_x, origin_y, occ_grid, width,
                    height, resolution):
    """Iterates through spherical moving obstacles and draws them on occupancy grid.

    Args:
        navsatfix: GPS fix.
        listener: Transform listener.
        origin_x: X point of origin of occ_grid.
        origin_y: Y point of origin of occ_grid.
        occ_grid: Occupancy Grid.
        width: Width of occ_grid.
        height: Height of occ_grid.
        resolution: Resolution (meters/cell).

    Returns:
        Two dimensional array of moving obstacles on occupancy grid.
    """
    moving_array = global_moving_array
    if not moving_array:
        return

    for count, move_obs in enumerate(moving_array.spheres, 1):
        if (move_obs.center.altitude - move_obs.radius > navsatfix.altitude or
                move_obs.center.altitude + move_obs.radius <
                navsatfix.altitude):
            break

        try:
            move_trans, move_rot = listener.lookupTransform(
                "obstacles/moving/{:d}".format(count), "map", rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException,
                tf.ExtrapolationException):
            return

        move_obs_ENU = ENUCoord(move_trans[0], move_trans[1], move_trans[2],
                                move_rot)
        circx_origin = int(move_obs_ENU.x / resolution + origin_x)
        circy_origin = int(move_obs_ENU.y / resolution + origin_y)
        h = move_obs.center.altitude + move_obs.radius - navsatfix.altitude
        cap_radius = int(math.sqrt(2 * h * move_obs.radius - h**2))
        draw_circle(circx_origin, circy_origin, cap_radius / resolution,
                    occ_grid)


def draw_line(point1, point2, occ_grid):
    """Uses OpenCV2 to draw a line on the occupancy grid given two points.

    Args:
        point1: (x, y) tuple.
        point2: (x, y) tuple.
        occ_grid: Occupancy grid.

    Returns:
        Approximation of line on occupancy grid.
    """
    occ_grid = cv2.line(occ_grid, point1, point2, 100, 2)


def draw_circle(circ_origin_x, circ_origin_y, radius, occ_grid):
    """Uses OpenCV2 to draw a filled circle on the occ_grid.

    Args:
        circ_origin_x: X point of origin of occ_grid.
        circ_origin_y: Y point of origin of occ_grid.
        radius: Radius of the circle.
        occ_grid: Occupancy grid.

    Returns:
        Filled in circle on occupancy grid.
    """
    occ_grid = cv2.circle(occ_grid, (circ_origin_x, circ_origin_y), radius, 100,
                          -1)


if __name__ == "__main__":
    rospy.init_node("~occupancy_grid")

    # Map width and height in the number of cells.
    width = int(rospy.get_param("~width", 2000))
    height = int(rospy.get_param("~height", 2000))

    # Resolution in meters per cell.
    resolution = float(rospy.get_param("~resolution", 1.0))

    interop_map = OccupancyGrid()
    interop_map.info.width = width
    interop_map.info.height = height
    interop_map.info.resolution = resolution
    interop_map.header.frame_id = "map"
    interop_map.data = range(width * height)
    interop_map.info.origin.position.x = -width / 2 * resolution
    interop_map.info.origin.position.y = -height / 2 * resolution
    interop_map.info.origin.orientation.w = 1
    listener = tf.TransformListener()

    pub = Publisher("~occupancy_grid", OccupancyGrid, queue_size=1)
    ref = ENUCoord.ref_point_from_map_transform()

    Subscriber(
        "/mavros/global_position/global",
        NavSatFix,
        gps_callback,
        (ref, pub, width, height, resolution, interop_map, listener),
        queue_size=1)
    Subscriber(
        "/interop/mission_info/flyzones",
        FlyZoneArray,
        flyzone_callback,
        queue_size=1)
    Subscriber(
        "/interop/obstacles/stationary",
        GeoCylinderArrayStamped,
        stationary_callback,
        queue_size=1)
    Subscriber(
        "/interop/obstacles/moving",
        GeoSphereArrayStamped,
        moving_callback,
        queue_size=1)
    rospy.spin()
