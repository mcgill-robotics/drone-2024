#!/usr/bin/env python

import rospy
from six.moves import zip
from rospy import Subscriber, Publisher
from std_msgs.msg import Bool
from sensor_msgs.msg import NavSatFix
from interop.msg import FlyZoneArray
from transformers.points import ENUCoord

flyzone_array = None


def gps_callback(msg, args):
    local_flyzone_array = flyzone_array
    pub, ref = args

    if local_flyzone_array is None or ref is None:
        return

    # Iterates through all of the flyzones and checks if the drone is any of
    # them.
    in_flyzone = False
    for flyzone in local_flyzone_array:
        if is_in_flyzone(msg, flyzone, ref):
            in_flyzone = True
            break

    pub.publish(in_flyzone)


def flyzone_callback(msg):
    global flyzone_array
    flyzone_array = msg.flyzones


def is_in_flyzone(navsatfix, flyzone, reference_ENU):
    """Whether or not the drone is within a particular flyzone.

    Args:
        navsatfix: Drone GPS position.
        flyzone: Flyzone obtained from interop.
        reference_ENU: ENUCoord reference point.

    Returns:
        bool: True if the drone is within the flyzone, False otherwise.
    """
    # Check that the drone is within the allowed altitudes.
    if not flyzone.min_alt <= navsatfix.altitude <= flyzone.max_alt:
        return False

    # Create an ENUCoord for the navsatfix to be used as a reference point.
    nav_ENU = ENUCoord.from_lla(
        (navsatfix.latitude, navsatfix.longitude, navsatfix.altitude),
        reference_ENU)

    # Use the ray casting algorithm to determine if the drone is within the
    # flyzone.
    # Find the number of intersections.
    intersections = 0
    points = flyzone.zone.polygon.points
    for p1, p2 in zip(points, points[1:] + points[:1]):
        p1_ENU = ENUCoord.from_lla((p1.latitude, p1.longitude, p1.altitude),
                                   reference_ENU)
        p2_ENU = ENUCoord.from_lla((p2.latitude, p2.longitude, p2.altitude),
                                   reference_ENU)

        if does_intersect(p1_ENU, p2_ENU, nav_ENU):
            intersections += 1

    # If the number of intersections is odd, the drone is within the polygon
    # (i.e. flyzone), otherwise the drone is outside the polygon.
    return intersections % 2 == 1


def does_intersect(p_lower, p_higher, navsatfix):
    """Checks to see if a lateral ray pointed to the right of the drone
    intersects the line.

    Args:
        p_lower: Lower y point.
        p_higher: Higher y point.
        navsatfix: Drone GPS fix.

    Returns:
        Whether the intersection occurs or not.
    """
    # Ensures that p_higher has the higher y.
    if p_lower.y > p_higher.y:
        p_lower, p_higher = p_higher, p_lower

    # Checks to ensure that the drone is within the "x" of the line.
    if p_lower.y <= navsatfix.y <= p_higher.y:
        if (p_lower.y - p_higher.y) != 0:
            # Finds the slope of the line (x/y).
            slope = p_lower.x - p_higher.x
            slope /= p_lower.y - p_higher.y

            # Determines the x of the point on the line.
            # Corresponds to the drone's "x".
            point_x = (navsatfix.y - p_higher.y) * slope + p_higher.x

            # Checks to see if the drone's "x" is less than or equal to
            # that point's x.
            return navsatfix.x <= point_x

    return False


if __name__ == "__main__":
    rospy.init_node("~flyzone_monitor")

    ref = ENUCoord.ref_point_from_map_transform()
    pub = Publisher("~in_flyzone", Bool, queue_size=1)
    Subscriber(
        "/mavros/global_position/global",
        NavSatFix,
        gps_callback, (pub, ref),
        queue_size=1)
    Subscriber(
        "/interop/mission_info/flyzones",
        FlyZoneArray,
        flyzone_callback,
        queue_size=1)

    rospy.spin()
