# -*- coding: utf-8 -*-
from mpu_imu import MPUImu

__author__ = "Bei Chen Liu"

__all__ = ["IMUImu"]
