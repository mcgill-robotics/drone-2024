# Raspberry Pi python script for:
#    MPU6000
#    MPU6050
#    MPU6500
#    MPU9150
#    MPU9250

# For McGill Robotics Ground Station Gimbal
# Author: Bei Chen Liu (bei.liu.mail.mcgill.ca)
# Version: 0.1
import smbus
from time import sleep
from enum import IntEnum


class MPUImu:
    # Address definition
    _ADDR_SLAVE_HIGH = 0x69
    _ADDR_SLAVE_LOW = 0x68
    _ADDR_SLAVE_MAG = 0x0C

    _REG_MPU_SELF_TEST_GYRO = 0x00  # MPU9250 ONLY

    _REG_MPU_SELF_TEST = 0x0D
    _REG_MPU_SELF_TEST_A = 0x10  # MPU6050 ONLY

    _REG_MPU_GYRO_OFFSET = 0x13

    _REG_MPU_SMPLRT_DIV = 0x19
    _REG_MPU_CONFIG = 0x1A
    _REG_MPU_GYRO_CONFIG = 0x1B
    _REG_MPU_ACCEL_CONFIG = 0x1C
    _REG_MPU_ACCEL_CONFIG2 = 0x1D  # MPU9250 ONLY
    _REG_MPU_LP_ACCEL_ODR = 0x1E  # MPU9250 ONLY
    _REG_MPU_WOM_THR = 0x1F  # MPU9250 ONLY

    _REG_MPU_FIFO_EN = 0x23

    _REG_MPU_I2C_MST_CTRL = 0x24
    _REG_MPU_I2C_MST_STATUS = 0x36
    _REG_MPU_I2C_MST_DELAY_CTRL = 0x67

    _REG_MPU_I2C_SLV0_ADDR = 0x25
    _REG_MPU_I2C_SLV0_REG = 0x26
    _REG_MPU_I2C_SLV0_CTRL = 0x27
    _REG_MPU_I2C_SLV0_DO = 0x63

    _REG_MPU_I2C_SLV1_ADDR = 0x28
    _REG_MPU_I2C_SLV1_REG = 0x29
    _REG_MPU_I2C_SLV1_CTRL = 0x2A
    _REG_MPU_I2C_SLv1_DO = 0x64

    _REG_MPU_I2C_SLV2_ADDR = 0x2B
    _REG_MPU_I2C_SLV2_REG = 0x2C
    _REG_MPU_I2C_SLV2_CTRL = 0x2D
    _REG_MPU_I2C_SLV2_DO = 0x65

    _REG_MPU_I2C_SLV3_ADDR = 0x2E
    _REG_MPU_I2C_SLV3_REG = 0x2F
    _REG_MPU_I2C_SLV3_CTRL = 0x30
    _REG_MPU_I2C_SLV3_DO = 0x66

    _REG_MPU_I2C_SLV4_ADDR = 0x31
    _REG_MPU_I2C_SLV4_REG = 0x32
    _REG_MPU_I2C_SLV4_DO = 0x33
    _REG_MPU_I2C_SLV4_CTRL = 0x34
    _REG_MPU_I2C_SLV4_DI = 0x35

    _REG_MPU_INT_PIN_CFG = 0x37
    _REG_MPU_INT_ENABLE = 0x38
    _REG_MPU_INT_STATUS = 0x3A

    _REG_MPU_ACCEL_OUT = 0x3B
    _REG_MPU_TEMP_OUT = 0x41
    _REG_MPU_GYRO_OUT = 0X43

    _REG_MPU_EXT_SENS_DATA = 0x49

    _REG_MPU_SIGNAL_PATH_RESET = 0x68
    _REG_MPU_MOT_DETECT_CTRL = 0x69  # MPU9250 ONLY
    _REG_MPU_USER_CTRL = 0x6A
    _REG_MPU_PWR_MGMT_1 = 0x6B
    _REG_MPU_PWR_MGMT_2 = 0x6C

    _REG_MPU_FIFO_COUT = 0x72
    _REG_MPU_FIFO_R_W = 0x74
    _REG_MPU_WHO_AM_I = 0x75

    _REG_MAG_WHO_AM_I = 0x00

    _REG_MPU_A_OFFSET = 0x77  # MPU9250 ONLY

    _WHO_AM_I_MAG = 0x48

    _REG_MAG_WIA = 0x00
    _REG_MAG_INFO = 0x01
    _REG_MAG_STATUS_1 = 0x02
    _REG_MAG_DATA = 0x03
    _REG_MAG_STATUS_2 = 0x09
    _REG_MAG_CONTROL_1 = 0x0A
    _REG_MAG_CONTROL_2 = 0x0B
    _REG_MAG_SELF_TEST = 0x0C
    _REG_MAG_TEST_1 = 0x0D
    _REG_MAG_TEST_2 = 0x0E
    _REG_MAG_SEN_ADJ = 0x10

    _GLOBAL_G = 9.80665
    _GLOBAL_PI = 3.1415926
    _GLOBAL_DEG2RAD = _GLOBAL_PI / 180.0

    class _Who_am_i(IntEnum):
        MPU9250 = 0x71
        MPU60X0 = 0x68
        MPU6500 = 0x70

    _MAG_MODE_LIST = [0b0000, 0b0001, 0b0010, 0b0110, 0b0100, 0b1000, 0b1111]

    _MPU_CFG_AFS_2G = 0b00
    _MPU_CFG_AFS_4G = 0b01
    _MPU_CFG_AFS_8G = 0b10
    _MPU_CFG_AFS_16G = 0b11

    _MPU_CFG_GFS_250DPS = 0b00
    _MPU_CFG_GFS_500DPS = 0b01
    _MPU_CFG_GFS_1000DPS = 0b10
    _MPU_CFG_GFS_2000DPS = 0b11

    def __init__(self, address=_ADDR_SLAVE_LOW, bus=1):
        '''Constructor for the imu object.

        Args:
            address: The I2C address of the imu, should be 0x68 or 0x69
            bus: The I2C bus where the imu is attached. 0 for RPI1; 1 for RPI2
            and RPI3.

        Raise:
            OSError: when unable to find device at the address or the WHO_AM_I
            id does not match any supported model.
        '''
        self._address = address
        self._bus = smbus.SMBus(bus)
        self.who_am_i = self._bus.read_byte_data(self._address,
                                                 self._REG_MPU_WHO_AM_I)
        self.supported = False
        self.has_mag = False
        self.gyro_res = self._GLOBAL_DEG2RAD * 250.0 / 32768.0
        self.accel_res = self._GLOBAL_G * 2.0 / 32768.0

        #  Check if the who_am_i ID of the device matches the supported models
        for model in self._Who_am_i:
            if model == self.who_am_i:
                self.supported = True
        if not self.supported:
            raise IOError('Find device with unsupported ID: 0x{0:X}'.format(
                self.who_am_i))

        #  Try to see if there is a magnetometer
        if self.who_am_i == self._Who_am_i.MPU9250:
            self.has_mag = True
        if self.who_am_i == self._Who_am_i.MPU60X0:
            try:
                mag_id = self._bus.read_byte_data(self._address,
                                                  self._REG_MAG_WHO_AM_I)
                if mag_id == self._WHO_AM_I_MAG:
                    self.has_mag = True
            except IOError as e:
                pass
        if self.has_mag:
            self.mag_res = 0.6 / 1000000.0
            self.mag_sen_adj = None

    def set_sample_rate_divider(self, rate_divider):
        '''Set the internal sample rate divider, the sample rate is used for
        sensor register output, FIFO output and DMP.
        Sample Rate = Internal Sample Rate / ( 1 + rate_divider)
            For MPU60X0 and MPU9150:
                Internal Sample Rate is 8kHz when the DLPF is disable and 1kHz
                when the DLPF is enabled.
            For MPU6500 and MPU9250:
                Intermal Sample Rate is 1kHz, and this register is only
                effective when the average filter's output is selected.

        Args:
            rate_divider: 8-bit unsigned interger.
        '''
        self._bus.write_byte_data(self._address, self._REG_MPU_SMPLRT_DIV,
                                  0xFF & rate_divider)

    def set_fifo_mode(self, value):
        '''Set the FIFO buffer mode, when set to '1', when the FIFO is full,
        additional writes will not be written to FIFO; when set to '0', when
        the FIFO is full, additional writes will be written to the FIFO,
        replacing the oldest data.
        Only Work on MPU6500 and MPU9250.

        Args:
            value: '0' or '1'.
        '''
        if (self.who_am_i == self._Who_am_i.MPU9250 or
                self.who_am_i == self._Who_am_i.MPU6500):
            temp = self._bus.read_byte_data(self._address, self._REG_MPU_CONFIG)
            self_bus.wirte_byte_data(
                self._address, self._REG_MPU_CONFIG,
                0xFF & [temp & ~(1 << 6), temp | (1 << 6)][value & 0x1])

    def sleep(self, value):
        '''Set the device to sleep or awake from sleep.

        Args:
            value, '0' for awake, or '1' for sleep.
        '''
        temp = self._bus.read_byte_data(self._address, self._REG_MPU_PWR_MGMT_1)
        self._bus.write_byte_data(
            self._address, self._REG_MPU_PWR_MGMT_1,
            0xFF & [temp & ~(1 << 6), temp | (1 << 6)][value & 0x1])

    def set_bypass_en(self, value):
        '''Set the device to bypass mode or normal mode.

        Args:
            value, '0' for normal, or '1' for bypass.
        '''
        temp = self._bus.read_byte_data(self._address,
                                        self._REG_MPU_INT_PIN_CFG)
        self._bus.write_byte_data(
            self._address, self._REG_MPU_INT_PIN_CFG,
            0xFF & [temp & ~(1 << 1), temp | (1 << 1)][value & 0x1])

    def reset_mpu(self):
        '''Software reset the MPU, returning register to their default
        settings.
        '''
        self._bus.write_byte_data(self._address, self._REG_MPU_PWR_MGMT_1,
                                  0b1000000)

    def clock_sel(self, value):
        '''Set the clock source.

        Args:
            value:
                MPU60X0 and MPU9150:
                    '0': Internal 8MHz oscillator
                    '1': PLL with X axis gyroscope reference.
                    '2': PLL with Y axis gyroscope reference.
                    '3': PLL with Z axis gyroscope reference.
                    '4': PLL with external 32.768kHZ reference.
                    '5': PLL with external 19.2MHZ reference.
                    '6': Reserved.
                    '7': Stop the clock and keep the timing generator in reset.
                MPU6500 and MPU9250:
                    '0': Internal 20MHz oscillator.
                    '1' - '5': Auto selects the best clock source -- PLL if
                        ready, else use internal oscillator.
                    '6': Internal 20MHz oscillator.
                    '7': Stop the clock and keep the timing generator in reset.
        '''

        temp = self._bus.read_byte_data(self._address, self._REG_MPU_PWR_MGMT_1)
        self._bus.write_byte_data(self._address, self._REG_MPU_PWR_MGMT_1,
                                  0b11111000 & temp | value & 0b111)
        temp = self._bus.read_byte_data(self._address, self._REG_MPU_PWR_MGMT_1)

    def set_accel_scale(self, value):
        '''Set the scale of ADC for the accelerometer.

        Args:
            Value:
                '0': +-2G.
                '1': +-4G.
                '2': +-8G.
                '3': +-16G.
        '''
        self._bus.write_byte_data(self._address, self._REG_MPU_ACCEL_CONFIG,
                                  (0b11 & value) << 3)
        self.accel_res = self._GLOBAL_G * 2.0 * 2**(value & 0b11) / 32768.0

    def set_gyro_scale(self, value):
        '''Set the scale of ADC for the gyroscope.

        Args:
            Value:
                '0': +-250dps.
                '1': +-500dps.
                '2': +-1000dps.
                '3': +-2000dps.
        '''
        self._bus.write_byte_data(self._address, self._REG_MPU_GYRO_CONFIG,
                                  (0b11 & value) << 3)
        self.gyro_res = (self._GLOBAL_DEG2RAD * 250.0 * 2**
                         (value & 0b11)) / 32768.0

    def print_reg_bin(self, reg):
        '''Get value from a register and print it in binary.

        Args:
            reg: Address of the register to read.
        '''
        temp = self._bus.read_byte_data(self._address, reg)
        print('0b{0:b}'.format(temp))

    def print_reg_hex(self, reg):
        '''Get value from a register and print it in hexadecimal.

        Args:
            reg: Address of the register to read.
        '''
        temp = self._bus.read_byte_data(self._address, reg)
        print('0x{0:x}'.format(temp))

    def _byte2int(self, byte_h, byte_l):
        '''Convert two byte into signed int.

        Args:
            byte_h: Higher byte.
            byte_l: Lower byte.

        Return:
            Value in signed int.
        '''
        value = byte_h << 8 | byte_l
        if value & 1 << 15:
            value -= 1 << 16
        return value

    def get_accel_data_raw(self):
        '''Get the raw acceleration data in signed int.

        Return:
            Array of accelertion in 3 axies in form of [x, y, z].
        '''
        data = self._bus.read_i2c_block_data(self._address,
                                             self._REG_MPU_ACCEL_OUT, 6)
        x = self._byte2int(data[0], data[1])
        y = self._byte2int(data[2], data[3])
        z = self._byte2int(data[4], data[5])
        return [x, y, z]

    def get_accel_data(self):
        '''Get acceleration data in m/s^2.

        Return:
            Array of acceleration in 3 axies in form of [x, y ,z].
        '''
        data = self.get_accel_data_raw()
        return [x * self.accel_res for x in data]

    def get_gyro_data_raw(self):
        '''Get the raw angular speed data in signed int.

        Return:
            Array of angular speed in 3 axies in form of [x, y, z].
        '''
        data = self._bus.read_i2c_block_data(self._address,
                                             self._REG_MPU_GYRO_OUT, 6)
        x = self._byte2int(data[0], data[1])
        y = self._byte2int(data[2], data[3])
        z = self._byte2int(data[4], data[5])
        return [x, y, z]

    def get_gyro_data(self):
        '''Get the angular speed data in rad/s.

        Return:
            Array of angular speed in 3 axies in form of [x, y, z].
        '''
        data = self.get_gyro_data_raw()
        return [x * self.gyro_res for x in data]

    def get_temp_data_raw(self):
        '''Get the raw temperature data in signed int.

        Return:
            Raw temperature value.
        '''
        data = self._bus.read_i2c_block_data(self._address,
                                             self._REG_MPU_TEMP_OUT, 6)
        t = self._byte2int(data[0], data[1])
        return t

    def get_temp_data(self):
        '''Get the raw temperature data in degree Celsius.

        Return:
            Temperature value.
        '''
        data = self.get_temp_data_raw()
        if (self.who_am_i == self._Who_am_i.MPU60X0):
            return (data / 340 + 36.53)
        else:
            return (data / 333.87 + 21.0)

    def get_mpu_data_raw(self):
        '''Get raw acceleration, temperature and gyro data in signed int with
        a single read.

        Return:
            [accel_x, accel_y, accel_z, temp, gyro_x, gyro_y, gyro_z].
        '''
        data = self._bus.read_i2c_block_data(self._address,
                                             self._REG_MPU_ACCEL_OUT, 14)
        accel_x = self._byte2int(data[0], data[1])
        accel_y = self._byte2int(data[2], data[3])
        accel_z = self._byte2int(data[4], data[5])
        temp = self._byte2int(data[6], data[7])
        gyro_x = self._byte2int(data[8], data[9])
        gyro_y = self._byte2int(data[10], data[11])
        gyro_z = self._byte2int(data[12], data[13])

        return [accel_x, accel_y, accel_z, temp, gyro_x, gyro_y, gyro_z]

    def get_mpu_data(self):
        '''Get acceleration in m/s^2, temperature in degree Celsius and angular
        velocity data in rad/s a single read.

        Return:
            [accel_x, accel_y, accel_z, temp, gyro_x, gyro_y, gyro_z].
        '''
        data = self.get_mpu_data_raw()

        if (self.who_am_i == self._Who_am_i.MPU60X0):
            temp = (data[3] / 340 + 36.53)
        else:
            temp = (data[3] / 333.87 + 21.0)

        return [
            data[0] * self.accel_res, data[1] * self.accel_res,
            data[2] * self.accel_res, temp, data[4] * self.gyro_res,
            data[5] * self.gyro_res, data[6] * self.gyro_res
        ]

    def reset_mag(self):
        '''Software resetting the magnetometer.
        '''
        self._bus.write_byte_data(self._ADDR_SLAVE_MAG, self._REG_MAG_CONTROL_2,
                                  0x01)

    def set_mag_mode(self, mode):
        '''Set the operation mode of the magnetometer.

        Args:
            mode:
                '0b0000': Power-down mode.
                '0b0001': Single measurement mode.
                '0b0010': Continuous measurement mode 1.
                '0b0110': Continuous measurement mode 2.
                '0b0100': External trigger mode.
                '0b1000': Self-test mode.
                '0b1111': Fuse ROM access mode.
                Other value are prohibited
        Raise:
            ValueError: mode value prohibited.
        '''
        if mode not in self._MAG_MODE_LIST:
            raise ValueError(
                'Magnetometer mode prohibited: {0:#b4}'.format(mode))
        else:
            temp = self._bus.read_byte_data(self._ADDR_SLAVE_MAG,
                                            self._REG_MAG_CONTROL_1)
            self._bus.write_byte_data(self._ADDR_SLAVE_MAG,
                                      self._REG_MAG_CONTROL_1, temp & 0xF0)
            if mode:
                sleep(0.0002)
                self._bus.write_byte_data(self._ADDR_SLAVE_MAG,
                                          self._REG_MAG_CONTROL_1,
                                          (temp & 0xF0) + mode)
                sleep(0.0002)

    def set_mag_res(self, value):
        '''Set the magnetometer resolution.

        Args:
            Value:
                '0': 14-bit mode, LSB is 0.6uT
                '1': 16-bit mode, LSB is 0.15uT
        '''
        temp = self._bus.read_byte_data(self._ADDR_SLAVE_MAG,
                                        self._REG_MAG_CONTROL_2)
        self._bus.write_byte_data(
            self._address, self._REG_MPU_PWR_MGMT_1,
            0xFF & [temp & ~(1 << 4), temp | (1 << 4)][value & 0x1])
        if value:
            self.mag_res = 0.6 / 1000000.0
        else:
            self.mag_res = 0.15 / 1000000.0

    def get_sen_adj_value(self):
        '''Get the sensitivity adjustment value from the fuse ROM.

        return: sensitivity value in form of [x, y, z]
        '''
        #  buffer the previous mode and res setting
        mode = self._bus.read_byte_data(self._ADDR_SLAVE_MAG,
                                        self._REG_MAG_CONTROL_1)

        #  change to fuse ROM read mode
        self.set_mag_mode(0b1111)

        #  get data
        data = self._bus.read_i2c_block_data(self._ADDR_SLAVE_MAG,
                                             self._REG_MAG_SEN_ADJ, 3)

        # chage mode back
        self.set_mag_mode(0b0000)
        if mode & 0x0F:
            sleep(0.0002)
            self._bus.write_byte_data(self._ADDR_SLAVE_MAG,
                                      self._REG_MAG_CONTROL_1, mode)
            sleep(0.0002)
        return data

    def get_mag_data_raw(self):
        '''Get raw unadjusted magnetometer value in signed int.

        return:
            'None' if magnetic sensor overflow ocurred else raw measurement in
            form of [x, y, z]
        '''
        ready = self._bus.read_byte_data(self._ADDR_SLAVE_MAG,
                                         self._REG_MAG_STATUS_1)
        data = self._bus.read_i2c_block_data(self._ADDR_SLAVE_MAG,
                                             self._REG_MAG_DATA, 7)
        if data[6] & 0x08:
            return None
        else:
            return [
                self._byte2int(data[1], data[0]),
                self._byte2int(data[3], data[2]),
                self._byte2int(data[5], data[4])
            ]

    def mag_adj_data(self, data, sen_adj):
        '''Calculate sensitivity adjusted measurement value.

        Args:
            data: raw measurement data.
            sen_adj: sensitivity adjustment value

        return: Adjusted measurement data
        '''
        return data * ((sen_adj - 128.0) / 256.0 + 1.0)

    def get_mag_data(self):
        '''Get measurement data in Tesla for all axies. If 'self.mag_data_adj'
        is set, the result will be adjusted data.

        Return: [x, y, z]
        '''
        data = self.get_mag_data_raw()
        if self.mag_sen_adj is None:
            return [x * self.mag_res for x in data]
        else:
            return [
                self.mag_adj_data(data[0], self.mag_sen_adj[0]) * self.mag_res,
                self.mag_adj_data(data[1], self.mag_sen_adj[1]) * self.mag_res,
                self.mag_adj_data(data[2], self.mag_sen_adj[2]) * self.mag_res
            ]
