# Raspberry Pi python script for INA219 current sensor fron TI
# For McGill Robotiscs Ground Station Gimbal
# Author: Bei Chen Liu

import smbus
from time import sleep


class INA219:
    _ALLOWED_ADDRESS = [
        0b1000000, 0b1000001, 0b1000010, 0b1000011, 0b1000100, 0b1000101,
        0b1000110, 0b1000111, 0b1001000, 0b1001001, 0b1001010, 0b1001011,
        0b1001100, 0b1001101, 0b1001110, 0b1001111
    ]
    _REG_CONF = 0x00
    _REG_V_SHUNT = 0x01
    _REG_V_BUS = 0x02
    _REG_POWER = 0x03
    _REG_CURRENT = 0x04
    _REG_CAL = 0x05

    def __init__(self, address, bus=1):
        '''Contructor for the current sensor object.

        Args:
            address: address for the INA219 sensor on the bus, range from 0x40
            to 0x4F. Address of the INA219 depends on the connection of pin A0
            and pin A1.
            bus: I2C bus where the INA219 is attached, use 0 for RPi1 and 1 for
            RPi2 or RPi3.

        Raise:
            ValueError: When address is not in the right range.
        '''
        if address not in self._ALLOWED_ADDRESS:
            raise ValueError("Invalid bus address: {0}".format(address))

        self._address = address
        self._bus = smbus.SMBus(bus)
        self._pga = 8
        self._current_const = 0
        self._power_const = 0

    def get_config(self):
        return self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)

    def set_mode(self, mode):
        '''Set the operation mode for the INA219.

        Args:
            mode: Mode to set to, valid values:
                0b000: Power-down;
                0b001: Shunt voltage, triggered;
                0b010: Bus voltage, triggered;
                0b011: Shunt and bus, triggered;
                0b100: ADC off (disabled);
                0b101: Shunt voltage, continuous;
                0b110: Bus voltage, continuous;
                0b111: Shunt and bus, continuous;
        '''
        config = self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)

        # Clear and set mode
        config[1] &= ~(0b111)
        config[1] |= (mode & 0b111)
        self._bus.write_i2c_block_data(self._address, self._REG_CONF, config)

    def set_calibration(self, i_max, r_shunt):
        '''Set the calibration register to convert voltage to current and power.

        Args:
            i_max: Maxinum expected current in Amperes.
            r_shunt: Resistance of the shunt resistor in Ohms.
        '''
        self._current_const = float(i_max) / 2**15

        cal = int(0.004096 / (self._current_const * r_shunt))
        self._power_const = 20.0 * self._current_const
        data = [(cal >> 8) & 0xFF, cal & 0xFE]
        self._bus.write_i2c_block_data(self._address, self._REG_CAL, data)

    def get_shunt_voltage(self):
        '''Get the shunt voltage.

           returns: shunt voltage in Volts.
        '''
        data = self._bus.read_i2c_block_data(self._address, self._REG_V_SHUNT,
                                             2)

        value = self._bytes_to_uint(data[0], data[1])
        if self._pga == 8:
            is_neg = value >> 15
            shunt = (~value - 1 if is_neg else value) & 0x7FFF
        elif self._pga == 4:
            is_neg = value >> 14
            shunt = (~value - 1 if is_neg else value) & 0x3FFF
        elif self._pga == 2:
            is_neg = value >> 13
            shunt = (~value - 1 if is_neg else value) & 0x1FFF
        elif self._pga == 1:
            is_neg = value >> 12
            shunt = (~value - 1 if is_neg else value) & 0x0FFF
        return shunt * -0.00001 if is_neg else shunt * 0.00001

    def _bytes_to_uint(self, byte_high, byte_low):
        '''Convert a two bytes to a 16-bit unsigned integer.

        Args:
            byte_high: Higher byte of the integer.
            byte_low: Lower byte of the integer.

        Returns: unsigned 16-bit integer
        '''
        return byte_high << 8 | byte_low

    def get_current(self):
        '''Get the current comsumption fron the INA219. Calibration register
        must be set by `set_calibration` in order to enable read.

        Returns: Current in Amperes.
        '''
        data = self._bus.read_i2c_block_data(self._address, self._REG_CURRENT,
                                             2)
        return self._bytes_to_uint(data[0], data[1]) * self._current_const

    def get_power(self):
        '''Get the power comsumption fron the INA219. Calibration register
        must be set by `set_calibration` in order to enable read.

        Returns: Power in Watts.
        '''
        data = self._bus.read_i2c_block_data(self._address, self._REG_POWER, 2)
        return self._bytes_to_uint(data[0], data[1]) * self._power_const

    def get_bus_voltage(self):
        '''Get bus voltage from the sensor.

        returns: Bus voltage in Volts.
        '''
        data = self._bus.read_i2c_block_data(self._address, self._REG_V_BUS, 2)
        return (self._bytes_to_uint(data[0], data[1]) >> 3) * 0.004

    def set_pga(self, pga):
        '''Set the PGA gain and range for the INA219.

        Args:
            pga: Mode to set to, valid values:
                0b00: Gain: 1, range +-40 mV;
                0b01: Gain: /2, range +-80 mV;
                0b10: Gain: /4, range +-160 mV;
                0b11: Gain: /8, range +-320 mV;
        '''
        self._pga = 2**(pga & 0b11)
        config = self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)
        config[0] &= ~(0b11 << 3)
        config[0] |= ((pga & 0b11) << 3)
        self._bus.write_i2c_block_data(self._address, self._REG_CONF, config)

    def set_badc_mode(self, mode):
        '''Set the resolution and average mode for bus voltage of the INA219.

        Args:
            mode: Mode to set to, valid values, X is don't care:
                          Mode/ Samples    Conversion Time
                0b0X00:       9 bit             84 us
                0b0X01:      10 bit            148 us
                0b0X10:      11 bit            276 us
                0b0X11:      12 bit            532 us
                0b1000:      12 bit            532 us
                0b1001:         2             1.06 ms
                0b1010:         4             2.13 ms
                0b1011:         8             4.26 ms
                0b1100:        16             8.51 ms
                0b1101:        32            17.02 ms
                0b1110:        64            34.05 ms
                0b1111:       128            68.10 ms
        '''
        config = self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)
        config[0] &= ~(0b111)
        config[1] &= ~(1 << 7)
        config[0] |= ((mode & 0b1110) >> 1)
        config[1] |= ((mode & 0b1) << 7)
        self._bus.write_i2c_block_data(self._address, self._REG_CONF, config)

    def trigger(self):
        '''Read the configuration register and write it back to INA219 to
        force a triggerd conversion. The INA219 must be set to desired trigger
        mode before calling this function.
        '''
        config = self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)
        self._bus.write_i2c_block_data(self._address, self._REG_CONF, config)

    def set_sadc_mode(self, mode):
        '''Set the resolution and average mode for shunt voltage of the INA219.

        Args:
            mode: Mode to set to, valid values, X is don't care:
                          Mode/ Samples    Conversion Time
                0b0X00:       9 bit             84 us
                0b0X01:      10 bit            148 us
                0b0X10:      11 bit            276 us
                0b0X11:      12 bit            532 us
                0b1000:      12 bit            532 us
                0b1001:         2             1.06 ms
                0b1010:         4             2.13 ms
                0b1011:         8             4.26 ms
                0b1100:        16             8.51 ms
                0b1101:        32            17.02 ms
                0b1110:        64            34.05 ms
                0b1111:       128            68.10 ms
        '''
        config = self._bus.read_i2c_block_data(self._address, self._REG_CONF, 2)
        config[1] &= ~(0b1111 << 3)
        config[1] |= ((mode & 0b1111) << 3)
        self._bus.write_i2c_block_data(self._address, self._REG_CONF, config)

    def reset(self):
        self._bus.write_i2c_block_data(self._address, self._REG_CONF,
                                       [0b10000000, 0b00000000])
        while ((1 << 7) & self._bus.read_i2c_block_data(self._address,
                                                        self._REG_CONF, 1)[0]):
            sleep(0.001)
