#!/usr/bin/env python

import rospy
import array
import struct
import numpy as np
import roslib.message
from cStringIO import StringIO
from mavros_plugins.msg import EncapsulatedData
from collections import defaultdict, OrderedDict

from sensor_msgs.msg import CompressedImage
from interop.msg import GeoCylinderArrayStamped, GeoSphereArrayStamped


class Header(object):

    FMT = "<BHII"
    SIZE = struct.calcsize(FMT)

    def __init__(self, type_id, msg_id, offset, remaining):
        self.type_id = type_id
        self.msg_id = msg_id
        self.offset = offset
        self.remaining = remaining

    @classmethod
    def from_buffer(cls, buff):
        return cls(*struct.unpack(cls.FMT, buff))

    def to_buffer(self):
        return struct.pack(self.FMT, self.type_id,
                           struct.unpack("<H", self.msg_id)[0], self.offset,
                           self.remaining)


class SingleMessageQueue(object):

    def __init__(self):
        self._buffer = StringIO()
        self._received = 0
        self._to_receive = None

    def add(self, encapsulated_data):
        header = Header.from_buffer(encapsulated_data.data[:Header.SIZE])

        if encapsulated_data.seqnr == 0:
            self._to_receive = header.remaining
            self._received = 0

        size = min(header.remaining, DATA_SIZE)
        self._received += size

        self._buffer.seek(header.offset)
        self._buffer.write(
            encapsulated_data.data[Header.SIZE:Header.SIZE + size])

    def is_complete(self):
        return self._received == self._to_receive

    def to_msg(self):
        msg = MSG_TYPE_CLASS()
        msg.deserialize(self._buffer.getvalue())
        return msg


class MultiMessageQueue(object):

    def __init__(self, max_queue_size):
        self._max_queue_size = max_queue_size
        self._queue = OrderedDict()

    def add(self, encapsulated_data):
        header = Header.from_buffer(encapsulated_data.data[:Header.SIZE])

        if header.msg_id not in self._queue:
            self._queue[header.msg_id] = SingleMessageQueue()

        self._queue[header.msg_id].add(encapsulated_data)

        if len(self._queue) > self._max_queue_size:
            self._queue.popitem(last=False)
            rospy.logwarn("Dropped message")

    def get_completed_messages(self):
        completed = []
        to_remove = []

        for msg_id, queue in self._queue.iteritems():
            if queue.is_complete():
                completed.append(queue.to_msg())
                to_remove.append(msg_id)

        for msg_id in to_remove:
            del self._queue[msg_id]

        return completed


def random_msg_id():
    return serialize_data(np.random.randint(0, 255, size=2))


def serialize_data(data):
    return array.array("B", data).tostring()


def serialize_packet(header, data):
    buff = StringIO()
    buff.write(header.to_buffer())
    buff.write(serialize_data(data))
    return buff


def recv_callback(msg):
    header = Header.from_buffer(msg.data[:Header.SIZE])

    if header.type_id != TYPE_ID:
        # Ignore any messages of a different type.
        return

    message_queue.add(msg)
    for msg in message_queue.get_completed_messages():
        publisher.publish(msg)


def send_callback(msg):
    msg_buff = StringIO()
    msg.serialize(msg_buff)

    data = msg_buff.getvalue()
    remaining = len(data)
    offset = 0
    msg_id = random_msg_id()

    seq = 0
    while remaining > 0:
        header = Header(TYPE_ID, msg_id, offset, remaining)
        buff = serialize_packet(header, data[:DATA_SIZE])

        encapsulated_data = EncapsulatedData()
        encapsulated_data.seqnr = seq
        encapsulated_data.data = buff.getvalue()

        publisher.publish(encapsulated_data)

        if remaining > DATA_SIZE:
            data = data[DATA_SIZE:]

        seq += 1
        remaining -= DATA_SIZE
        offset += DATA_SIZE

    if THROTTLE:
        rate.sleep()


if __name__ == "__main__":
    rospy.init_node("mavlink_forwarder", anonymous=True)

    # Parameters.
    ALL_TYPE_IDS = rospy.get_param("~all_topics")
    TOPIC_NAME = rospy.get_param("~topic_name")
    MSG_TYPE = rospy.get_param("~msg_type")
    MSG_QUEUE_SIZE = rospy.get_param("~msg_queue_size")
    MAVLINK_QUEUE_SIZE = rospy.get_param("~mavlink_queue_size")
    SEND_OR_RECV = rospy.get_param("~send_or_recv")
    THROTTLE = rospy.get_param("~throttle")
    THROTTLE_RATE_HZ = rospy.get_param("~throttle_rate")

    # Constants.
    PACKET_SIZE = len(EncapsulatedData().data)
    DATA_SIZE = PACKET_SIZE - Header.SIZE
    TYPE_ID = ALL_TYPE_IDS.index(TOPIC_NAME)
    MSG_TYPE_CLASS = roslib.message.get_message_class(MSG_TYPE)

    rate = rospy.Rate(THROTTLE_RATE_HZ)
    message_queue = MultiMessageQueue(MSG_QUEUE_SIZE)

    if SEND_OR_RECV == "send":
        publisher = rospy.Publisher(
            "/mavros/encapsulated_data/send",
            EncapsulatedData,
            queue_size=MAVLINK_QUEUE_SIZE)
        rospy.Subscriber(
            TOPIC_NAME,
            MSG_TYPE_CLASS,
            send_callback,
            queue_size=MSG_QUEUE_SIZE)
    elif SEND_OR_RECV == "recv":
        publisher = rospy.Publisher(
            TOPIC_NAME, MSG_TYPE_CLASS, queue_size=MSG_QUEUE_SIZE)
        rospy.Subscriber(
            "/mavros/encapsulated_data/recv",
            EncapsulatedData,
            recv_callback,
            queue_size=MAVLINK_QUEUE_SIZE)
    else:
        rospy.logfatal("unexpected parameter for send_or_recv")
        sys.exit(-1)

    rospy.spin()
