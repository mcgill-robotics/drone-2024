/**
 * @brief
 * @file encapsulated_data.cpp
 * @author Anass Al <dev@anassinator.com>
 *
 * @addtogroup plugin
 * @{
 */

#include <mavros/mavros_plugin.h>
#include <mavros_plugins/EncapsulatedData.h>

namespace mavros {
namespace custom_plugins {

class EncapsulatedDataPlugin : public plugin::PluginBase {
 public:
  EncapsulatedDataPlugin() : PluginBase(), nh("~encapsulated_data") {}

  void initialize(UAS &uas_) {
    PluginBase::initialize(uas_);
    sub =
        nh.subscribe("send", 100, &EncapsulatedDataPlugin::ros_callback, this);
    pub = nh.advertise<mavros_plugins::EncapsulatedData>("recv", 100);
  }

  Subscriptions get_subscriptions() {
    return {make_handler(&EncapsulatedDataPlugin::mavlink_callback)};
  }

 private:
  ros::NodeHandle nh;
  ros::Subscriber sub;
  ros::Publisher pub;

  void mavlink_callback(const mavlink::mavlink_message_t *msg,
                        mavlink::common::msg::ENCAPSULATED_DATA &encapsulated) {
    mavros_plugins::EncapsulatedData ros_msg;
    ros_msg.seqnr = encapsulated.seqnr;
    for (int i = 0; i < ros_msg.data.size(); i++) {
      ros_msg.data[i] = encapsulated.data[i];
    }
    pub.publish(ros_msg);
  }

  void ros_callback(const mavros_plugins::EncapsulatedData::ConstPtr &req) {
    mavlink::common::msg::ENCAPSULATED_DATA msg{};
    msg.seqnr = req->seqnr;
    for (int i = 0; i < req->data.size(); i++) {
      msg.data[i] = req->data[i];
    }
    UAS_FCU(m_uas)->send_message_ignore_drop(msg);
  }
};
}  // namespace custom_plugins
}  // namespace mavros

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(mavros::custom_plugins::EncapsulatedDataPlugin,
                       mavros::plugin::PluginBase)
