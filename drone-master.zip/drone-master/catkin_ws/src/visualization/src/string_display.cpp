#include "string_display.h"

namespace visualization {

StringDisplay::StringDisplay() {
  // Color.
  alpha_property_ = new rviz::FloatProperty(
      "Alpha", 1.0, "0 is fully transparent, 1.0 is fully opaque.", this,
      SLOT(update()));
  color_property_ = new rviz::ColorProperty(
      "Color", QColor(255, 255, 255), "Color to draw.", this, SLOT(update()));
  alpha_property_->setMin(0.0f);
  alpha_property_->setMax(1.0f);

  // Character scale.
  char_scale_property_ = new rviz::FloatProperty(
      "Char Height", 0.03f, "Max character height as percentage of display.",
      this, SLOT(update()));
  char_scale_property_->setMin(0.0f);
  char_scale_property_->setMax(1.0f);

  // Space width.
  space_width_property_ = new rviz::FloatProperty(
      "Space Width", 0.01f, "Space character width as percentage of display.",
      this, SLOT(update()));
  space_width_property_->setMin(0.0f);
  space_width_property_->setMax(1.0f);

  // Position.
  x_property_ = new rviz::FloatProperty(
      "x", 0.1f, "X coordinate as percentage of display.", this,
      SLOT(update()));
  y_property_ = new rviz::FloatProperty(
      "y", 0.1f, "Y coordinate as percentage of display.", this,
      SLOT(update()));
  x_property_->setMin(0.0f);
  x_property_->setMax(1.0f);
  y_property_->setMin(0.0f);
  y_property_->setMax(1.0f);
}

void StringDisplay::onInitialize() { MFDClass::onInitialize(); }

StringDisplay::~StringDisplay() {}

void StringDisplay::onDisable() {
  MFDClass::onDisable();
  visual_.reset();
}

void StringDisplay::onEnable() {
  MFDClass::onEnable();
  visual_.reset(new StringVisual());
  update();
}

void StringDisplay::reset() { MFDClass::reset(); }

void StringDisplay::update() {
  float alpha = alpha_property_->getFloat();
  Ogre::ColourValue color = color_property_->getOgreColor();
  visual_->setColor(color.r, color.g, color.b, alpha);

  float x = x_property_->getFloat();
  float y = y_property_->getFloat();
  visual_->setPosition(x, y);

  float char_scale = char_scale_property_->getFloat();
  visual_->setCharHeight(char_scale);

  float space_width = space_width_property_->getFloat();
  visual_->setSpaceWidth(space_width);
}

void StringDisplay::processMessage(
    const visualization::StringStamped::ConstPtr& msg) {
  visual_->setMessage(msg);
}
}  // namespace visualization

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(visualization::StringDisplay, rviz::Display)
