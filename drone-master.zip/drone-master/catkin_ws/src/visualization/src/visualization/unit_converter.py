"""Converts units for visualization."""

from interop.serializers import meters_to_feet


class UnitConverter(object):

    """Unit converter."""

    def __init__(self, metric):
        """Constructs a UnitConverter.

        Args:
            metric (bool): Whether to convert to metric or US customary units.
        """
        self._metric = metric

    def distance(self, dist):
        """Converts a distance from meters to the appropriate units.

        Args:
            dist (float): Distance in meters.

        Returns:
            Distance (float) in meters or feet.
        """
        return dist if self._metric else meters_to_feet(dist)

    def distance_unit(self):
        """Returns the appropriate distance unit symbol (str)."""
        return "m" if self._metric else "ft"

    def speed(self, speed):
        """Converts a speed from meters per second to the appropriate units.

        Args:
            dist (float): Distance in meters.

        Returns:
            Distance (float) in m/s or knots.
        """
        return speed if self._metric else speed * 1.94384

    def speed_unit(self):
        """Returns the appropriate speed unit symbol (str)."""
        return "m/s" if self._metric else "kn"
