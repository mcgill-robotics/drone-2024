//-----------------------------------------------------------------------------
// Lonewolff
//
// Filename:    OgreText.h
// Description: Class for simple text in Ogre (Version 040507:18.30)
//-----------------------------------------------------------------------------

#ifndef OGRE_TEXT_H
#define OGRE_TEXT_H

#include <OGRE/OgreStringConverter.h>
#include <OGRE/Overlay/OgreOverlayContainer.h>
#include <OGRE/Overlay/OgreOverlayElement.h>
#include <OGRE/Overlay/OgreOverlayManager.h>
#include <OGRE/Overlay/OgreTextAreaOverlayElement.h>

namespace Ogre {
namespace {
class Text {
 public:
  Text() {
    olm = OverlayManager::getSingletonPtr();

    if (init == 0) {
      panel = static_cast<OverlayContainer *>(
          olm->createOverlayElement("Panel", "GUI"));
      panel->setMetricsMode(Ogre::GMM_PIXELS);
      panel->setPosition(0, 0);
      panel->setDimensions(1.0f, 1.0f);
      overlay = olm->create("GUI_OVERLAY");
      overlay->add2D(panel);
    }
    ++(this->init);
    szElement = "element_" + StringConverter::toString(init);

    overlay = olm->getByName("GUI_OVERLAY");
    panel = static_cast<OverlayContainer *>(olm->getOverlayElement("GUI"));

    textArea = static_cast<TextAreaOverlayElement *>(
        olm->createOverlayElement("TextArea", szElement));
    textArea->setMetricsMode(Ogre::GMM_RELATIVE);
    textArea->setFontName("Liberation Sans");
    textArea->setDimensions(1.0f, 1.0f);

    panel->addChild(textArea);
    overlay->show();
  }

  ~Text() {
    szElement = "element_" + StringConverter::toString(init);
    olm->destroyOverlayElement(szElement);
    --(this->init);
    if (init == 0) {
      olm->destroyOverlayElement("GUI");
      olm->destroy("GUI_OVERLAY");
    }
  }

  void setCharHeight(float height) { textArea->setCharHeight(height); }

  void setColor(float r, float g, float b, float a) {
    textArea->setColour(Ogre::ColourValue(r, g, b, a));
    panel->setColour(Ogre::ColourValue(r, g, b, a));
  }

  void setPosition(float x, float y) { textArea->setPosition(x, y); }

  void setSpaceWidth(float width) { textArea->setSpaceWidth(width); }

  void setText(char *szString) { textArea->setCaption(szString); }

  void setText(String szString)  // now You can use Ogre::String as text
  {
    textArea->setCaption(szString);
  }

 private:
  OverlayManager *olm;
  OverlayContainer *panel;
  Overlay *overlay;
  TextAreaOverlayElement *textArea;
  static int init;
  String szElement;
};

int Text::init = 0;
}  // namespace
}  // namespace Ogre
#endif
