#include <OGRE/OgreSceneManager.h>
#include <OGRE/OgreSceneNode.h>
#include <OGRE/OgreVector3.h>

#include "string_visual.h"

namespace visualization {

StringVisual::StringVisual() { text_.reset(new Ogre::Text()); }

StringVisual::~StringVisual() { text_.reset(); }

void StringVisual::setColor(float r, float g, float b, float a) {
  text_->setColor(r, g, b, a);
}

void StringVisual::setCharHeight(float height) { text_->setCharHeight(height); }

void StringVisual::setMessage(
    const visualization::StringStamped::ConstPtr& msg) {
  text_->setText(msg->data);
}

void StringVisual::setPosition(float x, float y) { text_->setPosition(x, y); }

void StringVisual::setSpaceWidth(float width) { text_->setSpaceWidth(width); }
}  // namespace visualization
