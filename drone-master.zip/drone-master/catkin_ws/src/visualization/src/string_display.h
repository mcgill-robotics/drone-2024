#ifndef STRING_DISPLAY_H
#define STRING_DISPLAY_H

#include <rviz/message_filter_display.h>
#include <rviz/properties/color_property.h>
#include <rviz/properties/float_property.h>
#include <visualization/StringStamped.h>

#include "string_visual.h"

namespace rviz {
class ColorProperty;
class FloatProperty;
class IntProperty;
}  // namespace rviz

namespace visualization {

class StringVisual;

class StringDisplay
    : public rviz::MessageFilterDisplay<visualization::StringStamped> {
  Q_OBJECT
 public:
  StringDisplay();
  virtual ~StringDisplay();

 protected:
  virtual void onInitialize();
  virtual void onEnable();
  virtual void onDisable();
  virtual void reset();

 private Q_SLOTS:
  void update();

 private:
  void processMessage(const visualization::StringStamped::ConstPtr& msg);
  boost::shared_ptr<StringVisual> visual_;

  // User-editable property variables.
  rviz::FloatProperty* alpha_property_;
  rviz::ColorProperty* color_property_;
  rviz::FloatProperty* char_scale_property_;
  rviz::FloatProperty* space_width_property_;
  rviz::FloatProperty* x_property_;
  rviz::FloatProperty* y_property_;
};
}  // namespace visualization

#endif
