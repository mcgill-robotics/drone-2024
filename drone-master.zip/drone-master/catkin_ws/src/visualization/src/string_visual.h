#ifndef STRING_VISUAL_H
#define STRING_VISUAL_H

#include <visualization/StringStamped.h>

#include "OgreText.h"

namespace visualization {

class StringVisual {
 public:
  StringVisual();
  virtual ~StringVisual();

  void setColor(float r, float g, float b, float a);
  void setCharHeight(float height);
  void setSpaceWidth(float width);
  void setMessage(const visualization::StringStamped::ConstPtr& msg);
  void setPosition(float x, float y);

 private:
  boost::shared_ptr<Ogre::Text> text_;
};
}  // namespace visualization

#endif
