#!/usr/bin/env python
"""Visualizes stationary and moving obstacles in RViz."""

import rospy
import numpy as np
from geometry_msgs.msg import Point
from transformers.points import ENUCoord
from std_msgs.msg import ColorRGBA, Header
from visualization_msgs.msg import Marker, MarkerArray
from state_estimation.msg import PointSplineArrayStamped
from visualization.unit_converter import UnitConverter
from state_estimation.splines import PointSplineEvaluator
from interop.msg import GeoCylinderArrayStamped, GeoSphereArrayStamped

# McGill Robotics red, because we have big egos.
OBSTACLE_COLOR = ColorRGBA(r=218 / 255.0, g=41 / 255.0, b=28 / 255.0, a=1.0)
TEXT_COLOR = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)


def moving_cb(msg, cb_args):
    """Publishes a spherical visualization marker corresponding to each moving
    obstacle.

    Args:
        msg (GeoSphereArrayStamped): Moving obstacles message.
        cb_args (ENUCoord, Publisher, UnitConverter, float): Additional
            callback arguments.
    """
    ref, pub, converter, lifetime = cb_args

    stamp = msg.header.stamp
    markers_array = MarkerArray()
    for i, obstacle in enumerate(msg.spheres):
        marker = Marker()
        marker.header.stamp = stamp
        marker.header.frame_id = "obstacles/moving/{}".format(i + 1)
        marker.frame_locked = True

        marker.type = marker.SPHERE
        marker.color = OBSTACLE_COLOR
        marker.ns = marker.header.frame_id
        marker.lifetime = rospy.Duration(lifetime)

        # Set scale as radius.
        marker.scale.x = marker.scale.y = marker.scale.z = obstacle.radius

        # Add altitude as text.
        text_marker = Marker()
        text_marker.header = marker.header
        text_marker.frame_locked = True

        text_marker.type = Marker.TEXT_VIEW_FACING
        text_marker.color = TEXT_COLOR
        text_marker.ns = "{}/text".format(marker.header.frame_id)
        text_marker.lifetime = rospy.Duration(lifetime)
        text_marker.scale.z = 10
        text_marker.pose.position.z = obstacle.radius + 1.0
        text_marker.text = "{:4.1f} {}".format(
            converter.distance(obstacle.center.altitude),
            converter.distance_unit())

        markers_array.markers.append(marker)
        markers_array.markers.append(text_marker)

    pub.publish(markers_array)


def stationary_cb(msg, cb_args):
    """Publishes a cylindrical visualization marker corresponding to each
    stationary obstacle.

    Args:
        msg (GeoCylinderArrayStamped): Stationary obstacles message.
        cb_args (ENUCoord, Publisher, UnitConverter, float): Additional
            callback arguments.
    """
    ref, pub, converter, lifetime = cb_args

    stamp = msg.header.stamp
    markers_array = MarkerArray()
    for i, obstacle in enumerate(msg.cylinders):
        marker = Marker()
        marker.header.stamp = stamp
        marker.header.frame_id = "obstacles/stationary/{}".format(i + 1)

        marker.type = Marker.CYLINDER
        marker.color = OBSTACLE_COLOR
        marker.ns = marker.header.frame_id
        marker.lifetime = rospy.Duration(lifetime)

        # Set scale as radius.
        marker.scale.x = marker.scale.y = obstacle.radius
        marker.scale.z = obstacle.height
        marker.pose.position.z = obstacle.height / 2

        # Add height as text.
        text_marker = Marker()
        text_marker.header = marker.header

        text_marker.type = Marker.TEXT_VIEW_FACING
        text_marker.color = TEXT_COLOR
        text_marker.ns = "{}/text".format(marker.header.frame_id)
        text_marker.lifetime = rospy.Duration(lifetime)
        text_marker.scale.z = 10
        text_marker.pose.position.z = obstacle.height + 2.0
        text_marker.text = "{:4.1f} {}".format(
            converter.distance(obstacle.height), converter.distance_unit())

        markers_array.markers.append(marker)
        markers_array.markers.append(text_marker)

    pub.publish(markers_array)


def predictions_cb(msg, cb_args):
    """Publishes a cylindrical visualization marker corresponding to each
    stationary obstacle.

    Args:
        msg (PointSplineSegmentArrayStamped): Moving obstacles predictions
            message.
        cb_args (Publisher, float, float): Additional callback arguments.
    """
    pub, lifetime, horizon = cb_args

    # Generate base header.
    header = Header()
    header.stamp = msg.header.stamp
    header.frame_id = "map"
    curr_t = msg.header.stamp.to_sec()

    # Parse stationary obstacles, and populate markers with cylinders.
    markers_array = MarkerArray()
    for i, point_spline in enumerate(msg.point_splines):
        # Moving obstacles are spheres.
        marker = Marker()
        marker.header = header
        marker.type = marker.LINE_STRIP
        marker.color = OBSTACLE_COLOR
        marker.ns = "obstacles/predictions/{}".format(i + 1)
        marker.lifetime = rospy.Duration(lifetime)

        # Set line width.
        marker.scale.x = 0.1

        # Convert latitude and longitude to ENU.
        for t in np.linspace(curr_t, curr_t + horizon):
            coord = PointSplineEvaluator.from_msg(point_spline).eval(t)

            if not np.isfinite(coord).all():
                # Ignore potential instabilities when looking too far into the
                # future.
                rospy.logwarn_throttle(1.0, "Obstacle prediction diverged")
                break

            point = Point(*coord)
            marker.points.append(point)

        markers_array.markers.append(marker)

    pub.publish(markers_array)


if __name__ == "__main__":
    rospy.init_node("~obstacles")

    moving_lifetime = float(rospy.get_param("~moving/lifetime"))
    stationary_lifetime = float(rospy.get_param("~stationary/lifetime"))
    predictions_lifetime = float(rospy.get_param("~predictions/lifetime"))
    predictions_horizon = float(rospy.get_param("~predictions/horizon"))

    moving_pub = rospy.Publisher("~moving", MarkerArray, queue_size=1)
    stationary_pub = rospy.Publisher("~stationary", MarkerArray, queue_size=1)

    ref = ENUCoord.ref_point_from_map_transform()
    converter = UnitConverter(rospy.get_param("~metric"))

    rospy.Subscriber(
        "/interop/obstacles/moving",
        GeoSphereArrayStamped,
        moving_cb,
        queue_size=1,
        callback_args=(ref, moving_pub, converter, moving_lifetime))
    rospy.Subscriber(
        "/interop/obstacles/stationary",
        GeoCylinderArrayStamped,
        stationary_cb,
        queue_size=1,
        callback_args=(ref, stationary_pub, converter, stationary_lifetime))
    rospy.Subscriber(
        "/state_estimation/obstacle_tracker/predictions",
        PointSplineArrayStamped,
        predictions_cb,
        queue_size=1,
        callback_args=(moving_pub, predictions_lifetime, predictions_horizon))

    rospy.spin()
