#!/usr/bin/env python
"""Visualizes the aircraft's state in RViz."""

import rospy
import tf2_ros
import textwrap
import numpy as np
from functools import partial
from collections import deque
from nav_msgs.msg import Odometry
from sensor_msgs.msg import NavSatFix
from std_msgs.msg import ColorRGBA, Float64
from visualization.msg import StringStamped
from geometry_msgs.msg import Point, PoseStamped
from mavros_msgs.msg import Altitude, State, VFR_HUD
from visualization.unit_converter import UnitConverter
from visualization_msgs.msg import Marker, MarkerArray

GOAL_COLOR = ColorRGBA(r=1.0, g=1.0, b=0.0, a=1.0)
MESH_COLOR = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
MESH_PATH = "package://px4/Tools/sitl_gazebo/models/plane/meshes/body.dae"

# Copied from Flight Review to use familiar colors.
#   MANUAL: Red
#   ALTITUDE: Yellow
#   POSITION: Green
#   ACRO: Olive
#   OFFBOARD: Light blue
#   STABILIZED: Dark blue
#   RATTITUDE: Orange
#   AUTO.*: Purple
#   UNKNOWN: White
PATH_COLORS = {
    "MANUAL":
        ColorRGBA(r=0xCC / 255.0, g=0x00 / 255.0, b=0x00 / 255.0, a=0.5),
    "ALTITUDE":
        ColorRGBA(r=0xEE / 255.0, g=0xCC / 255.0, b=0x00 / 255.0, a=0.5),
    "POSITION":
        ColorRGBA(r=0x00 / 255.0, g=0xCC / 255.0, b=0x33 / 255.0, a=0.5),
    "ACRO":
        ColorRGBA(r=0x66 / 255.0, g=0xCC / 255.0, b=0x00 / 255.0, a=0.5),
    "OFFBOARD":
        ColorRGBA(r=0x00 / 255.0, g=0xCC / 255.0, b=0xCC / 255.0, a=0.5),
    "STABILIZED":
        ColorRGBA(r=0x00 / 255.0, g=0x33 / 255.0, b=0xCC / 255.0, a=0.5),
    "RATTITUDE":
        ColorRGBA(r=0xEE / 255.0, g=0x99 / 255.0, b=0x00 / 255.0, a=0.5),
}
PATH_COLOR_AUTO = ColorRGBA(
    r=0x66 / 255.0, g=0x00 / 255.0, b=0xCC / 255.0, a=0.5)
PATH_COLOR_UNKNOWN = ColorRGBA(r=1.0, g=1.0, b=1.0, a=0.5)


class HUD(object):

    """Heads-Up Display information."""

    def __init__(self, converter):
        """Constructs a HUD.

        Args:
            converter (UnitConverter): Unit converter.
        """
        self._armed = False
        self._mode = "UNKNOWN"

        self._formatted_distance = ""
        self._formatted_msl_alt = ""
        self._formatted_rel_alt = ""
        self._formatted_airspeed = ""
        self._formatted_groundspeed = ""

        self._converter = converter

        rospy.Subscriber(
            "/mavros/altitude", Altitude, self._altitude_cb, queue_size=1)
        rospy.Subscriber(
            "/mavros/global_position/local",
            Odometry,
            self._local_pos_cb,
            queue_size=1)
        rospy.Subscriber("/mavros/state", State, self._state_cb, queue_size=1)
        rospy.Subscriber(
            "/mavros/vfr_hud", VFR_HUD, self._vfr_hud_cb, queue_size=1)

    def get_mode_color(self):
        """Returns the corresponding color for the current mode of operation.

        Returns:
            ColorRGBA message.
        """
        mode = self._mode
        if mode in PATH_COLORS:
            return PATH_COLORS[mode]
        if mode.startswith("AUTO"):
            return PATH_COLOR_AUTO
        return PATH_COLOR_UNKNOWN

    def _altitude_cb(self, msg):
        """Global position callback.

        Args:
            msg (Altitude): ROS message.
        """
        self._formatted_msl_alt = "{:4.1f} {}".format(
            self._converter.distance(msg.amsl), self._converter.distance_unit())
        self._formatted_rel_alt = "{:4.1f} {}".format(
            self._converter.distance(msg.relative),
            self._converter.distance_unit())

    def _local_pos_cb(self, msg):
        """Local position callback.

        Args:
            msg (Odometry): ROS message.
        """
        distance = np.linalg.norm([
            msg.pose.pose.position.x,
            msg.pose.pose.position.y,
            msg.pose.pose.position.z,
        ])
        self._formatted_distance = "{:4.1f} {}".format(
            self._converter.distance(distance), self._converter.distance_unit())

    def _state_cb(self, msg):
        """State callback.

        Args:
            msg (State): ROS message.
        """
        self._mode = msg.mode
        self._armed = msg.armed

    def _vfr_hud_cb(self, msg):
        """VFR HUD callback.

        Args:
            msg (VFR_HUD): ROS message.
        """
        self._formatted_airspeed = "{:4.1f} {}".format(
            converter.speed(msg.airspeed), converter.speed_unit())
        self._formatted_groundspeed = "{:4.1f} {}".format(
            converter.speed(msg.groundspeed), converter.speed_unit())

    def to_string_stamped(self):
        """Formats the HUD information to a visualizable format.

        Returns:
            StringStamped message.
        """
        msg = StringStamped()
        msg.header.frame_id = "map"
        fmt = textwrap.dedent("""\
            MODE: {s._mode}
            ARMED: {s._armed}

            MSL ALT: {s._formatted_msl_alt}
            REL ALT: {s._formatted_rel_alt}

            AIRSPEED: {s._formatted_airspeed}
            GROUND SPEED: {s._formatted_groundspeed}

            DISTANCE: {s._formatted_distance}
            """)
        msg.data = fmt.format(s=self)
        return msg


def aircraft_cb(msg, cb_args):
    """Publishes a marker to the aircraft's state.

    Args:
        msg (NavSatFix): Aircraft global position message.
        cb_args (HUD, TfBuffer, Publisher, float, float, deque, deque):
            Additional callback arguments.
    """
    hud, tf_buffer, pub, lifetime, scale, path_queue, color_queue = cb_args

    # Build the mesh marker.
    mesh_marker = Marker()
    mesh_marker.header.stamp = msg.header.stamp
    mesh_marker.header.frame_id = "base_link"
    mesh_marker.frame_locked = True

    mesh_marker.type = Marker.MESH_RESOURCE
    mesh_marker.color = MESH_COLOR
    mesh_marker.ns = "aircraft/mesh"
    mesh_marker.lifetime = rospy.Duration(lifetime)
    mesh_marker.scale.x = mesh_marker.scale.y = mesh_marker.scale.z = scale
    mesh_marker.mesh_resource = MESH_PATH

    markers_array = MarkerArray()
    markers_array.markers.append(mesh_marker)

    # Build the plane path marker.
    path_marker = Marker()
    path_marker.header.stamp = msg.header.stamp
    path_marker.header.frame_id = "map"

    path_marker.type = Marker.LINE_STRIP
    path_marker.ns = "aircraft/path"
    path_marker.lifetime = rospy.Duration(lifetime)
    path_marker.scale.x = 1.0

    try:
        vector = tf_buffer.lookup_transform("map", "base_link",
                                            rospy.Time(0)).transform.translation
        path_queue.append(Point(vector.x, vector.y, vector.z))
        color_queue.append(hud.get_mode_color())
        path_marker.points = list(path_queue)
        path_marker.colors = list(color_queue)
        markers_array.markers.append(path_marker)
    except (tf2_ros.LookupException, tf2_ros.ConnectivityException,
            tf2_ros.ExtrapolationException) as e:
        rospy.logerr_throttle(1.0, str(e))

    pub.publish(markers_array)


def goal_cb(msg, cb_args):
    """Goal callback.

    Args:
        msg (PoseStamped): Planner goal message.
        cb_args (Publisher, float): Additional callback arguments.
    """
    pub, scale = cb_args

    marker = Marker()
    marker.header = msg.header

    marker.type = Marker.SPHERE
    marker.color = GOAL_COLOR
    marker.ns = "plan/goal"
    marker.scale.x = marker.scale.y = marker.scale.z = scale
    marker.pose = msg.pose

    markers_array = MarkerArray()
    markers_array.markers.append(marker)

    pub.publish(markers_array)


def hud_cb(hud, pub, event):
    """HUD callback.

    Args:
        hud (HUD): Heads-up display.
        pub (Publisher): ROS publisher.
        event (TimerEvent): Unused.
    """
    msg = hud.to_string_stamped()
    pub.publish(msg)


if __name__ == "__main__":
    rospy.init_node("~state")

    aircraft_lifetime = float(rospy.get_param("~aircraft/lifetime"))
    aircraft_scale = float(rospy.get_param("~aircraft/scale"))
    path_queue_size = int(rospy.get_param("~aircraft/queue_size"))
    goal_scale = float(rospy.get_param("~plan/goal/scale"))

    aircraft_pub = rospy.Publisher("~aircraft", MarkerArray, queue_size=1)
    plan_pub = rospy.Publisher("~plan", MarkerArray, queue_size=1)

    converter = UnitConverter(rospy.get_param("~metric"))
    hud = HUD(converter)
    path_queue = deque(maxlen=path_queue_size)
    color_queue = deque(maxlen=path_queue_size)

    tf_buffer = tf2_ros.Buffer()
    tf_listener = tf2_ros.TransformListener(tf_buffer)

    rospy.Subscriber(
        "/planner/dwa_planner/current_target",
        PoseStamped,
        goal_cb,
        callback_args=(plan_pub, goal_scale),
        queue_size=1)
    rospy.Subscriber(
        "/mavros/global_position/global",
        NavSatFix,
        aircraft_cb,
        callback_args=(hud, tf_buffer, aircraft_pub, aircraft_lifetime,
                       aircraft_scale, path_queue, color_queue),
        queue_size=1)

    hud_pub = rospy.Publisher("~hud", StringStamped, queue_size=1)
    rospy.Timer(rospy.Duration(0.05), partial(hud_cb, hud, hud_pub))

    rospy.spin()
