#!/usr/bin/env python
"""Visualizes interop mission information in RViz."""

import rospy
from geometry_msgs.msg import Point
from transformers.points import ENUCoord
from std_msgs.msg import ColorRGBA, Header
from geographic_msgs.msg import GeoPointStamped
from visualization_msgs.msg import Marker, MarkerArray
from interop.msg import FlyZoneArray, GeoPolygonStamped, WayPoints

AIR_DROP_COLOR_1 = ColorRGBA(r=1.0, g=0.0, b=0.0, a=1.0)
AIR_DROP_COLOR_2 = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
EMERGENT_COLOR = ColorRGBA(r=1.0, g=1.0, b=0.0, a=1.0)
FLYZONE_SIDE_COLOR = ColorRGBA(r=218 / 255.0, g=41 / 255.0, b=28 / 255.0, a=0.4)
FLYZONE_TOP_COLOR = ColorRGBA(r=218 / 255.0, g=41 / 255.0, b=28 / 255.0, a=1.0)
OFF_AXIS_COLOR = ColorRGBA(r=0.0, g=0.0, b=1.0, a=1.0)
SEARCH_GRID_COLOR = ColorRGBA(r=0.0, g=1.0, b=0.0, a=1.0)
TEXT_COLOR = ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)
WAYPOINT_COLOR = ColorRGBA(r=0.0, g=1.0, b=0.0, a=1.0)


def air_drop_cb(msg, cb_args):
    """Publishes a marker corresponding to an air drop message.

    Args:
        msg (GeoPointStamped): ROS message.
        cb_args (Publisher, float, float): Additional callback
            arguments.
    """
    pub, lifetime, scale = cb_args

    # Generate base header.
    header = Header()
    header.stamp = msg.header.stamp
    header.frame_id = "air_drop"

    namespaces = [5, 4, 3, 2, 1]
    colors = [
        AIR_DROP_COLOR_1, AIR_DROP_COLOR_2, AIR_DROP_COLOR_1, AIR_DROP_COLOR_2,
        AIR_DROP_COLOR_1
    ]
    scale_factors = [1.0, 0.8, 0.6, 0.4, 0.2]

    offset = 0
    markers_array = MarkerArray()
    for ns, color, scale_factor in zip(namespaces, colors, scale_factors):
        marker = Marker()
        marker.header = header

        marker.type = Marker.CYLINDER
        marker.color = color
        marker.ns = "air_drop/{}".format(ns)
        marker.lifetime = rospy.Duration(lifetime)
        marker.scale.x = marker.scale.y = scale * scale_factor
        marker.scale.z = 0.2
        marker.pose.position.z = offset
        offset += 0.2

        markers_array.markers.append(marker)

    pub.publish(markers_array)


def geopoint_cb(msg, cb_args):
    """Publishes a marker corresponding to a GeoPointStamped message.

    Args:
        msg (GeoPointStamped): ROS message.
        cb_args (str, Publisher, float, float, Color): Additional
            callback arguments.
    """
    frame, pub, lifetime, scale, color = cb_args

    marker = Marker()

    marker.header.stamp = msg.header.stamp
    marker.header.frame_id = frame

    marker.type = Marker.CYLINDER
    marker.color = color
    marker.ns = frame
    marker.lifetime = rospy.Duration(lifetime)
    marker.scale.x = marker.scale.y = scale
    marker.scale.z = 0.1

    markers_array = MarkerArray()
    markers_array.markers.append(marker)
    pub.publish(markers_array)


def flyzones_cb(msg, cb_args):
    """Publishes flyzones formed with triangular markers.

    Args:
        msg (FlyZoneArray): Flyzones message.
        cb_args (ENUCoord, Publisher, float): Additional callback arguments.
    """
    ref, pub, lifetime = cb_args

    markers_array = MarkerArray()
    for i, flyzone in enumerate(msg.flyzones):
        if not flyzone.zone.polygon.points:
            continue

        points = flyzone.zone.polygon.points + flyzone.zone.polygon.points[:1]

        marker2d_min = Marker()
        marker2d_max = Marker()
        marker3d = Marker()

        marker2d_min.type = Marker.LINE_STRIP
        marker2d_max.type = Marker.LINE_STRIP
        marker3d.type = Marker.TRIANGLE_LIST

        marker2d_min.ns = "flyzones/{}/min".format(i + 1)
        marker2d_max.ns = "flyzones/{}/max".format(i + 1)
        marker3d.ns = "flyzones/{}/3d".format(i + 1)

        marker2d_min.color = FLYZONE_TOP_COLOR
        marker2d_max.color = FLYZONE_TOP_COLOR
        marker3d.color = FLYZONE_SIDE_COLOR

        for marker in (marker2d_min, marker2d_max, marker3d):
            marker.header.stamp = flyzone.zone.header.stamp
            marker.header.frame_id = "map"
            marker.lifetime = rospy.Duration(lifetime)
            marker.scale.x = marker.scale.y = marker.scale.z = 1.0

        for gpt1, gpt2 in zip(points, points[1:]):
            # Convert latitude and longitude to ENU.
            lla1_min = (gpt1.latitude, gpt1.longitude, flyzone.min_alt)
            lla1_max = (gpt1.latitude, gpt1.longitude, flyzone.max_alt)
            lla2_min = (gpt2.latitude, gpt2.longitude, flyzone.min_alt)
            lla2_max = (gpt2.latitude, gpt2.longitude, flyzone.max_alt)

            enu1_min = ENUCoord.from_lla(lla1_min, ref)
            enu1_max = ENUCoord.from_lla(lla1_max, ref)
            enu2_min = ENUCoord.from_lla(lla2_min, ref)
            enu2_max = ENUCoord.from_lla(lla2_max, ref)

            point1_min = Point(enu1_min.x, enu1_min.y, enu1_min.z)
            point1_max = Point(enu1_max.x, enu1_max.y, enu1_max.z)
            point2_min = Point(enu2_min.x, enu2_min.y, enu2_min.z)
            point2_max = Point(enu2_max.x, enu2_max.y, enu2_max.z)

            # Need to draw each triangle twice in order for the color to be
            # visible from both sides.
            marker3d.points.extend([
                # Triangle 1.
                point1_min,
                point1_max,
                point2_min,
                # Triangle 1 reversed.
                point1_min,
                point2_min,
                point1_max,
                # Triangle 2.
                point1_max,
                point2_max,
                point2_min,
                # Triangle 2 reversed.
                point1_max,
                point2_min,
                point2_max,
            ])

            # 2D view is just a polygon.
            marker2d_min.points.append(point1_min)
            marker2d_max.points.append(point1_max)

        # Close the polygon.
        marker2d_min.points.append(point2_min)
        marker2d_max.points.append(point2_max)

        # Add to markers array.
        markers_array.markers.append(marker2d_min)
        markers_array.markers.append(marker2d_max)
        markers_array.markers.append(marker3d)

    pub.publish(markers_array)


def search_grid_cb(msg, cb_args):
    """Publishes the search grid as a polygon.

    Args:
        msg (GeoPolygonStamped): Search grid message.
        cb_args (ENUCoord, Publisher, float): Additional callback arguments.
    """
    if not msg.polygon.points:
        # We assume there is at least one vertex in the polygon.
        return

    ref, pub, lifetime = cb_args

    marker = Marker()

    marker.header.stamp = msg.header.stamp
    marker.header.frame_id = "map"

    marker.type = Marker.LINE_STRIP
    marker.color = SEARCH_GRID_COLOR
    marker.ns = "search_grid"
    marker.lifetime = rospy.Duration(lifetime)
    marker.scale.x = 1.0

    for geopoint in msg.polygon.points + msg.polygon.points[:1]:
        # Convert latitude and longitude to ENU.
        lla = (geopoint.latitude, geopoint.longitude, geopoint.altitude)
        enu = ENUCoord.from_lla(lla, ref)
        point = Point()
        point.x = enu.x
        point.y = enu.y
        point.z = enu.z
        marker.points.append(point)

    markers_array = MarkerArray()
    markers_array.markers.append(marker)
    pub.publish(markers_array)


def waypoints_cb(msg, cb_args):
    """Publishes waypoints as spherical markers.

    Args:
        msg (WayPoints): Waypoints message.
        cb_args (Publisher, float, float): Additional callback arguments.
    """
    pub, lifetime, scale = cb_args

    markers_array = MarkerArray()
    for i, waypoint in enumerate(msg.waypoints):
        wp_marker = Marker()
        text_marker = Marker()

        for marker in (wp_marker, text_marker):
            marker.header.frame_id = "waypoints/{}".format(i + 1)
            marker.header.stamp = msg.header.stamp
            marker.lifetime = rospy.Duration(lifetime)

        wp_marker.type = Marker.SPHERE
        wp_marker.color = WAYPOINT_COLOR
        wp_marker.ns = "{}/sphere".format(wp_marker.header.frame_id)
        wp_marker.scale.x = wp_marker.scale.y = wp_marker.scale.z = scale

        text_marker.type = Marker.TEXT_VIEW_FACING
        text_marker.color = TEXT_COLOR
        text_marker.ns = "{}/text".format(text_marker.header.frame_id)
        text_marker.text = str(i + 1)
        text_marker.scale.z = 10
        text_marker.pose.position.z = scale + 1.0

        markers_array.markers.append(wp_marker)
        markers_array.markers.append(text_marker)

    pub.publish(markers_array)


if __name__ == "__main__":
    rospy.init_node("~mission_info")

    airdrop_lifetime = float(rospy.get_param("~air_drop/lifetime"))
    airdrop_scale = float(rospy.get_param("~air_drop/scale"))
    airdrop_pub = rospy.Publisher("~air_drop", MarkerArray, queue_size=1)

    emergent_lifetime = float(rospy.get_param("~emergent/lifetime"))
    emergent_scale = float(rospy.get_param("~emergent/scale"))
    emergent_pub = rospy.Publisher("~emergent", MarkerArray, queue_size=1)

    flyzones_lifetime = float(rospy.get_param("~flyzones/lifetime"))
    flyzones_pub = rospy.Publisher("~flyzones", MarkerArray, queue_size=1)

    off_axis_lifetime = float(rospy.get_param("~off_axis/lifetime"))
    off_axis_scale = float(rospy.get_param("~off_axis/scale"))
    off_axis_pub = rospy.Publisher("~off_axis", MarkerArray, queue_size=1)

    search_grid_lifetime = float(rospy.get_param("~search_grid/lifetime"))
    search_grid_pub = rospy.Publisher("~search_grid", MarkerArray, queue_size=1)

    waypoints_lifetime = float(rospy.get_param("~waypoints/lifetime"))
    waypoints_scale = float(rospy.get_param("~waypoints/scale"))
    waypoints_pub = rospy.Publisher("~waypoints", MarkerArray, queue_size=1)

    ref = ENUCoord.ref_point_from_map_transform()

    rospy.Subscriber(
        "/interop/mission_info/air_drop",
        GeoPointStamped,
        air_drop_cb,
        queue_size=1,
        callback_args=(airdrop_pub, airdrop_lifetime, airdrop_scale))
    rospy.Subscriber(
        "/interop/mission_info/emergent_obj",
        GeoPointStamped,
        geopoint_cb,
        queue_size=1,
        callback_args=("emergent_obj", emergent_pub, emergent_lifetime,
                       emergent_scale, EMERGENT_COLOR))
    rospy.Subscriber(
        "/interop/mission_info/flyzones",
        FlyZoneArray,
        flyzones_cb,
        queue_size=1,
        callback_args=(ref, flyzones_pub, flyzones_lifetime))
    rospy.Subscriber(
        "/interop/mission_info/off_axis_obj",
        GeoPointStamped,
        geopoint_cb,
        queue_size=1,
        callback_args=("off_axis_obj", off_axis_pub, off_axis_lifetime,
                       off_axis_scale, OFF_AXIS_COLOR))
    rospy.Subscriber(
        "/interop/mission_info/search_grid",
        GeoPolygonStamped,
        search_grid_cb,
        queue_size=1,
        callback_args=(ref, search_grid_pub, search_grid_lifetime))
    rospy.Subscriber(
        "/interop/mission_info/waypoints",
        WayPoints,
        waypoints_cb,
        queue_size=1,
        callback_args=(waypoints_pub, waypoints_lifetime, waypoints_scale))

    rospy.spin()
