# Planner

This package navigates the drone to goal positions while avoiding obstacles

Check out the docs [here](https://drone.mcgillrobotics.com/packages/planner).

