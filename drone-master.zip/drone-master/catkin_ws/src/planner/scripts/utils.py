#!/usr/bin/env python
import rospy
import tf
import numpy as np

from pyproj import Proj, transform
from threading import Lock, Thread
from math import sin, cos
from functools import partial
from transformers.points import ENUCoord

from std_srvs.srv import Trigger
from std_msgs.msg import String
from mavros_msgs.msg import PositionTarget

TAKEOFF_MASK = 0x11f8
LAND_MASK = 0x21f8


class SyncMsg(object):

    def __init__(self):
        self._lock = Lock()
        self._msg = None
        self.got_msg = False

    def get(self):
        with self._lock:
            self.got_msg = False
            return self._msg

    def set(self, data):
        with self._lock:
            self.got_msg = True
            self._msg = data

    def available(self):
        return self.got_msg


IN_AIR = 1
TAKEOFF = 2
LANDING = 3
IN_GROUND = 4

publish = True

current_state = IN_GROUND

msg = SyncMsg()


def send_messages(publisher, rate):
    global publish

    while not msg.available() and not rospy.is_shutdown():
        rate.sleep()

    msg_ = msg.get()
    while not rospy.is_shutdown() and publish:
        if msg.available():
            msg_ = msg.get()
        publisher.publish(msg_)
        rate.sleep()


def try_lookup_state(listener):
    while not rospy.is_shutdown():
        try:
            return listener.lookupTransform("map", "base_link", rospy.Time(0))
        except:
            rospy.logwarn_throttle(1, "Waiting for map to base_link transform")
            continue


def build_msg(ref_point, listener, goal_altitude, distance):
    position, quaternion = try_lookup_state(listener)
    msg = PositionTarget()
    msg.position.z = -goal_altitude
    _, _, yaw = tf.transformations.euler_from_quaternion(quaternion)
    x = cos(yaw) * distance + position[0]
    y = sin(yaw) * distance + position[0]

    inv_rot = tf.transformations.quaternion_inverse(ref_point.q)
    tmp = tf.transformations.quaternion_multiply(inv_rot,
                                                 [x, y, -goal_altitude, 0.0])
    tr = tf.transformations.quaternion_multiply(
        tmp, tf.transformations.quaternion_conjugate(inv_rot))[:3]

    translated = [tr[0] + ref_point.x, tr[1] + ref_point.y, tr[2] + ref_point.z]

    lla = Proj(proj="latlon", ellps="WGS84", datum="WGS84")
    ecef = Proj(proj="geocent", ellps="WGS84", datum="WGS84")

    lon, lat, _ = transform(
        ecef, lla, translated[0], translated[1], translated[2], radians=False)

    msg.position.x = lat
    msg.position.y = lon

    return msg


def takeoff_callback(ref_point, publisher, listener, goal_altitude, distance,
                     req):
    global publish
    global current_state
    if current_state == IN_AIR or current_state == LANDING:
        return False, "Failed, not in the correct state"

    msg_ = build_msg(ref_point, listener, goal_altitude, distance)
    msg_.type_mask = TAKEOFF_MASK
    msg.set(msg_)
    current_state = TAKEOFF
    publish = True
    return True, "Success"


def land_callback(ref_point, listener, distance, req):
    global publish
    global current_state
    if current_state != IN_AIR:
        return False

    msg_ = build_msg(ref_point, listener, 0, distance)
    msg_.type_mask = LAND_MASK
    msg.set(msg_)

    publish = True
    return True


def update_state(listener, altitude):
    position, _ = try_lookup_state(listener)
    in_ground = np.isclose(position[2], 0, atol=5)
    if current_state == TAKEOFF or current_state == IN_GROUND:
        if position[2] > altitude:
            current_state = IN_AIR
            publish = False


def get_state(listener, altitude):
    """
    Get the current state in string format after update.
    Args:
        listener(TransformListener) : TransformListener to listen to the
            baselink transform.
        altitude(float) : Minimum altitude.

    Returns:
        A string corresponding to the state.
    """
    global publish
    global current_state

    position, _ = try_lookup_state(listener)
    in_ground = np.isclose(position[2], 0, atol=5)
    if current_state == TAKEOFF:
        if position[2] > altitude:
            current_state = IN_AIR
            publish = False
            return "IN_AIR"
        else:
            return "TAKEOFF"
    elif current_state == IN_AIR:
        return "IN_AIR"
    elif current_state == LANDING:
        return "LANDING"


if __name__ == '__main__':
    rospy.init_node("utils")

    ref_point = ENUCoord.ref_point_from_map_transform()

    listener = tf.TransformListener()
    publisher = rospy.Publisher(
        "/mavros/setpoint_raw/local", PositionTarget, queue_size=1)

    takeoff_distance = rospy.get_param("~takeoff_distance")
    land_distance = rospy.get_param("~land_distance")
    altitude = rospy.get_param("~minimum_altitude")

    pub_thread = Thread(target=send_messages, args=(publisher, rospy.Rate(20)))
    pub_thread.start()

    takeoff_cb = partial(takeoff_callback, ref_point, publisher, listener,
                         altitude, takeoff_distance)
    land_cb = partial(land_callback, ref_point, publisher, listener,
                      land_distance)

    takeoff_service = rospy.Service("takeoff", Trigger, takeoff_cb)
    land_service = rospy.Service("land", Trigger, land_cb)

    planner_state_pub = rospy.Publisher("state", String, queue_size=1)
    state_pub_rate = rospy.Rate(30)

    while not rospy.is_shutdown():
        state = get_state(listener, altitude)
        planner_state_pub.publish(state)

        state_pub_rate.sleep()
    pub_thread.join()
