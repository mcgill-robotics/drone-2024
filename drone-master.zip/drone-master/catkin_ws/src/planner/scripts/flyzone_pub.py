#!/usr/bin/env python
import rospy
import tf
from transformers.points.enu_coord import ENUCoord
from interop.msg import FlyZoneArray
from geometry_msgs.msg import PolygonStamped, Point

if __name__ == '__main__':
    rospy.init_node("flyzone_pub")
    ref_point = ENUCoord.ref_point_from_map_transform()
    flyzones = rospy.wait_for_message("/interop/mission_info/flyzones",
                                      FlyZoneArray)
    major_fz = filter(lambda x: x.min_alt >= 0, flyzones.flyzones)[0]

    polygon = PolygonStamped()
    for point in major_fz.zone.polygon.points:
        tr_point = ENUCoord.from_lla((point.latitude, point.longitude, 0),
                                     ref_point)
        polygon.polygon.points.append(
            Point(x=tr_point.x, y=tr_point.y, z=tr_point.z))

    publisher = rospy.Publisher("/flyzone", PolygonStamped, queue_size=1)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        publisher.publish(polygon)
        rate.sleep()
