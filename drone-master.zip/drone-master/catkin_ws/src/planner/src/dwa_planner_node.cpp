#include <atomic>
#include <string>
#include <thread>

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <eigen3/Eigen/Core>

#include <geometry_msgs/PolygonStamped.h>
#include <interop/GeoCylinderArrayStamped.h>
#include <interop/GeoSphereArrayStamped.h>
#include <mavros_msgs/PositionTarget.h>
#include <nav_msgs/Path.h>
#include <std_msgs/String.h>
#include <std_srvs/SetBool.h>

#include "cost_terms/flyzone_cost_term.h"
#include "cost_terms/goal_cost_term.h"
#include "cost_terms/obstacle_cost_term.h"
#include "dwa_planner.h"
#include "utils/msg_listener.h"

std::atomic_bool publish(false);

bool get_current_location(Eigen::Vector3f &out, float &curr_altitude,
                          float &curr_roll,
                          const tf::TransformListener &listener) {
  bool success = false;
  tf::StampedTransform tr;
  try {
    listener.waitForTransform("map", "base_link", ros::Time(0),
                              ros::Duration(1));
    listener.lookupTransform("map", "base_link", ros::Time(0), tr);
    double roll, pitch, yaw;
    tf::Matrix3x3(tr.getRotation()).getRPY(roll, pitch, yaw);
    curr_roll = roll;
    out[0] = tr.getOrigin().x();
    out[1] = tr.getOrigin().y();
    curr_altitude = tr.getOrigin().z();
    out[2] = yaw;
    success = true;
  } catch (tf::TransformException e) {
    ROS_WARN("Failed to fetch the transform to base link: %s", e.what());
  }
  return success;
}

nav_msgs::Path path_from_motion(const Motion &m, float alt) {
  nav_msgs::Path out;
  std_msgs::Header header;
  header.frame_id = "map";
  header.stamp = ros::Time::now();
  out.header = header;
  for (auto it = m.begin(); it != m.end(); it++) {
    geometry_msgs::PoseStamped pose;
    pose.header = header;
    pose.pose.position.x = (*it)[0];
    pose.pose.position.y = (*it)[1];
    pose.pose.position.z = alt;
    out.poses.push_back(pose);
  }
  return out;
}

void setup_cost_functions(ros::NodeHandle &node, ObstacleCostTerm &obs_cost,
                          FlyzoneCostTerm &fz_cost) {
  const auto stationary_obstacles =
      ros::topic::waitForMessage<interop::GeoCylinderArrayStamped>(
          "/interop/obstacles/stationary", node, ros::Duration(0));
  const auto moving_obstacles =
      ros::topic::waitForMessage<interop::GeoSphereArrayStamped>(
          "/interop/obstacles/moving", node, ros::Duration(0));

  const auto flyzones =
      ros::topic::waitForMessage<geometry_msgs::PolygonStamped>(
          "/flyzone", node, ros::Duration(0));

  std::vector<Eigen::Vector2f> points;
  for (auto &point : flyzones->polygon.points) {
    Eigen::Vector2f point_vec;
    point_vec[0] = point.x;
    point_vec[1] = point.y;
    points.push_back(point_vec);
  }
  fz_cost.add_flyzone(points);

  for (int i = 0; i < stationary_obstacles->cylinders.size(); ++i) {
    obs_cost.add_stationary_obstacle(i + 1,
                                     stationary_obstacles->cylinders[i].radius,
                                     stationary_obstacles->cylinders[i].height);
  }
  for (int i = 0; i < moving_obstacles->spheres.size(); ++i) {
    obs_cost.add_moving_obstacle(i + 1, moving_obstacles->spheres[i].radius);
  }
}

bool publish_callback(std_srvs::SetBool::Request &req,
                      std_srvs::SetBool::Response &resp) {
  publish = req.data;
  resp.success = true;
  return true;
}

int main(int argc, char **argv) {
  ros::init(argc, argv, "dwa_planner");
  ros::NodeHandle node("~");

  ros::AsyncSpinner spinner(4);
  spinner.start();

  std::string cmd_vel_topic;
  node.getParam("cmd_vel_topic", cmd_vel_topic);

  float dt, max_u;
  int step_count, velocity_samples;
  float obstacle_cost_a, goal_cost_a, flyzone_cost_a;
  float obstacle_dilation_offset;
  bool dynamic_obstacle_dilation;
  float default_goal_x, default_goal_y, default_goal_z;
  float minimum_altitude;
  float max_roll_rate;
  float flyzone_avoidance_range;
  bool debug;

  node.getParam("dt", dt);
  node.getParam("max_roll", max_u);
  node.getParam("step_count", step_count);
  node.getParam("vel_samples", velocity_samples);
  node.getParam("debug", debug);
  node.getParam("obstacle_cost_alpha", obstacle_cost_a);
  node.getParam("goal_cost_alpha", goal_cost_a);
  node.getParam("flyzone_cost_alpha", flyzone_cost_a);
  node.getParam("dynamic_obstacle_dilation", dynamic_obstacle_dilation);
  node.getParam("obstacle_dilation_offset", obstacle_dilation_offset);
  node.getParam("default_goal_x", default_goal_x);
  node.getParam("default_goal_y", default_goal_y);
  node.getParam("default_altitude", default_goal_z);
  node.getParam("minimum_altitude", minimum_altitude);
  node.getParam("max_roll_rate", max_roll_rate);
  node.getParam("flyzone_avoidance_range", flyzone_avoidance_range);

  Listener<geometry_msgs::TwistStamped> state_listener(1);
  Listener<geometry_msgs::PoseStamped> goal_listener(2);

  const tf::TransformListener listener;

  const ros::Subscriber state_sub = node.subscribe(
      "/mavros/local_position/velocity", 10,
      &Listener<geometry_msgs::TwistStamped>::cb, &state_listener);
  const ros::Subscriber goal_sub = node.subscribe(
      "target", 10, &Listener<geometry_msgs::PoseStamped>::cb, &goal_listener);

  const ros::Publisher current_goal_pub =
      node.advertise<geometry_msgs::PoseStamped>("current_target", 10);
  const ros::Publisher trajectory_pub =
      node.advertise<nav_msgs::Path>("debug/out", 10);
  const ros::Publisher cmd_vel =
      node.advertise<mavros_msgs::PositionTarget>(cmd_vel_topic, 10);

  const ros::ServiceServer publish_srv =
      node.advertiseService("toggle_publish", publish_callback);

  DWAPlanner planner(dt, step_count, 10, max_u, -max_u, max_roll_rate);

  GoalCostTerm goal_cost(goal_cost_a);
  ObstacleCostTerm obs_cost(obstacle_cost_a, obstacle_dilation_offset, node,
                            dynamic_obstacle_dilation, max_u);
  FlyzoneCostTerm flyzone_cost(flyzone_cost_a, flyzone_avoidance_range);

  setup_cost_functions(node, obs_cost, flyzone_cost);

  ros::Rate planner_rate = 20;

  planner.add_cost_term(&goal_cost);
  planner.add_cost_term(&obs_cost);
  planner.add_cost_term(&flyzone_cost);

  state_listener.wait_for_new_msg();

  float goal_x = default_goal_x;
  float goal_y = default_goal_y;
  float goal_z = default_goal_z;

  while (ros::ok()) {
    if (!publish) {
      continue;
    }

    const geometry_msgs::TwistStamped vel_state = state_listener.get_msg();

    // Update our goal if a new goal is available
    if (goal_listener.new_data_available()) {
      const geometry_msgs::PoseStamped goal = goal_listener.get_msg();
      geometry_msgs::PoseStamped tr_goal;
      try {
        listener.transformPose("map", goal, tr_goal);
        goal_x = tr_goal.pose.position.x;
        goal_y = tr_goal.pose.position.y;
        goal_z =
            tr_goal.pose.position.z < std::numeric_limits<double>::epsilon()
                ? goal_z
                : tr_goal.pose.position.z;
      } catch (tf::TransformException e) {
        ROS_WARN("Could not get transform to map, discarding goal %s",
                 e.what());
      }
    }

    if (goal_z < minimum_altitude) {
      ROS_WARN_THROTTLE(0.5, "Altitude set point too low: %f", goal_z);
      goal_z = minimum_altitude;
    }

    const Eigen::Vector3f goal_vec(goal_x, goal_y, goal_z);
    goal_cost.update_goal(goal_vec);

    Eigen::Vector3f curr_loc;
    float curr_altitude;
    float curr_roll;
    if (get_current_location(curr_loc, curr_altitude, curr_roll, listener)) {
      const float current_speed =
          std::sqrt(std::pow(vel_state.twist.linear.x, 2) +
                    std::pow(vel_state.twist.linear.y, 2));

      const float u =
          planner.plan(curr_loc, current_speed, curr_altitude, curr_roll);
      mavros_msgs::PositionTarget pub_msg;

      // Type mask to enable offboard mode, see mavlink docs.
      pub_msg.type_mask = 0x1f8;
      pub_msg.yaw_rate = u;
      pub_msg.position.z = -goal_z;
      cmd_vel.publish(pub_msg);

      geometry_msgs::PoseStamped current_goal;
      current_goal.header.frame_id = "map";
      current_goal.header.stamp = ros::Time::now();
      current_goal.pose.position.x = goal_x;
      current_goal.pose.position.y = goal_y;
      current_goal.pose.position.z = goal_z;
      current_goal_pub.publish(current_goal);

      if (debug) {
        const Motion m = planner.get_current_motion();
        trajectory_pub.publish(path_from_motion(m, -goal_z));
      }
      planner_rate.sleep();
    }
  }
  return 0;
}
