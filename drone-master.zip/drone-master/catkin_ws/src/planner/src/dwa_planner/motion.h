#ifndef MOTION_H
#define MOTION_H
#include <eigen3/Eigen/Core>
#include <vector>

/*!
 * \brief Defines a motion as a list of reference points seperated by dt.
 *        Can be generated from arbitary dynamics models.
 *
 *        Not really a trajectory because we do not keep time data on the
 * states.
 */
class Motion {
 private:
  std::vector<Eigen::Vector3f> ref_states;
  float dt;

  float u;              //!< angular velocity input in the motion>
  float v;              //!< linear velocity in the motion>
  float curr_altitude;  //!< altitude when the motion starts>

 public:
  typedef std::vector<Eigen::Vector3f>::const_iterator const_iterator;
  Motion(Eigen::Vector3f start, const float dt, const float u, const float v,
         const float curr_altitude)
      : dt(dt), u(u), v(v), curr_altitude(curr_altitude) {
    ref_states.push_back(start);
  }

  void add_point(Eigen::Vector3f pnt) { ref_states.push_back(pnt); }

  float get_dt() const { return dt; }

  float get_u() const { return u; }

  float get_v() const { return v; }

  float get_altitude() const { return curr_altitude; };

  size_t get_length() const { return ref_states.size(); }

  const_iterator begin() const { return ref_states.cbegin(); }

  const_iterator end() const { return ref_states.cend(); }
};

#endif  // MOTION_H
