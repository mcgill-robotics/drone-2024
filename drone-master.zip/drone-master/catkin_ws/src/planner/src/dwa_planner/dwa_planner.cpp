#include "dwa_planner.h"
#include <ros/ros.h>

#define ONE_G 9.81

DWAPlanner::DWAPlanner(const float dt, const int step_count,
                       const int sample_num, const float max_u,
                       const float min_u, const float max_roll_rate)
    : dt(dt),
      step_count(step_count),
      min_u(min_u),
      max_u(max_u),
      max_roll_rate(max_roll_rate),
      n(sample_num),
      curr_traj(Eigen::Vector3f(0, 0, 0), 0, 0, 0, 0) {
  assert(max_u > min_u);
}

void DWAPlanner::add_cost_term(CostTerm *cost_term) {
  cost_functions.push_back(cost_term);
}

void DWAPlanner::set_num_samples(const int samples) { this->n = samples; }

float DWAPlanner::plan(const Eigen::Vector3f &curr_state, const float speed,
                       const float curr_altitude, const float curr_roll) {
  const float interval = dt * step_count;
  const float max_roll_change = interval * max_roll_rate;

  float max_roll = -curr_roll + max_roll_change;
  if (max_roll > max_u) {
    max_roll = max_u;
  }

  float min_roll = -curr_roll - max_roll_change;
  if (min_roll < min_u) {
    min_roll = min_u;
  }

  const float max_yaw = std::tan(max_roll) * ONE_G / speed;
  const float min_yaw = std::tan(min_roll) * ONE_G / speed;

  const float sample_dist = (max_roll - min_roll) / n;
  float curr_u = min_yaw;

  float min_cost = std::numeric_limits<float>::max();
  float u = 0;

  while (curr_u < max_yaw && ros::ok()) {
    const Motion mot = simulate(curr_state, curr_u, speed, curr_altitude);
    const float curr_cost = evaluate_costs(mot);
    if (curr_cost < min_cost) {
      u = curr_u;
      min_cost = curr_cost;
      curr_traj = mot;
    }
    curr_u += sample_dist;
  }
  return u;
}

const Motion DWAPlanner::simulate(const Eigen::Vector3f &curr_state,
                                  const float u, const float v,
                                  const float curr_altitude) {
  float curr_x = curr_state[0];
  float curr_y = curr_state[1];
  float curr_theta = curr_state[2];

  Motion m(curr_state, dt, u, v, curr_altitude);

  for (int i = 0; i < step_count; i++) {
    curr_theta += dt * u;
    curr_x += v * std::cos(curr_theta) * dt;
    curr_y += v * std::sin(curr_theta) * dt;
    m.add_point(Eigen::Vector3f(curr_x, curr_y, curr_theta));
  }
  return m;
}

float DWAPlanner::evaluate_costs(const Motion &m) {
  float cost = 0;

  for (CostTerm *cost_term : cost_functions) {
    cost += (*cost_term)(m);
  }

  return cost;
}

Motion DWAPlanner::get_current_motion() const { return curr_traj; }
