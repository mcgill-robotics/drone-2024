#ifndef OBSTACLE_COST_H
#define OBSTACLE_COST_H

#include <state_estimation/PointSpline.h>
#include <state_estimation/PointSplineArrayStamped.h>
#include <state_estimation/Spline.h>
#include <tf/transform_listener.h>
#include <unordered_map>

#include "cost_term.h"
#include "utils/msg_listener.h"

class ObstacleCostTerm : public CostTerm {
 public:
  constexpr static float static_cost = 1e3;

  struct Obstacle {
    int key;
    float radius;
    bool valid;
    Eigen::Vector3f location;
  };

  struct MovingObstacle : Obstacle {
    state_estimation::Spline x_spline;
    state_estimation::Spline y_spline;
    state_estimation::Spline z_spline;
    bool splines_valid;
  };

  struct StationaryObstacle : Obstacle {
    float height;
  };

  /*!
   * \brief Create a static obstacle cost term.
   * \param smoothing_factor Multiplicative factor applied to all costs.
   * \param dilation_offset The radial offset to calculate the dilation with,
   * only used when dynamic_dilation is False.
   * \param dynamic_dilation Set true if dilation should be calculated using
   * current state.
   * \param max_turn_rate Used to calculate the dynamic dilation factor.
   */
  ObstacleCostTerm(const float smoothing_factor, const float dilation_offset,
                   ros::NodeHandle &node, const bool dynamic_dilation = false,
                   const float max_turn_rate = 0);

  /*!
   * \brief Add an obstacle to track.
   * \param key Key for the obstacle.
   * \param radius Radius of the obstacle.
   */
  void add_stationary_obstacle(const int key, const float radius,
                               const float height);
  void add_moving_obstacle(const int key, const float radius);
  /*!
   * \brief Set the multiplying factor for the cost.
   * \param coeff The factor to set.
   */
  void set_cost_coefficient(const float coeff);

  /*!
   * \brief Poll all  obstacles.
   */
  void poll_stationary_obstacles();
  void poll_moving_obstacles();

  /*!
   * \brief Get the cost for a motion for stationary obstacles.
   * \param m The motion to evaluate.
   * \return The cost of the motion.
   */
  float get_stationary_obstacle_cost(const Motion &m);
  float get_moving_obstacle_cost(const Motion &m);
  float get_cost(const Motion &m);

 private:
  void fetch_obstacle_position(MovingObstacle &obs);
  void fetch_obstacle_position(StationaryObstacle &obs);

  void fetch_obstacle_position(Obstacle &obs, const std::string &frame_key);

  float evaluate_spline(const state_estimation::Spline &spline,
                        const double time);

  float get_dilation(const Eigen::Vector3f &final_location,
                     const Eigen::Vector3f &obstacle_location,
                     const float obstacle_radius, const float speed);
  float get_dilation_offset(const float obstacle_radius, const float speed);

  float calculate_circular_obs_cost(Eigen::Vector3f const &plane_location,
                                    Eigen::Vector3f const &obs_location,
                                    float const radius, float const dilation);
  void make_obstacle(Obstacle &obs, int const key, float const radius);

  tf::TransformListener listener;
  std::vector<StationaryObstacle> stationary_obstacle_data;
  std::vector<MovingObstacle> moving_obstacle_data;

  Listener<state_estimation::PointSplineArrayStamped> spline_listener;

  int num_obstacles{0};
  float a{0};
  float dilation_offset{0};

  bool dynamic_dilation{false};
  float max_turn_rate{0};
};
#endif  // OBSTACLE_COST_H
