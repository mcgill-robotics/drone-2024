#include <tf/transform_listener.h>
#include <unordered_map>

#include "obstacle_cost_term.h"

using namespace state_estimation;

constexpr float ObstacleCostTerm::static_cost;

ObstacleCostTerm::ObstacleCostTerm(const float smoothing_factor,
                                   const float dilation_offset,
                                   ros::NodeHandle &node,
                                   const bool dynamic_dilation,
                                   const float max_turn_rate)
    : a(smoothing_factor),
      dynamic_dilation(dynamic_dilation),
      dilation_offset(dilation_offset),
      max_turn_rate(max_turn_rate),
      spline_listener(99) {
  if (dynamic_dilation) {
    assert(max_turn_rate > 0);
  }
  node.subscribe("/state_estimation/obstacle_tracker/predictions", 10,
                 &Listener<PointSplineArrayStamped>::cb, &spline_listener);
}

void ObstacleCostTerm::add_stationary_obstacle(const int key,
                                               const float radius,
                                               const float height) {
  StationaryObstacle obs;
  make_obstacle(obs, key, radius);
  obs.height = height;
  stationary_obstacle_data.push_back(obs);
}

void ObstacleCostTerm::add_moving_obstacle(const int key, const float radius) {
  MovingObstacle obs;
  make_obstacle(obs, key, radius);
  moving_obstacle_data.push_back(obs);
}

void ObstacleCostTerm::set_cost_coefficient(const float coeff) { a = coeff; }

void ObstacleCostTerm::poll_stationary_obstacles() {
  for (auto &obs : stationary_obstacle_data) {
    std::stringstream obs_frame_key;
    obs_frame_key << "obstacles/stationary/" << obs.key;
    tf::StampedTransform tr;
    try {
      listener.lookupTransform("map", obs_frame_key.str(), ros::Time(0), tr);
      obs.location = Eigen::Vector3f(tr.getOrigin().x(), tr.getOrigin().y(),
                                     tr.getOrigin().z());
      obs.valid = true;
    } catch (tf::TransformException exception) {
      ROS_WARN_THROTTLE(
          1, "Failed to retrieve location of stationary obstacle %i", obs.key);
      obs.valid = false;
    }
  }
}

void ObstacleCostTerm::poll_moving_obstacles() {
  double current_time = ros::Time::now().toSec();

  PointSplineArrayStamped msg;
  bool msg_valid = spline_listener.new_data_available();
  if (msg_valid) {
    msg = spline_listener.get_msg();
  }

  for (auto &obs : moving_obstacle_data) {
    fetch_obstacle_position(obs);
    if (msg_valid) {
      auto spline = msg.point_splines[obs.key];
      obs.x_spline = spline.x_spline;
      obs.y_spline = spline.y_spline;
      obs.z_spline = spline.z_spline;
      obs.splines_valid = true;
    } else {
      obs.splines_valid = false;
    }
  }
}

void ObstacleCostTerm::fetch_obstacle_position(MovingObstacle &obs) {
  std::stringstream obs_frame_key;
  obs_frame_key << "obstacles/moving/" << obs.key;
  tf::StampedTransform tr;
  try {
    listener.lookupTransform("map", obs_frame_key.str(), ros::Time(0), tr);
    obs.location = Eigen::Vector3f(tr.getOrigin().x(), tr.getOrigin().y(),
                                   tr.getOrigin().z());
    obs.valid = true;
  } catch (tf::TransformException exception) {
    ROS_WARN_THROTTLE(1, "Failed to retrieve location of moving obstacle %i",
                      obs.key);
    obs.valid = false;
  }
}

float ObstacleCostTerm::get_stationary_obstacle_cost(const Motion &m) {
  poll_stationary_obstacles();

  float cost = 0;

  for (int i = 0; i < m.get_length(); i++) {
    const Eigen::Vector3f final_loc = *(m.begin() + i);
    for (auto &obs : stationary_obstacle_data) {
      const float dilation =
          get_dilation(final_loc, obs.location, obs.radius, m.get_v());
      if (obs.valid) {
        if (m.get_altitude() >
            obs.location[2] + obs.height) {  // Should some buffer here?
          continue;
        }

        cost += calculate_circular_obs_cost(final_loc, obs.location, obs.radius,
                                            dilation);
      }
    }
  }
  return cost;
}

float ObstacleCostTerm::get_moving_obstacle_cost(const Motion &m) {
  poll_moving_obstacles();

  float cost = 0;
  double initial_time = ros::Time::now().toSec();

  for (int i = 0; i < m.get_length(); i++) {
    const Eigen::Vector3f final_loc = *(m.begin() + i);
    double current_time = initial_time + m.get_dt() * i;
    for (auto &obs : moving_obstacle_data) {
      const float dilation =
          get_dilation(final_loc, obs.location, obs.radius, m.get_v());
      if (obs.valid) {
        // Skip the obstacle if our altitude is not within range
        if ((m.get_altitude() < obs.location[2] - obs.radius - dilation) ||
            (m.get_altitude() > obs.location[2] + obs.radius + dilation))
          continue;

        Eigen::Vector3f location = obs.location;
        if (obs.splines_valid) {
          location[0] = evaluate_spline(obs.x_spline, current_time);
          location[1] = evaluate_spline(obs.y_spline, current_time);
          location[2] = evaluate_spline(obs.z_spline, current_time);
        }

        cost += calculate_circular_obs_cost(final_loc, obs.location, obs.radius,
                                            dilation);
      }
    }
  }
  return std::min(static_cost, cost);  // Cap the cost
}

float ObstacleCostTerm::evaluate_spline(const Spline &spline,
                                        const double time) {
  double abs_time = time - spline.t0.toSec();
  return (float)(spline.c0 + abs_time * spline.c1 +
                 std::pow(abs_time, 2) * spline.c2 +
                 std::pow(abs_time, 3) * spline.c3);
}

float ObstacleCostTerm::get_cost(const Motion &m) {
  return get_moving_obstacle_cost(m) + get_stationary_obstacle_cost(m);
}

float ObstacleCostTerm::get_dilation(const Eigen::Vector3f &final_location,
                                     const Eigen::Vector3f &obstacle_location,
                                     const float obstacle_radius,
                                     const float speed) {
  const float theta = final_location[2];
  auto v_curr_obs = obstacle_location - final_location;
  const float theta_curr_obs = std::atan2(v_curr_obs[1], v_curr_obs[0]);
  const float projection = std::cos(theta_curr_obs - theta) * v_curr_obs.norm();

  const auto point =
      projection * Eigen::Vector2f(std::cos(theta), std::sin(theta)) +
      final_location.head<2>();

  if (projection < 0 ||
      (point - obstacle_location.head<2>()).norm() > obstacle_radius) {
    return 0;  // We are not going to hit the obstacle so don't dilate.
  } else {
    return get_dilation_offset(obstacle_radius, speed);
  }
}

float ObstacleCostTerm::get_dilation_offset(const float obstacle_radius,
                                            const float speed) {
  if (!dynamic_dilation) {
    return dilation_offset;
  }

  // Caculate the diameter of the fastest turn possible.
  return (speed / max_turn_rate);
}

float ObstacleCostTerm::calculate_circular_obs_cost(
    Eigen::Vector3f const &plane_location, Eigen::Vector3f const &obs_location,
    float const radius, float const dilation) {
  float cost = 0;

  const float dist = (plane_location.head<2>() - obs_location.head<2>()).norm();
  const float obs_augmented_radius = (radius + dilation);

  // Inside the obstacles dilated area but not inside the actual obstacle.
  if (dist > radius && dist < obs_augmented_radius) {
    const float dilated_area_cost = (1. / (dist - radius));
    cost = a * dilated_area_cost;
    ROS_WARN_THROTTLE(1, "Distance to closest obstacle: %f", dist);
  } else if (dist < radius) {
    cost = static_cost;
    ROS_WARN_THROTTLE(1, "Collided with an obstacle");
  }
  return cost;
}

void ObstacleCostTerm::make_obstacle(Obstacle &obs, int const key,
                                     float const radius) {
  obs.key = key;
  obs.radius = radius;
}
