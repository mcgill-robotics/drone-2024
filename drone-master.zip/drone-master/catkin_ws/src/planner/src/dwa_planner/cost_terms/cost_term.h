#ifndef COSTTERM_H
#define COSTTERM_H

#include "motion.h"

class CostTerm {
 public:
  virtual float operator()(const Motion &m) { return get_cost(m); }

  /*!
   * \brief get_cost Find the cost on a given Motion
   * \param curr_u current angular velocity
   * \param curr_v current lateral velocity
   * \return the total cost
   */
  virtual float get_cost(const Motion &m) = 0;

  /*!
   * \brief set_cost_coefficient Set the coefficient for the cost term
   * \param coeff coeff to set.
   */
  virtual void set_cost_coefficient(const float coeff) = 0;
};

#endif  // COSTTERM_H
