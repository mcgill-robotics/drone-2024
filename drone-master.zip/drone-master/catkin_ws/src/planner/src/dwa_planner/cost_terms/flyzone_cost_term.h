#ifndef FLYZONECOST_H
#define FLYZONECOST_H
#include <ros/ros.h>
#include "cost_term.h"

class FlyzoneCostTerm : public CostTerm {
 public:
  struct Line {
    float max_x;
    float min_x;
    float m;
    float b;
  };

  FlyzoneCostTerm(const float smoothing_factor,
                  const float flyzone_check_range);
  void add_flyzone(const std::vector<Eigen::Vector2f>& point_list);
  void set_cost_coefficient(const float coeff) override;
  float get_cost(const Motion& m);

 private:
  bool inside_flyzone(const Eigen::Vector3f& location);
  bool line_intersection(Eigen::Vector2f& point, const Line& line1,
                         const Line& line2);
  float dist_to_closest_line(const Eigen::Vector3f& state);
  float get_buffer_range(const Motion& m);

  Eigen::Vector2f point;
  std::vector<Line> lines;
  float flyzone_check_range;
  float a;
};

#endif  // FLYZONECOST_H
