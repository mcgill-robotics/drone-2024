#include "flyzone_cost_term.h"

FlyzoneCostTerm::FlyzoneCostTerm(const float smoothing_factor,
                                 const float flyzone_check_range)
    : a(smoothing_factor), flyzone_check_range(flyzone_check_range) {}

void FlyzoneCostTerm::set_cost_coefficient(const float coeff) { a = coeff; }

void FlyzoneCostTerm::add_flyzone(
    const std::vector<Eigen::Vector2f>& point_list) {
  for (auto it = point_list.begin(); it != point_list.end(); it++) {
    Line line;
    Eigen::Vector2f pnt1 = *it;
    Eigen::Vector2f pnt2 =
        it == point_list.end() - 1 ? *point_list.begin() : *(it + 1);
    line.min_x = std::min(pnt1[0], pnt2[0]);
    line.max_x = std::max(pnt1[0], pnt2[0]);
    line.m = (pnt2[1] - pnt1[1]) / (pnt2[0] - pnt1[0]);
    line.b = pnt1[1] - line.m * pnt1[0];
    lines.push_back(line);
  }
}

bool FlyzoneCostTerm::inside_flyzone(const Eigen::Vector3f& state) {
  size_t i = 0;

  const float x = state[0];
  const float y = state[1];
  for (auto& line : lines) {
    const float line_y = line.m * x + line.b;
    if (x <= line.max_x && x > line.min_x && y > line_y) {
      i++;
    }
  }
  return i % 2 == 1;
}

float FlyzoneCostTerm::dist_to_closest_line(const Eigen::Vector3f& state) {
  Line l2;
  l2.m = std::tan(state[2]);
  if (state[2] <= M_PI / 2 && state[2] >= -M_PI / 2) {
    l2.min_x = state[0];
    l2.max_x = std::numeric_limits<float>::max();
  } else if (state[2] < -M_PI / 2 || state[2] > M_PI / 2) {
    l2.min_x = -std::numeric_limits<float>::max();
    l2.max_x = state[0];
  }

  float min_dist = std::numeric_limits<float>::max();
  l2.b = state[1] - l2.m * state[0];
  for (auto& line : lines) {
    Eigen::Vector2f intersection;
    if (line_intersection(intersection, line, l2)) {
      float dist = (intersection - state.head<2>()).norm();
      min_dist = dist < min_dist ? dist : min_dist;
    }
  }
  return min_dist;
}

float FlyzoneCostTerm::get_cost(const Motion& m) {
  const Eigen::Vector3f final_loc = *(m.end() - 1);
  const bool is_inside = inside_flyzone(final_loc);
  if (is_inside) {
    float min_dist = dist_to_closest_line(final_loc);
    if (min_dist < flyzone_check_range) {
      ROS_WARN_THROTTLE(1, "Trying to avoid flyzone, distance: %f", min_dist);
      return a / min_dist;
    }
    return 0;
  }
  ROS_WARN_THROTTLE(1, "Outside the flyzone");
  return 1e4;
}

float FlyzoneCostTerm::get_buffer_range(const Motion& m) {}

bool FlyzoneCostTerm::line_intersection(Eigen::Vector2f& point,
                                        const FlyzoneCostTerm::Line& line1,
                                        const FlyzoneCostTerm::Line& line2) {
  if (!std::isfinite(line1.m) && !std::isfinite(line2.m)) {
    if (line2.min_x == line1.min_x) {
      point[0] = line2.min_x;
    } else {
      return false;
    }
  } else if (!std::isfinite(line1.m)) {
    point[0] = line1.min_x;
    point[1] = line2.m * line1.min_x + line2.b;
  } else if (!std::isfinite(line2.m)) {
    point[0] = line2.min_x;
    point[1] = line1.m * line2.min_x + line1.b;
  } else {
    point[0] = (line2.b - line1.b) / (line1.m - line2.m);
    if ((point[0] < line1.min_x || point[0] > line1.max_x) ||
        (point[0] < line2.min_x || point[0] > line2.max_x)) {
      return false;
    }
    point[1] = line1.m * point[0] + line1.b;
  }
  return true;
}
