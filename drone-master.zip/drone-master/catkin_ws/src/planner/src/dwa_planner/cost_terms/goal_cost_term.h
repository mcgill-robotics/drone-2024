#ifndef GOALCOST_H
#define GOALCOST_H
#include <ros/ros.h>
#include "cost_term.h"

class GoalCostTerm : public CostTerm {
 public:
  /*!
   * \brief Goal cost term
   * \param smoothing_factor Smoothing factor applied to the cost.
   */
  GoalCostTerm(const float smoothing_factor) : a(smoothing_factor) {}

  /*!
   * \brief Set the cost factor.
   * \param coeff Coefficient to set.
   */
  void set_cost_coefficient(const float coeff) override { a = coeff; }

  /*!
   * \brief Update the goal to track.
   * \param goal The goal to track.
   */
  void update_goal(Eigen::Vector3f goal) { this->goal = goal; }

  /*!
   * \brief Get the cost for a motion m
   * \param m The motion to evaluate.
   */
  float get_cost(const Motion &m) {
    const Eigen::Vector3f final_state = *(m.end() - 1);
    const float x = goal[0] - final_state[0];
    const float y = goal[1] - final_state[1];
    float angle_to_dest = std::fabs(final_state[2] - std::atan2(y, x));
    if (angle_to_dest > M_PI) {
      angle_to_dest = 2 * M_PI - angle_to_dest;
    }
    return a * angle_to_dest;
  }

 private:
  Eigen::Vector3f goal;
  float a;
};

#endif  // GOALCOST_H
