#ifndef DWA_PLANNER_H
#define DWA_PLANNER_H

#include "cost_terms/cost_term.h"
#include "motion.h"

/*!
 * \brief The DWAPlanner class implements a dynamic window approach local
 * planner. The planner is strictly implemented for dubins dynamics.
 */

class DWAPlanner {
 public:
  /*!
   * \brief DWAPlanner
   * \param dt the time for one step in a trajectory.
   * \param step_count the number of steps in one interval
   * \param max_u the maximum angular acceleration in one
   * interval(dt*step_count)
   * \param min_u the minimum angular acceleration in one
   * interval(dt*step_count);
   */
  DWAPlanner(const float dt, const int step_count, const int sample_num,
             const float max_u, const float min_u, const float max_roll_rate);

  /*!
   * \brief update_window_size Updates the possible velocities to search.
   * \param min_u Minimum angular velocity.
   * \param max_u Maximum angular velocity.
   */
  void update_window_size(const float min_u, const float max_u);

  /*!
   * \brief add_cost_term Adds a cost term to the optimization procedure
   * \param c CostTerm to add.
   */
  void add_cost_term(CostTerm *c);

  /*!
   * \brief set_num_samples Set the number of samples to be linearly picked from
   * the action space.
   * \param samples Number to pick
   */
  void set_num_samples(const int samples);

  /*!
   * \brief plan Get a target angular velocity for a given state
   * \param curr Current state, [x,y theta]
   * \param speed forward speed
   * \param curr_altitude the current altitude
   * \return the angular velocity command, under the given constraints
   */
  float plan(const Eigen::Vector3f &curr, const float speed,
             const float curr_altitude, const float curr_roll);

  Motion get_current_motion() const;

 private:
  float dt;
  float step_count;
  float max_roll_rate;

  float max_u;
  float min_u;
  int n;

  Motion curr_traj;

  std::vector<CostTerm *> cost_functions;

  const Motion simulate(const Eigen::Vector3f &curr, const float u,
                        const float v, const float current_altitude);
  float evaluate_costs(const Motion &m);
};

#endif  // DWA_PLANNER_H
