#ifndef MSG_LISTENER_H
#define MSG_LISTENER_H

#include <mutex>
#include <string>
#include <thread>

#include <ros/ros.h>

template <class MsgType>
class Listener {
 public:
  Listener(int uid) : data_lock(std::make_shared<std::mutex>()), uid(uid) {}

  MsgType get_msg() {
    is_data_available = false;
    std::lock_guard<std::mutex> guard(*data_lock);
    return data;
  }

  void cb(const boost::shared_ptr<const MsgType> &msg) {
    std::lock_guard<std::mutex> guard(*data_lock);
    data = *msg;
    is_data_available = true;
  }

  bool new_data_available() { return is_data_available; }

  void wait_for_new_msg() {
    while (ros::ok() && !is_data_available) {
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
  }

 private:
  std::shared_ptr<std::mutex> data_lock;
  MsgType data;
  bool is_data_available{false};
  int uid;
};
#endif  // MSG_LISTENER_H
