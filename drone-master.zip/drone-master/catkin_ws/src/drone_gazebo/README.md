# Drone Gazebo

This package simulates the drone, the autopilot and the entire mission. The
drone can be then controlled through MAVLINK as usual (e.g. through MavROS or
QGroundControl).

Check out the docs
[here](https://drone.mcgillrobotics.com/packages/simulation).

