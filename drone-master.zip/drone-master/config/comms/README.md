# Communications and Networking Configurations

This hosts all communication and networking configurations and setups
necessary to connect the drone's onboard computer with the ground station.

# Device naming

You might need to disable device inherited names from GRUB by appending ther
following to the `GRUB_CMDLINE_LINUX=""` line in `/etc/default/grub`:

```
net.ifnames=0 biosdevname=0
```

Then simply copy `10-networking.rules` to `/etc/udev/rules.d/` and
`interfaces` to `/etc/network/interfaces`. Finally, run `sudo update-grub`
and reboot.

# RouterBoards

The RouterBoards are currently set up in a bridged configuration through
Ethernet over IP (EoIP), and each RouterBoard's configuration can be found
in [routerboard-config](routerboard-config).

## Summary

- 2 RouterBoards are bridged using Ethernet over IP (EoIP) tunneling to
  create an Ethernet tunnel between 2 routers on top of an IP connection,
  all Ethernet traffic is bridged just as if there where a physical Ethernet
  interface and cable between the 2 RouterBoards.
- 2 separate EoIP tunnels were created over a 2.4GHz and a 5.8GHz Wi-Fi
  connections.
- The EoIP tunnels are bounded together using balance-rr mode as to form a
  single virtual link. This mode provides load balancing and fault tolerance
  between the 2 tunnels.
- The bounded EoIP tunnels are connected to the first Ethernet port on each
  RouterBoard using MAC bridges.

## IP Addresses

### Ground Station Computer (GSC)
- GSC: `10.0.0.1` (Network `10.0.0.0`)
- GS RouterBoard `eth1`: `10.0.0.2` (Network `10.0.0.0`)
- GS RouterBoard `wlan1`: `10.24.1.2` (Network `10.24.1.0`)
- GS RouterBoard `wlan2`: `10.58.1.2` (Network `10.58.1.0`)
- GS RouterBoard `wlan3`: `10.58.2.2` (Network `10.58.2.0`)

### On-Board Computer (OBC)
- OBC: `10.0.0.4` (Network `10.0.0.0`)
- OB RouterBoard `eth1`: `10.0.0.3` (Network `10.0.0.0`)
- OB RouterBoard `wlan1`: `10.24.1.3` (Network `10.24.1.0`)
- OB RouterBoard `wlan2`: `10.58.1.3` (Network `10.58.1.0`)
