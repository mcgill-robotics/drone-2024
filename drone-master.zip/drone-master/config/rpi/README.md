README for RPi Setup
====================

How-to setup wireless accesss point

- 1: run:
```
sudo apt-get update
sudo apt-get dist-upgrade
sudo apt-get install -y dnsmasq hostapd
sudo systemctl stop dnsmasq
sudo systemctl stop hostapd
```
- 2: append `denyinterfaces wlan0` to `/etc/dhcpcd.conf`
- 3: open `/etc/network/interfaces` and append:
```
allow-hotplug wlan0
iface wlan0 inet static
    address 10.0.1.10
    netmask 255.255.255.0
    network 10.0.1.0
```
- 4: run and ignore warnings and errors:
```
sudo service dhcpcd restart
sudo ifdown wlan0
sudo ifup wlan0
```
- 5: open `/etc/dnsmasq.conf` and insert:
```
interface=wlan0
  dhcp-range=10.0.1.100,10.0.1.200,255.255.255.0,24h
```
- 6: change `/etc/hostapd/hostapd.conf` to:
```
interface=wlan0
driver=nl80211
ssid=McGill Robotics GSG
hw_mode=g
channel=6
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=elgordo21
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
```
- 7: replace the line with `#DAEMON_CONF` with `DAEMON_CONF="/etc/hostapd/hostapd.conf"` in `/etc/default/hostapd`.
- 8: run:
```
sudo service hostapd start
sudo service dnsmasq start
```
