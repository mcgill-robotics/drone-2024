#!/bin/bash
set -e

echo "Install RPi dependencies..."
sudo apt-get install -y python3-smbus

echo "Setting up RPi configurations..."
# Disable bluetooth and serial console that might interfere with GPS
sudo systemctl mask hciuart
sudo systemctl mask serial-getty@ttyAMA0.service

# Move config file
if [[ "$(diff -q cmdline.txt /boot/cmdline.txt)" ]]; then
  sudo mv -f /boot/cmdline.txt /boot/cmdline.txt.backup
  sudo cp -f cmdline.txt /boot/
fi
if [[ "$(diff -q config.txt /boot/config.txt)" ]]; then
  sudo mv -f /boot/config.txt /boot/config.txt.backup
  sudo cp -f config.txt /boot/
fi

