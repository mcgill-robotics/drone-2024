#!/bin/bash
set -e

# Setup chrony server for time sync from FCU to OBC
sudo apt-get install -y chrony
if ! grep -q ROS /etc/chrony/chrony.conf; then
  echo "Setting up chrony server..."
  echo "" | sudo tee -a /etc/chrony/chrony.conf
  echo "### Enable step sync" | sudo tee -a /etc/chrony/chrony.conf
  echo "makestep 10 -1" | sudo tee -a /etc/chrony/chrony.conf
  echo "" | sudo tee -a /etc/chrony/chrony.conf
  echo "### SHM driver (unit 2)" | sudo tee -a /etc/chrony/chrony.conf
  echo "refclock SHM 3:perm=666 delay 0.5 refid ROS" | \
    sudo tee -a /etc/chrony/chrony.conf
  sudo service chrony restart
fi

