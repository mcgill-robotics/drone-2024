# Chrony

`Chrony` is used in conjunction with `ntpd_driver` to sync time
from FCU to a ROS enabled computer.

## Setup
Simply run `setup.sh` in this directory.

## System Explanation
1. `SYSTEM_TIME` is request form the FCU by the `extras.txt` in `params`
folder. The `extras.txt` files need to be copied to `/etc/` of the SD card of
the FCU. This allows `/mavros/time_reference` to be published.

2. `time_sync.launch` in `drone_base` launches `shm_driver` in `ntpd_driver`
that listen to `/mavros/time_reference`, parse the time information, and put
it into shared memory (SHM).

3. `chrony` daemon read the SHM and update system time accordingly.
